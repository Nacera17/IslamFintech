import 'package:flutter/material.dart';
import 'dart:ui';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:flutter_app/utils.dart';
import 'package:google_fonts/google_fonts.dart';

class Property1Component10 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return 
    Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          margin: EdgeInsets.fromLTRB(0, 1, 0, 1),
          child: Text(
            'option',
            style: GoogleFonts.getFont(
              'Inter',
              fontWeight: FontWeight.w700,
              fontSize: 15,
              color: Color(0xFF000000),
            ),
          ),
        ),
        SizedBox(
          width: 20,
          height: 20,
          child: SvgPicture.asset(
            'assets/vectors/ellipse_37_x2.svg',
          ),
        ),
      ],
    );
  }
}
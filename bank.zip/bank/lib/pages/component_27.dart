import 'package:flutter/material.dart';
import 'dart:ui';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:flutter_app/utils.dart';
import 'package:google_fonts/google_fonts.dart';

class Component27 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return 
    Container(
      decoration: BoxDecoration(
        border: Border.all(color: Color(0xFF777777)),
        borderRadius: BorderRadius.circular(2),
        color: Color(0xFFFFFFFF),
      ),
      child: Container(
        padding: EdgeInsets.fromLTRB(1.7, 1.4, 1.4, 1.2),
        child: SizedBox(
          width: 4.9,
          height: 5.5,
          child: SvgPicture.asset(
            'assets/vectors/vector_19_x2.svg',
          ),
        ),
      ),
    );
  }
}
import 'package:flutter/material.dart';
import 'dart:ui';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:flutter_app/utils.dart';
import 'package:vector_math/vector_math_64.dart' as math;

import 'package:google_fonts/google_fonts.dart';

class Info extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return
    Container(
      decoration: BoxDecoration(
        color: Color(0xFFFFFFFF),
      ),
      child: Stack(
        children: [
          Positioned(
            left: -84.2,
            top: 522,
            child: Transform.rotate(
              angle: -0.7374045709,
              child: SizedBox(
                width: 169.4,
                height: 167.4,
                child: SvgPicture.asset(
                  'assets/vectors/ellipse_2847_x2.svg',
                ),
              ),
            ),
          ),
          Positioned(
            left: -114,
            top: 470,
            child: Transform.rotate(
              angle: -0.7374045709,
              child: SizedBox(
                width: 169.4,
                height: 167.4,
                child: SvgPicture.asset(
                  'assets/vectors/ellipse_297_x2.svg',
                ),
              ),
            ),
          ),
          Positioned(
            right: -144,
            top: -296,
            child: Container(
              width: 588,
              height: 221,
              decoration: BoxDecoration(
                boxShadow: [
                  BoxShadow(
                    color: Color(0x40000000),
                    offset: Offset(0, 1),
                    blurRadius: 2,
                  ),
                ],
              ),
              child: SvgPicture.asset(
                'assets/vectors/ellipse_234_x2.svg',
              ),
            ),
          ),
    Container(
            padding: EdgeInsets.fromLTRB(33, 241, 27, 29),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Container(
                  margin: EdgeInsets.fromLTRB(0, 0, 5, 50),
                  child: Align(
                    alignment: Alignment.topCenter,
                    child: Text(
                      'معلومات عن الحساب البنكي',
                      style: GoogleFonts.getFont(
                        'Inter',
                        fontWeight: FontWeight.w700,
                        fontSize: 20,
                        height: 1.5,
                        color: Color(0xFF1DB5B7),
                      ),
                    ),
                  ),
                ),
                Container(
                  margin: EdgeInsets.fromLTRB(0, 0, 3, 39),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(
                        child: Container(
                          margin: EdgeInsets.fromLTRB(0, 0, 9, 0),
                          decoration: BoxDecoration(
                            border: Border.all(color: Color(0xFF000000)),
                            borderRadius: BorderRadius.circular(5),
                            color: Color(0xFFFCFCFE),
                          ),
                          child: Container(
                            padding: EdgeInsets.fromLTRB(2, 14.5, 0, 14.5),
                            child: Stack(
                              clipBehavior: Clip.none,
                              children: [
                                Text(
                                  'XXXXXX.XX',
                                  style: GoogleFonts.getFont(
                                    'Inter',
                                    fontWeight: FontWeight.w700,
                                    fontSize: 15,
                                    color: Color(0xFF000000),
                                  ),
                                ),
                                Positioned(
                                  left: -2,
                                  right: 0,
                                  top: -14.5,
                                  bottom: -14.5,
                                  child: Container(
                                    decoration: BoxDecoration(
                                      border: Border.all(color: Color(0xFF000000)),
                                      borderRadius: BorderRadius.circular(5),
                                      color: Color(0xFFFCFCFE),
                                    ),
                                    child: Container(
                                      width: 179,
                                      height: 48,
                                      padding: EdgeInsets.fromLTRB(2, 14.5, 0, 14.5),
                                      child: Text(
                                        '52136485921',
                                        style: GoogleFonts.getFont(
                                          'Inter',
                                          fontWeight: FontWeight.w700,
                                          fontSize: 15,
                                          color: Color(0xFF0E0E0E),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                      Expanded(
                        child: Container(
                          decoration: BoxDecoration(
                            color: Color(0xFF265073),
                            borderRadius: BorderRadius.circular(5),
                          ),
                          child: Container(
                            height: 48,
                            child: Positioned(
                              right: -13,
                              bottom: 15,
                              child: SizedBox(
                                height: 18,
                                child: Text(
                                  'رقم الحساب البنكي',
                                  style: GoogleFonts.getFont(
                                    'Inter',
                                    fontWeight: FontWeight.w700,
                                    fontSize: 15,
                                    color: Color(0xFFFFFFFF),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  margin: EdgeInsets.fromLTRB(0, 0, 3, 41),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(
                        child: Container(
                          margin: EdgeInsets.fromLTRB(0, 0, 9, 1),
                          decoration: BoxDecoration(
                            border: Border.all(color: Color(0xFF000000)),
                            borderRadius: BorderRadius.circular(5),
                            color: Color(0xFFFCFCFE),
                          ),
                          child: Container(
                            padding: EdgeInsets.fromLTRB(0, 14.5, 0, 14.5),
                            child: Text(
                              'BNA',
                              style: GoogleFonts.getFont(
                                'Inter',
                                fontWeight: FontWeight.w700,
                                fontSize: 15,
                                color: Color(0xFF000000),
                              ),
                            ),
                          ),
                        ),
                      ),
                      Expanded(
                        child: Container(
                          margin: EdgeInsets.fromLTRB(0, 1, 0, 0),
                          child: Container(
                            decoration: BoxDecoration(
                              color: Color(0xFF265073),
                              borderRadius: BorderRadius.circular(5),
                            ),
                            child: Container(
                              padding: EdgeInsets.fromLTRB(2, 15, 0, 15),
                              child: Text(
                                'البنك',
                                style: GoogleFonts.getFont(
                                  'Inter',
                                  fontWeight: FontWeight.w700,
                                  fontSize: 15,
                                  color: Color(0xFFFFFFFF),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  margin: EdgeInsets.fromLTRB(0, 0, 3, 40),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(
                        child: Container(
                          margin: EdgeInsets.fromLTRB(0, 0, 9, 0),
                          decoration: BoxDecoration(
                            border: Border.all(color: Color(0xFFF87C47)),
                            borderRadius: BorderRadius.circular(5),
                            color: Color(0xFFFCFCFE),
                          ),
                          child: Container(
                            padding: EdgeInsets.fromLTRB(1, 14.5, 0, 14.5),
                            child: Text(
                              '100000.00',
                              style: GoogleFonts.getFont(
                                'Inter',
                                fontWeight: FontWeight.w700,
                                fontSize: 15,
                                color: Color(0xFF000000),
                              ),
                            ),
                          ),
                        ),
                      ),
                      Expanded(
                        child: Container(
                          decoration: BoxDecoration(
                            border: Border.all(color: Color(0xFF265073)),
                            borderRadius: BorderRadius.circular(5),
                            color: Color(0xFFF87C47),
                          ),
                          child: Container(
                            padding: EdgeInsets.fromLTRB(2, 14, 0, 14),
                            child: Text(
                              'دج',
                              style: GoogleFonts.getFont(
                                'Inter',
                                fontWeight: FontWeight.w700,
                                fontSize: 15,
                                color: Color(0xFFFFFFFF),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  margin: EdgeInsets.fromLTRB(1, 0, 10, 156),
                  decoration: BoxDecoration(
                    border: Border.all(color: Color(0xA8000000)),
                    borderRadius: BorderRadius.circular(6),
                    color: Color(0xFFFFFFFF),
                  ),
                  child: Container(
                    padding: EdgeInsets.fromLTRB(1, 14.5, 0, 14.5),
                    child: Stack(
                      clipBehavior: Clip.none,
                      children: [
                        Text(
                          'رقم الحساب البنكي',
                          style: GoogleFonts.getFont(
                            'Inter',
                            fontWeight: FontWeight.w700,
                            fontSize: 15,
                            color: Color(0xFFFFFFFF),
                          ),
                        ),
                        Positioned(
                          bottom: 0.5,
                          child: SizedBox(
                            height: 18,
                            child: Text(
                              'عروض خاصة بوكالات الحج و  العمرة ',
                              style: GoogleFonts.getFont(
                                'Inter',
                                fontWeight: FontWeight.w700,
                                fontSize: 15,
                                color: Color(0xFF265073),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                Container(
                  decoration: BoxDecoration(
                    image: DecorationImage(
                      fit: BoxFit.cover,
                      image: AssetImage(
                        'assets/images/exit.png',
                      ),
                    ),
                  ),
                  child: Container(
                    width: 25,
                    height: 25,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
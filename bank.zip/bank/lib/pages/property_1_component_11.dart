import 'package:flutter/material.dart';
import 'dart:ui';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:flutter_app/utils.dart';
import 'package:google_fonts/google_fonts.dart';

class Property1Component11 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return 
    Stack(
      children: [
        SizedBox(
          width: double.infinity,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                margin: EdgeInsets.fromLTRB(0, 1, 0, 1),
                child: Text(
                  'option',
                  style: GoogleFonts.getFont(
                    'Inter',
                    fontWeight: FontWeight.w700,
                    fontSize: 15,
                    color: Color(0xFF000000),
                  ),
                ),
              ),
              SizedBox(
                width: 20,
                height: 20,
                child: SvgPicture.asset(
                  'assets/vectors/ellipse_35_x2.svg',
                ),
              ),
            ],
          ),
        ),
        Positioned(
          right: 6,
          top: 5,
          child: Container(
            decoration: BoxDecoration(
              color: Color(0xFF64CACB),
              borderRadius: BorderRadius.circular(4.5),
            ),
            child: Container(
              width: 9,
              height: 9,
            ),
          ),
        ),
      ],
    );
  }
}
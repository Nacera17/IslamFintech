import 'package:flutter/material.dart';
import 'dart:ui';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:flutter_app/utils.dart';
import 'package:google_fonts/google_fonts.dart';

class Iphone131438 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return 
    Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment(0, 1),
          end: Alignment(0, -1),
          colors: <Color>[Color(0xED64CACB), Color(0xED27658B)],
          stops: <double>[0.7, 0.89],
        ),
      ),
      child: Stack(
        children: [
          Positioned(
            left: -112,
            top: -59,
            child: Container(
              width: 527,
              height: 166.3,
              decoration: BoxDecoration(
                boxShadow: [
                  BoxShadow(
                    color: Color(0x40000000),
                    offset: Offset(0, 1),
                    blurRadius: 2,
                  ),
                ],
              ),
              child: SvgPicture.asset(
                'assets/vectors/ellipse_222_x2.svg',
              ),
            ),
          ),
    Container(
            padding: EdgeInsets.fromLTRB(31, 20, 0, 151),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  margin: EdgeInsets.fromLTRB(0, 0, 0, 147),
                  child: Align(
                    alignment: Alignment.topLeft,
                    child: Container(
                      width: 20,
                      height: 20,
                      child: Container(
                        decoration: BoxDecoration(
                          image: DecorationImage(
                            fit: BoxFit.cover,
                            image: AssetImage(
                              'assets/images/back.png',
                            ),
                          ),
                        ),
                        child: Container(
                          width: 20,
                          height: 20,
                        ),
                      ),
                    ),
                  ),
                ),
                Container(
                  margin: EdgeInsets.fromLTRB(12, 0, 0, 94),
                  child: Align(
                    alignment: Alignment.topCenter,
                    child: SizedBox(
                      width: 242,
                      height: 250,
                      child: SvgPicture.asset(
                        'assets/vectors/undraw_access_account_re_8_spm_1_x2.svg',
                      ),
                    ),
                  ),
                ),
                Container(
                  margin: EdgeInsets.fromLTRB(2, 0, 2, 52),
                  child: Align(
                    alignment: Alignment.topLeft,
                    child: Container(
                      decoration: BoxDecoration(
                        border: Border.all(color: Color(0xFF64CACB)),
                        borderRadius: BorderRadius.circular(100),
                        color: Color(0xFFFFFFFF),
                      ),
                      child: Container(
                        width: 314,
                        padding: EdgeInsets.fromLTRB(0, 12, 0, 23),
                        child: Text(
                          'فتح حساب',
                          style: GoogleFonts.getFont(
                            'Inter',
                            fontWeight: FontWeight.w700,
                            fontSize: 15,
                            color: Color(0xFF000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
                Container(
                  margin: EdgeInsets.fromLTRB(2, 0, 2, 0),
                  child: Align(
                    alignment: Alignment.topLeft,
                    child: Container(
                      decoration: BoxDecoration(
                        color: Color(0xFFFFFFFF),
                        borderRadius: BorderRadius.circular(100),
                      ),
                      child: Container(
                        width: 314,
                        padding: EdgeInsets.fromLTRB(0, 18.5, 0, 18.5),
                        child: Text(
                          'الدخول الى حسابي',
                          style: GoogleFonts.getFont(
                            'Inter',
                            fontWeight: FontWeight.w700,
                            fontSize: 15,
                            color: Color(0xFF000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
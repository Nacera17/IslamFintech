import 'package:flutter/material.dart';
import 'dart:ui';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:flutter_app/utils.dart';
import 'package:google_fonts/google_fonts.dart';

class ArKeyboard1 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return 
    ClipRect(
      child: BackdropFilter(
        filter: ImageFilter.blur(
          sigmaX: 54.3656349182,
          sigmaY: 54.3656349182,
        ),
        child: Container(
          decoration: BoxDecoration(
            color: Color(0xFFD1D5DB),
          ),
          child: Container(
            padding: EdgeInsets.fromLTRB(3, 8, 18, 3),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  margin: EdgeInsets.fromLTRB(0, 0, 0, 12),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(
                        child: Container(
                          margin: EdgeInsets.fromLTRB(0, 0, 5, 0),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(4.6),
                            color: Color(0xFFFCFCFE),
                            boxShadow: [
                              BoxShadow(
                                color: Color(0xFF898A8D),
                                offset: Offset(0, 1),
                                blurRadius: 0,
                              ),
                            ],
                          ),
                          child: Container(
                            padding: EdgeInsets.fromLTRB(2, 10, 3, 10),
                            child: Text(
                              'ض',
                              style: GoogleFonts.getFont(
                                'Tajawal',
                                fontWeight: FontWeight.w400,
                                fontSize: 18,
                                letterSpacing: -0.6,
                                color: Color(0xFF0E0E0E),
                              ),
                            ),
                          ),
                        ),
                      ),
                      Expanded(
                        child: Container(
                          margin: EdgeInsets.fromLTRB(0, 0, 5, 0),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(4.6),
                            color: Color(0xFFFCFCFE),
                            boxShadow: [
                              BoxShadow(
                                color: Color(0xFF898A8D),
                                offset: Offset(0, 1),
                                blurRadius: 0,
                              ),
                            ],
                          ),
                          child: Container(
                            padding: EdgeInsets.fromLTRB(2, 10, 3, 10),
                            child: Text(
                              'ص',
                              style: GoogleFonts.getFont(
                                'Tajawal',
                                fontWeight: FontWeight.w400,
                                fontSize: 18,
                                letterSpacing: -0.6,
                                color: Color(0xFF0E0E0E),
                              ),
                            ),
                          ),
                        ),
                      ),
                      Expanded(
                        child: Container(
                          margin: EdgeInsets.fromLTRB(0, 0, 5, 0),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(4.6),
                            color: Color(0xFFFCFCFE),
                            boxShadow: [
                              BoxShadow(
                                color: Color(0xFF898A8D),
                                offset: Offset(0, 1),
                                blurRadius: 0,
                              ),
                            ],
                          ),
                          child: Container(
                            padding: EdgeInsets.fromLTRB(6.2, 10, 7.2, 10),
                            child: Text(
                              'ث',
                              style: GoogleFonts.getFont(
                                'Tajawal',
                                fontWeight: FontWeight.w400,
                                fontSize: 18,
                                letterSpacing: -0.6,
                                color: Color(0xFF0E0E0E),
                              ),
                            ),
                          ),
                        ),
                      ),
                      Expanded(
                        child: Container(
                          margin: EdgeInsets.fromLTRB(0, 0, 5, 0),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(4.6),
                            color: Color(0xFFFCFCFE),
                            boxShadow: [
                              BoxShadow(
                                color: Color(0xFF898A8D),
                                offset: Offset(0, 1),
                                blurRadius: 0,
                              ),
                            ],
                          ),
                          child: Container(
                            padding: EdgeInsets.fromLTRB(7.4, 10, 8.4, 10),
                            child: Text(
                              'ق',
                              style: GoogleFonts.getFont(
                                'Tajawal',
                                fontWeight: FontWeight.w400,
                                fontSize: 18,
                                letterSpacing: -0.6,
                                color: Color(0xFF0E0E0E),
                              ),
                            ),
                          ),
                        ),
                      ),
                      Expanded(
                        child: Container(
                          margin: EdgeInsets.fromLTRB(0, 0, 5, 0),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(4.6),
                            color: Color(0xFFFCFCFE),
                            boxShadow: [
                              BoxShadow(
                                color: Color(0xFF898A8D),
                                offset: Offset(0, 1),
                                blurRadius: 0,
                              ),
                            ],
                          ),
                          child: Container(
                            padding: EdgeInsets.fromLTRB(6.1, 10, 6.1, 10),
                            child: Text(
                              'ف',
                              style: GoogleFonts.getFont(
                                'Tajawal',
                                fontWeight: FontWeight.w400,
                                fontSize: 18,
                                letterSpacing: -0.6,
                                color: Color(0xFF0E0E0E),
                              ),
                            ),
                          ),
                        ),
                      ),
                      Expanded(
                        child: Container(
                          margin: EdgeInsets.fromLTRB(0, 0, 5, 0),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(4.6),
                            color: Color(0xFFFCFCFE),
                            boxShadow: [
                              BoxShadow(
                                color: Color(0xFF898A8D),
                                offset: Offset(0, 1),
                                blurRadius: 0,
                              ),
                            ],
                          ),
                          child: Container(
                            padding: EdgeInsets.fromLTRB(9, 10, 10, 10),
                            child: Text(
                              'غ',
                              style: GoogleFonts.getFont(
                                'Tajawal',
                                fontWeight: FontWeight.w400,
                                fontSize: 18,
                                letterSpacing: -0.6,
                                color: Color(0xFF0E0E0E),
                              ),
                            ),
                          ),
                        ),
                      ),
                      Expanded(
                        child: Container(
                          margin: EdgeInsets.fromLTRB(0, 0, 5, 0),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(4.6),
                            color: Color(0xFFFCFCFE),
                            boxShadow: [
                              BoxShadow(
                                color: Color(0xFF898A8D),
                                offset: Offset(0, 1),
                                blurRadius: 0,
                              ),
                            ],
                          ),
                          child: Container(
                            padding: EdgeInsets.fromLTRB(9, 10, 10, 10),
                            child: Text(
                              'ع',
                              style: GoogleFonts.getFont(
                                'Tajawal',
                                fontWeight: FontWeight.w400,
                                fontSize: 18,
                                letterSpacing: -0.6,
                                color: Color(0xFF0E0E0E),
                              ),
                            ),
                          ),
                        ),
                      ),
                      Expanded(
                        child: Container(
                          margin: EdgeInsets.fromLTRB(0, 0, 5, 0),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(4.6),
                            color: Color(0xFFFCFCFE),
                            boxShadow: [
                              BoxShadow(
                                color: Color(0xFF898A8D),
                                offset: Offset(0, 1),
                                blurRadius: 0,
                              ),
                            ],
                          ),
                          child: Container(
                            padding: EdgeInsets.fromLTRB(9.4, 10, 10.4, 10),
                            child: Text(
                              'ه',
                              style: GoogleFonts.getFont(
                                'Tajawal',
                                fontWeight: FontWeight.w400,
                                fontSize: 18,
                                letterSpacing: -0.6,
                                color: Color(0xFF0E0E0E),
                              ),
                            ),
                          ),
                        ),
                      ),
                      Expanded(
                        child: Container(
                          margin: EdgeInsets.fromLTRB(0, 0, 5, 0),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(4.6),
                            color: Color(0xFFFCFCFE),
                            boxShadow: [
                              BoxShadow(
                                color: Color(0xFF898A8D),
                                offset: Offset(0, 1),
                                blurRadius: 0,
                              ),
                            ],
                          ),
                          child: Container(
                            padding: EdgeInsets.fromLTRB(8.4, 10, 9.4, 10),
                            child: Text(
                              'خ',
                              style: GoogleFonts.getFont(
                                'Tajawal',
                                fontWeight: FontWeight.w400,
                                fontSize: 18,
                                letterSpacing: -0.6,
                                color: Color(0xFF0E0E0E),
                              ),
                            ),
                          ),
                        ),
                      ),
                      Expanded(
                        child: Container(
                          margin: EdgeInsets.fromLTRB(0, 0, 5, 0),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(4.6),
                            color: Color(0xFFFCFCFE),
                            boxShadow: [
                              BoxShadow(
                                color: Color(0xFF898A8D),
                                offset: Offset(0, 1),
                                blurRadius: 0,
                              ),
                            ],
                          ),
                          child: Container(
                            padding: EdgeInsets.fromLTRB(8.4, 10, 9.4, 10),
                            child: Text(
                              'ح',
                              style: GoogleFonts.getFont(
                                'Tajawal',
                                fontWeight: FontWeight.w400,
                                fontSize: 18,
                                letterSpacing: -0.6,
                                color: Color(0xFF0E0E0E),
                              ),
                            ),
                          ),
                        ),
                      ),
                      Expanded(
                        child: Container(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(4.6),
                            color: Color(0xFFFCFCFE),
                            boxShadow: [
                              BoxShadow(
                                color: Color(0xFF898A8D),
                                offset: Offset(0, 1),
                                blurRadius: 0,
                              ),
                            ],
                          ),
                          child: Container(
                            padding: EdgeInsets.fromLTRB(8.4, 10, 9.4, 10),
                            child: Text(
                              'ج',
                              style: GoogleFonts.getFont(
                                'Tajawal',
                                fontWeight: FontWeight.w400,
                                fontSize: 18,
                                letterSpacing: -0.6,
                                color: Color(0xFF0E0E0E),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  margin: EdgeInsets.fromLTRB(0, 0, 0, 14),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(
                        child: Container(
                          margin: EdgeInsets.fromLTRB(0, 0, 5, 0),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(4.6),
                            color: Color(0xFFFCFCFE),
                            boxShadow: [
                              BoxShadow(
                                color: Color(0xFF898A8D),
                                offset: Offset(0, 1),
                                blurRadius: 0,
                              ),
                            ],
                          ),
                          child: Container(
                            padding: EdgeInsets.fromLTRB(2.1, 10, 3.1, 10),
                            child: Text(
                              'ش',
                              style: GoogleFonts.getFont(
                                'Tajawal',
                                fontWeight: FontWeight.w400,
                                fontSize: 18,
                                letterSpacing: -0.6,
                                color: Color(0xFF0E0E0E),
                              ),
                            ),
                          ),
                        ),
                      ),
                      Expanded(
                        child: Container(
                          margin: EdgeInsets.fromLTRB(0, 0, 5, 0),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(4.6),
                            color: Color(0xFFFCFCFE),
                            boxShadow: [
                              BoxShadow(
                                color: Color(0xFF898A8D),
                                offset: Offset(0, 1),
                                blurRadius: 0,
                              ),
                            ],
                          ),
                          child: Container(
                            padding: EdgeInsets.fromLTRB(2.1, 10, 3.1, 10),
                            child: Text(
                              'س',
                              style: GoogleFonts.getFont(
                                'Tajawal',
                                fontWeight: FontWeight.w400,
                                fontSize: 18,
                                letterSpacing: -0.6,
                                color: Color(0xFF0E0E0E),
                              ),
                            ),
                          ),
                        ),
                      ),
                      Expanded(
                        child: Container(
                          margin: EdgeInsets.fromLTRB(0, 0, 5, 0),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(4.6),
                            color: Color(0xFFFCFCFE),
                            boxShadow: [
                              BoxShadow(
                                color: Color(0xFF898A8D),
                                offset: Offset(0, 1),
                                blurRadius: 0,
                              ),
                            ],
                          ),
                          child: Container(
                            padding: EdgeInsets.fromLTRB(8.1, 10, 8.1, 10),
                            child: Text(
                              'ي',
                              style: GoogleFonts.getFont(
                                'Tajawal',
                                fontWeight: FontWeight.w400,
                                fontSize: 18,
                                letterSpacing: -0.6,
                                color: Color(0xFF0E0E0E),
                              ),
                            ),
                          ),
                        ),
                      ),
                      Expanded(
                        child: Container(
                          margin: EdgeInsets.fromLTRB(0, 0, 5, 0),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(4.6),
                            color: Color(0xFFFCFCFE),
                            boxShadow: [
                              BoxShadow(
                                color: Color(0xFF898A8D),
                                offset: Offset(0, 1),
                                blurRadius: 0,
                              ),
                            ],
                          ),
                          child: Container(
                            padding: EdgeInsets.fromLTRB(6.2, 10, 7.2, 10),
                            child: Text(
                              'ب',
                              style: GoogleFonts.getFont(
                                'Tajawal',
                                fontWeight: FontWeight.w400,
                                fontSize: 18,
                                letterSpacing: -0.6,
                                color: Color(0xFF0E0E0E),
                              ),
                            ),
                          ),
                        ),
                      ),
                      Expanded(
                        child: Container(
                          margin: EdgeInsets.fromLTRB(0, 0, 5, 0),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(4.6),
                            color: Color(0xFFFCFCFE),
                            boxShadow: [
                              BoxShadow(
                                color: Color(0xFF898A8D),
                                offset: Offset(0, 1),
                                blurRadius: 0,
                              ),
                            ],
                          ),
                          child: Container(
                            padding: EdgeInsets.fromLTRB(8.4, 10, 8.4, 10),
                            child: Text(
                              'ل',
                              style: GoogleFonts.getFont(
                                'Tajawal',
                                fontWeight: FontWeight.w400,
                                fontSize: 18,
                                letterSpacing: -0.6,
                                color: Color(0xFF0E0E0E),
                              ),
                            ),
                          ),
                        ),
                      ),
                      Expanded(
                        child: Container(
                          margin: EdgeInsets.fromLTRB(0, 0, 5, 0),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(4.6),
                            color: Color(0xFFFCFCFE),
                            boxShadow: [
                              BoxShadow(
                                color: Color(0xFF898A8D),
                                offset: Offset(0, 1),
                                blurRadius: 0,
                              ),
                            ],
                          ),
                          child: Container(
                            padding: EdgeInsets.fromLTRB(12.3, 10, 12.3, 10),
                            child: Text(
                              'ا',
                              style: GoogleFonts.getFont(
                                'Tajawal',
                                fontWeight: FontWeight.w400,
                                fontSize: 18,
                                letterSpacing: -0.6,
                                color: Color(0xFF0E0E0E),
                              ),
                            ),
                          ),
                        ),
                      ),
                      Expanded(
                        child: Container(
                          margin: EdgeInsets.fromLTRB(0, 0, 5, 0),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(4.6),
                            color: Color(0xFFFCFCFE),
                            boxShadow: [
                              BoxShadow(
                                color: Color(0xFF898A8D),
                                offset: Offset(0, 1),
                                blurRadius: 0,
                              ),
                            ],
                          ),
                          child: Container(
                            padding: EdgeInsets.fromLTRB(6.2, 10, 7.2, 10),
                            child: Text(
                              'ت',
                              style: GoogleFonts.getFont(
                                'Tajawal',
                                fontWeight: FontWeight.w400,
                                fontSize: 18,
                                letterSpacing: -0.6,
                                color: Color(0xFF0E0E0E),
                              ),
                            ),
                          ),
                        ),
                      ),
                      Expanded(
                        child: Container(
                          margin: EdgeInsets.fromLTRB(0, 0, 5, 0),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(4.6),
                            color: Color(0xFFFCFCFE),
                            boxShadow: [
                              BoxShadow(
                                color: Color(0xFF898A8D),
                                offset: Offset(0, 1),
                                blurRadius: 0,
                              ),
                            ],
                          ),
                          child: Container(
                            padding: EdgeInsets.fromLTRB(8.5, 10, 8.5, 10),
                            child: Text(
                              'ن',
                              style: GoogleFonts.getFont(
                                'Tajawal',
                                fontWeight: FontWeight.w400,
                                fontSize: 18,
                                letterSpacing: -0.6,
                                color: Color(0xFF0E0E0E),
                              ),
                            ),
                          ),
                        ),
                      ),
                      Expanded(
                        child: Container(
                          margin: EdgeInsets.fromLTRB(0, 0, 5, 0),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(4.6),
                            color: Color(0xFFFCFCFE),
                            boxShadow: [
                              BoxShadow(
                                color: Color(0xFF898A8D),
                                offset: Offset(0, 1),
                                blurRadius: 0,
                              ),
                            ],
                          ),
                          child: Container(
                            padding: EdgeInsets.fromLTRB(9.4, 10, 9.4, 10),
                            child: Text(
                              'م',
                              style: GoogleFonts.getFont(
                                'Tajawal',
                                fontWeight: FontWeight.w400,
                                fontSize: 18,
                                letterSpacing: -0.6,
                                color: Color(0xFF0E0E0E),
                              ),
                            ),
                          ),
                        ),
                      ),
                      Expanded(
                        child: Container(
                          margin: EdgeInsets.fromLTRB(0, 0, 5, 0),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(4.6),
                            color: Color(0xFFFCFCFE),
                            boxShadow: [
                              BoxShadow(
                                color: Color(0xFF898A8D),
                                offset: Offset(0, 1),
                                blurRadius: 0,
                              ),
                            ],
                          ),
                          child: Container(
                            padding: EdgeInsets.fromLTRB(6.2, 10, 7.2, 10),
                            child: Text(
                              'ك',
                              style: GoogleFonts.getFont(
                                'Tajawal',
                                fontWeight: FontWeight.w400,
                                fontSize: 18,
                                letterSpacing: -0.6,
                                color: Color(0xFF0E0E0E),
                              ),
                            ),
                          ),
                        ),
                      ),
                      Expanded(
                        child: Container(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(4.6),
                            color: Color(0xFFFCFCFE),
                            boxShadow: [
                              BoxShadow(
                                color: Color(0xFF898A8D),
                                offset: Offset(0, 1),
                                blurRadius: 0,
                              ),
                            ],
                          ),
                          child: Container(
                            padding: EdgeInsets.fromLTRB(9.4, 10, 10.4, 10),
                            child: Text(
                              'ة',
                              style: GoogleFonts.getFont(
                                'Tajawal',
                                fontWeight: FontWeight.w400,
                                fontSize: 18,
                                letterSpacing: -0.6,
                                color: Color(0xFF0E0E0E),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  margin: EdgeInsets.fromLTRB(0, 0, 0, 14),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(
                        child: Container(
                          margin: EdgeInsets.fromLTRB(0, 0, 22, 0),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                margin: EdgeInsets.fromLTRB(0, 0, 5, 0),
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(4.6),
                                  color: Color(0xFFFCFCFE),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Color(0xFF898A8D),
                                      offset: Offset(0, 1),
                                      blurRadius: 0,
                                    ),
                                  ],
                                ),
                                child: Container(
                                  padding: EdgeInsets.fromLTRB(9.4, 10, 10.4, 10),
                                  child: Text(
                                    'ء',
                                    style: GoogleFonts.getFont(
                                      'Tajawal',
                                      fontWeight: FontWeight.w400,
                                      fontSize: 18,
                                      letterSpacing: -0.6,
                                      color: Color(0xFF0E0E0E),
                                    ),
                                  ),
                                ),
                              ),
                              Container(
                                margin: EdgeInsets.fromLTRB(0, 0, 5, 0),
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(4.6),
                                  color: Color(0xFFFCFCFE),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Color(0xFF898A8D),
                                      offset: Offset(0, 1),
                                      blurRadius: 0,
                                    ),
                                  ],
                                ),
                                child: Container(
                                  padding: EdgeInsets.fromLTRB(6.2, 10, 7.2, 10),
                                  child: Text(
                                    'ظ',
                                    style: GoogleFonts.getFont(
                                      'Tajawal',
                                      fontWeight: FontWeight.w400,
                                      fontSize: 18,
                                      letterSpacing: -0.6,
                                      color: Color(0xFF0E0E0E),
                                    ),
                                  ),
                                ),
                              ),
                              Container(
                                margin: EdgeInsets.fromLTRB(0, 0, 5, 0),
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(4.6),
                                  color: Color(0xFFFCFCFE),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Color(0xFF898A8D),
                                      offset: Offset(0, 1),
                                      blurRadius: 0,
                                    ),
                                  ],
                                ),
                                child: Container(
                                  padding: EdgeInsets.fromLTRB(6.2, 10, 7.2, 10),
                                  child: Text(
                                    'ط',
                                    style: GoogleFonts.getFont(
                                      'Tajawal',
                                      fontWeight: FontWeight.w400,
                                      fontSize: 18,
                                      letterSpacing: -0.6,
                                      color: Color(0xFF0E0E0E),
                                    ),
                                  ),
                                ),
                              ),
                              Container(
                                margin: EdgeInsets.fromLTRB(0, 0, 5, 0),
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(4.6),
                                  color: Color(0xFFFCFCFE),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Color(0xFF898A8D),
                                      offset: Offset(0, 1),
                                      blurRadius: 0,
                                    ),
                                  ],
                                ),
                                child: Container(
                                  padding: EdgeInsets.fromLTRB(10.5, 10, 10.5, 10),
                                  child: Text(
                                    'ذ',
                                    style: GoogleFonts.getFont(
                                      'Tajawal',
                                      fontWeight: FontWeight.w400,
                                      fontSize: 18,
                                      letterSpacing: -0.6,
                                      color: Color(0xFF0E0E0E),
                                    ),
                                  ),
                                ),
                              ),
                              Container(
                                margin: EdgeInsets.fromLTRB(0, 0, 5, 0),
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(4.6),
                                  color: Color(0xFFFCFCFE),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Color(0xFF898A8D),
                                      offset: Offset(0, 1),
                                      blurRadius: 0,
                                    ),
                                  ],
                                ),
                                child: Container(
                                  padding: EdgeInsets.fromLTRB(10.5, 10, 10.5, 10),
                                  child: Text(
                                    'د',
                                    style: GoogleFonts.getFont(
                                      'Tajawal',
                                      fontWeight: FontWeight.w400,
                                      fontSize: 18,
                                      letterSpacing: -0.6,
                                      color: Color(0xFF0E0E0E),
                                    ),
                                  ),
                                ),
                              ),
                              Container(
                                margin: EdgeInsets.fromLTRB(0, 0, 5, 0),
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(4.6),
                                  color: Color(0xFFFCFCFE),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Color(0xFF898A8D),
                                      offset: Offset(0, 1),
                                      blurRadius: 0,
                                    ),
                                  ],
                                ),
                                child: Container(
                                  padding: EdgeInsets.fromLTRB(11.2, 10, 12.2, 10),
                                  child: Text(
                                    'ز',
                                    style: GoogleFonts.getFont(
                                      'Tajawal',
                                      fontWeight: FontWeight.w400,
                                      fontSize: 18,
                                      letterSpacing: -0.6,
                                      color: Color(0xFF0E0E0E),
                                    ),
                                  ),
                                ),
                              ),
                              Container(
                                margin: EdgeInsets.fromLTRB(0, 0, 5, 0),
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(4.6),
                                  color: Color(0xFFFCFCFE),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Color(0xFF898A8D),
                                      offset: Offset(0, 1),
                                      blurRadius: 0,
                                    ),
                                  ],
                                ),
                                child: Container(
                                  padding: EdgeInsets.fromLTRB(11.2, 10, 12.2, 10),
                                  child: Text(
                                    'ر',
                                    style: GoogleFonts.getFont(
                                      'Tajawal',
                                      fontWeight: FontWeight.w400,
                                      fontSize: 18,
                                      letterSpacing: -0.6,
                                      color: Color(0xFF0E0E0E),
                                    ),
                                  ),
                                ),
                              ),
                              Container(
                                margin: EdgeInsets.fromLTRB(0, 0, 5, 0),
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(4.6),
                                  color: Color(0xFFFCFCFE),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Color(0xFF898A8D),
                                      offset: Offset(0, 1),
                                      blurRadius: 0,
                                    ),
                                  ],
                                ),
                                child: Container(
                                  padding: EdgeInsets.fromLTRB(10.1, 10, 10.1, 10),
                                  child: Text(
                                    'و',
                                    style: GoogleFonts.getFont(
                                      'Tajawal',
                                      fontWeight: FontWeight.w400,
                                      fontSize: 18,
                                      letterSpacing: -0.6,
                                      color: Color(0xFF0E0E0E),
                                    ),
                                  ),
                                ),
                              ),
                              Container(
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(4.6),
                                  color: Color(0xFFFCFCFE),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Color(0xFF898A8D),
                                      offset: Offset(0, 1),
                                      blurRadius: 0,
                                    ),
                                  ],
                                ),
                                child: Container(
                                  padding: EdgeInsets.fromLTRB(8.1, 10, 8.1, 10),
                                  child: Text(
                                    'ى',
                                    style: GoogleFonts.getFont(
                                      'Tajawal',
                                      fontWeight: FontWeight.w400,
                                      fontSize: 18,
                                      letterSpacing: -0.6,
                                      color: Color(0xFF0E0E0E),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      Container(
                        width: 46,
                        height: 42,
                        child: SizedBox(
                          width: 46,
                          height: 42,
                          child: SvgPicture.asset(
                            'assets/vectors/container_4_x2.svg',
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  margin: EdgeInsets.fromLTRB(0, 0, 0, 18),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Stack(
                        children: [
                            Positioned(
                              left: -10,
                              right: -10,
                              top: -11,
                              bottom: -10,
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(4.6),
                                child: Container(
                                  width: 41,
                                  height: 42,
                                  decoration: BoxDecoration(
                                    boxShadow: [
                                      BoxShadow(
                                        color: Color(0xFF898A8D),
                                        offset: Offset(0, 1),
                                        blurRadius: 0,
                                      ),
                                    ],
                                  ),
                                  child: SvgPicture.asset(
                                    'assets/vectors/rectangle_4_x2.svg',
                                  ),
                                ),
                              ),
                            ),
                      Container(
                            padding: EdgeInsets.fromLTRB(10, 11, 10, 10),
                            child: Text(
                              '123',
                              style: GoogleFonts.getFont(
                                'Tajawal',
                                fontWeight: FontWeight.w400,
                                fontSize: 16,
                                height: 1.3,
                                letterSpacing: -0.3,
                                color: Color(0xFF0E0E0E),
                              ),
                            ),
                          ),
                        ],
                      ),
                      SizedBox(
                        width: 41,
                        height: 42,
                        child: SvgPicture.asset(
                          'assets/vectors/image_1_x2.svg',
                        ),
                      ),
                      Stack(
                        children: [
                            Positioned(
                              left: 0,
                              right: 0,
                              top: 0,
                              bottom: 0,
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(4.6),
                                child: Container(
                                  width: 134,
                                  height: 42,
                                  decoration: BoxDecoration(
                                    boxShadow: [
                                      BoxShadow(
                                        color: Color(0xFF898A8D),
                                        offset: Offset(0, 1),
                                        blurRadius: 0,
                                      ),
                                    ],
                                  ),
                                  child: SvgPicture.asset(
                                    'assets/vectors/rectangle_5_x2.svg',
                                  ),
                                ),
                              ),
                            ),
                      Container(
                            width: 134,
                            padding: EdgeInsets.fromLTRB(0, 12, 0, 9),
                            child: Text(
                              'مسافة',
                              style: GoogleFonts.getFont(
                                'Tajawal',
                                fontWeight: FontWeight.w400,
                                fontSize: 16,
                                height: 1.3,
                                letterSpacing: -0.3,
                                color: Color(0xFF0E0E0E),
                              ),
                            ),
                          ),
                        ],
                      ),
                      SizedBox(
                        width: 41,
                        height: 42,
                        child: SvgPicture.asset(
                          'assets/vectors/image_x2.svg',
                        ),
                      ),
                      SizedBox(
                        width: 88,
                        height: 42,
                        child: SvgPicture.asset(
                          'assets/vectors/return_3_x2.svg',
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  margin: EdgeInsets.fromLTRB(21, 0, 6, 0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(
                        width: 25,
                        height: 25,
                        child: SvgPicture.asset(
                          'assets/vectors/vector_36_x2.svg',
                        ),
                      ),
                      Container(
                        margin: EdgeInsets.fromLTRB(0, 15, 0, 5),
                        width: 134,
                        height: 5,
                        child: Container(
                          decoration: BoxDecoration(
                            color: Color(0xFF030319),
                            borderRadius: BorderRadius.circular(100),
                          ),
                          child: Container(
                            width: 134,
                            height: 5,
                          ),
                        ),
                      ),
                      SizedBox(
                        width: 15,
                        height: 25,
                        child: SvgPicture.asset(
                          'assets/vectors/dictation_2_x2.svg',
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
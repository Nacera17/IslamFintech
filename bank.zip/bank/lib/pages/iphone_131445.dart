import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:google_fonts/google_fonts.dart';

class Iphone131445 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          color: Color(0xFFFFFFFF),
        ),
        child: Stack(
          children: [
            Positioned(
              right: -124,
              top: -69,
              child: SizedBox(
                width: 226,
                height: 181,
                child: SvgPicture.asset(
                  'assets/vectors/ellipse_2924_x2.svg',
                ),
              ),
            ),
            SingleChildScrollView(
              child: Container(
                padding: EdgeInsets.fromLTRB(17.9, 20, 17.9, 26),
                child: Column(
                  children: [
                    Container(
                      margin: EdgeInsets.fromLTRB(4.1, 0, 4.1, 55.7),
                      child: Align(
                        alignment: Alignment.topLeft,
                        child: SizedBox(
                          width: 21.9,
                          height: 21.3,
                          child: SvgPicture.asset(
                            'assets/vectors/container_27_x2.svg',
                          ),
                        ),
                      ),
                    ),
                    Container(
                      margin: EdgeInsets.fromLTRB(28.1, 0, 28.1, 4),
                      child: Align(
                        alignment: Alignment.topLeft,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            Container(
                              width: 328.6,
                              decoration: BoxDecoration(
                                border: Border.all(color: Color(0xFF979797)),
                                borderRadius: BorderRadius.circular(100),
                                color: Color(0xFFFFFFFF),
                              ),
                              child: Container(
                                width: 328.6,
                                padding: EdgeInsets.fromLTRB(16, 0, 16, 0),
                                child: TextFormField(
                                  decoration: InputDecoration(
                                    hintText: 'اكتب هنا',
                                    border: InputBorder.none,
                                    hintStyle: GoogleFonts.getFont(
                                      'Inter',
                                      fontWeight: FontWeight.w400,
                                      fontSize: 13,
                                      color: Color(0xFF979797),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Container(
                      margin: EdgeInsets.fromLTRB(30.1, 0, 30.1, 6),
                      child: Align(
                        alignment: Alignment.topLeft,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            Container(
                              width: 328.6,
                              decoration: BoxDecoration(
                                border: Border.all(color: Color(0xFF979797)),
                                borderRadius: BorderRadius.circular(100),
                                color: Color(0xFFFFFFFF),
                              ),
                              child: Container(
                                width: 328.6,
                                padding: EdgeInsets.fromLTRB(16, 0, 16, 0),
                                child: TextFormField(
                                  decoration: InputDecoration(
                                    hintText: 'اكتب هنا',
                                    border: InputBorder.none,
                                    hintStyle: GoogleFonts.getFont(
                                      'Inter',
                                      fontWeight: FontWeight.w400,
                                      fontSize: 13,
                                      color: Color(0xFF979797),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Container(
                      margin: EdgeInsets.fromLTRB(31.1, 0, 31.1, 7),
                      child: Align(
                        alignment: Alignment.topLeft,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            Container(
                              width: 328.6,
                              decoration: BoxDecoration(
                                border: Border.all(color: Color(0xFF979797)),
                                borderRadius: BorderRadius.circular(100),
                                color: Color(0xFFFFFFFF),
                              ),
                              child: Container(
                                width: 328.6,
                                padding: EdgeInsets.fromLTRB(16, 0, 16, 0),
                                child: TextFormField(
                                  keyboardType: TextInputType.number,
                                  decoration: InputDecoration(
                                    hintText: '0',
                                    border: InputBorder.none,
                                    hintStyle: GoogleFonts.getFont(
                                      'Inter',
                                      fontWeight: FontWeight.w400,
                                      fontSize: 13,
                                      color: Color(0xFF979797),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Container(
                      margin: EdgeInsets.fromLTRB(31.1, 0, 31.1, 10),
                      child: Align(
                        alignment: Alignment.topLeft,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            Container(
                              width: 328.6,
                              decoration: BoxDecoration(
                                border: Border.all(color: Color(0xFF979797)),
                                borderRadius: BorderRadius.circular(100),
                                color: Color(0xFFFFFFFF),
                              ),
                              child: Container(
                                width: 328.6,
                                padding: EdgeInsets.fromLTRB(16, 0, 16, 0),
                                child: TextFormField(
                                  decoration: InputDecoration(
                                    hintText: 'اكتب هنا',
                                    border: InputBorder.none,
                                    hintStyle: GoogleFonts.getFont(
                                      'Inter',
                                      fontWeight: FontWeight.w400,
                                      fontSize: 13,
                                      color: Color(0xFF979797),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Container(
                      margin: EdgeInsets.fromLTRB(27.1, 0, 27.1, 12),
                      child: Align(
                        alignment: Alignment.topLeft,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            Container(
                              width: 328.6,
                              decoration: BoxDecoration(
                                border: Border.all(color: Color(0xFF979797)),
                                borderRadius: BorderRadius.circular(100),
                                color: Color(0xFFFFFFFF),
                              ),
                              child: Container(
                                width: 328.6,
                                padding: EdgeInsets.fromLTRB(16, 0, 16, 0),
                                child: TextFormField(
                                  decoration: InputDecoration(
                                    hintText: 'اكتب هنا',
                                    border: InputBorder.none,
                                    hintStyle: GoogleFonts.getFont(
                                      'Inter',
                                      fontWeight: FontWeight.w400,
                                      fontSize: 13,
                                      color: Color(0xFF979797),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Container(
                      margin: EdgeInsets.fromLTRB(29.1, 0, 29.1, 8),
                      child: Align(
                        alignment: Alignment.topLeft,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            Container(
                              width: 328.6,
                              decoration: BoxDecoration(
                                border: Border.all(color: Color(0xFF979797)),
                                borderRadius: BorderRadius.circular(100),
                                color: Color(0xFFFFFFFF),
                              ),
                              child: Container(
                                width: 328.6,
                                height: 53.8,
                                padding: EdgeInsets.fromLTRB(16, 21.8, 16, 17.2),
                                child: Transform.rotate(
                                  angle: -3.0999695795,
                                  child: SizedBox(
                                    width: 19.7,
                                    height: 14.8,
                                    child: SvgPicture.asset(
                                      'assets/vectors/group_3_x2.svg',
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Container(
                      margin: EdgeInsets.fromLTRB(0, 0, 186.2, 14),
                      child: Align(
                        alignment: Alignment.topCenter,
                        child: Text(
                          'استقبال رمز التاكيد ',
                          style: GoogleFonts.getFont(
                            'Inter',
                            fontWeight: FontWeight.w700,
                            fontSize: 15,
                            color: Color(0xFF18AEB1),
                          ),
                        ),
                      ),
                    ),
                    Container(
                      margin: EdgeInsets.fromLTRB(0, 0, 0, 21),
                      child: Align(
                        alignment: Alignment.topLeft,
                        child: SizedBox(
                          width: 339.1,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                margin: EdgeInsets.fromLTRB(0, 0, 0, 2),
                                child: Container(
                                  padding: EdgeInsets.fromLTRB(0, 2, 17.9, 2),
                                  child: Stack(
                                    clipBehavior: Clip.none,
                                    children: [
                                      Text(
                                        'مكالمة صوتية',
                                        style: GoogleFonts.getFont(
                                          'Inter',
                                          fontWeight: FontWeight.w600,
                                          fontSize: 13,
                                          color: Color(0xFF0E0E0E),
                                        ),
                                      ),
                                      Positioned(
                                        right: 0,
                                        bottom: 0,
                                        child: Container(
                                          width: 20,
                                          height: 20,
                                          decoration: BoxDecoration(
                                            border: Border.all(color: Color(0xC9808080)),
                                            borderRadius: BorderRadius.circular(100),
                                            color: Color(0xFFFFFFFF),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              Container(
                                margin: EdgeInsets.fromLTRB(0, 2, 0, 0),
                                child: Container(
                                  padding: EdgeInsets.fromLTRB(0, 0, 14.4, 0),
                                  child: Stack(
                                    clipBehavior: Clip.none,
                                    children: [
                                      Text(
                                        'الرسائل النصية',
                                        style: GoogleFonts.getFont(
                                          'Inter',
                                          fontWeight: FontWeight.w600,
                                          fontSize: 13,
                                          color: Color(0xFF979797),
                                        ),
                                      ),
                                      Positioned(
                                        right: 0,
                                        bottom: 0,
                                        child: Container(
                                          width: 20,
                                          height: 20,
                                          decoration: BoxDecoration(
                                            border: Border.all(color: Color(0xC9808080)),
                                            borderRadius: BorderRadius.circular(100),
                                            color: Color(0xFFFFFFFF),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    Container(
                      margin: EdgeInsets.fromLTRB(31.1, 0, 31.1, 0),
                      child: Align(
                        alignment: Alignment.topLeft,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            Container(
                              width: 328.6,
                              decoration: BoxDecoration(
                                border: Border.all(color: Color(0xFF979797)),
                                borderRadius: BorderRadius.circular(100),
                                color: Color(0xFFFFFFFF),
                              ),
                              child: Container(
                                width: 328.6,
                                padding: EdgeInsets.fromLTRB(0, 21.8, 0, 17.2),
                                child: Align(
                                  alignment: Alignment.topRight,
                                  child: SizedBox(
                                    width: 14.1,
                                    height: 9.7,
                                    child: SvgPicture.asset(
                                      'assets/vectors/group_9_x2.svg',
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'dart:ui';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:flutter_app/utils.dart';
import 'package:google_fonts/google_fonts.dart';

class Iphone131475 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return 
    Container(
      decoration: BoxDecoration(
        color: Color(0xFFFFFFFF),
      ),
      child: Stack(
        children: [
          Positioned(
            left: -112,
            top: -63,
            child: Container(
              width: 527,
              height: 166.3,
              decoration: BoxDecoration(
                boxShadow: [
                  BoxShadow(
                    color: Color(0x40000000),
                    offset: Offset(0, 1),
                    blurRadius: 2,
                  ),
                ],
              ),
              child: SvgPicture.asset(
                'assets/vectors/ellipse_226_x2.svg',
              ),
            ),
          ),
    Container(
            padding: EdgeInsets.fromLTRB(31, 24, 11.3, 65),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Container(
                  margin: EdgeInsets.fromLTRB(0, 0, 0, 105),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        margin: EdgeInsets.fromLTRB(0, 0, 0, 17),
                        width: 20,
                        height: 20,
                        child: Container(
                          decoration: BoxDecoration(
                            image: DecorationImage(
                              fit: BoxFit.cover,
                              image: AssetImage(
                                'assets/images/back.png',
                              ),
                            ),
                          ),
                          child: Container(
                            width: 20,
                            height: 20,
                          ),
                        ),
                      ),
                      Container(
                        margin: EdgeInsets.fromLTRB(0, 4, 0, 0),
                        child: Text(
                          'استشارة اسلامية',
                          style: GoogleFonts.getFont(
                            'Inter',
                            fontWeight: FontWeight.w700,
                            fontSize: 22,
                            height: 1.5,
                            color: Color(0xFF265073),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  margin: EdgeInsets.fromLTRB(10.7, 0, 10.7, 55),
                  child: Text(
                    'تفاصيل الخدمة  : ',
                    textAlign: TextAlign.center,
                    style: GoogleFonts.getFont(
                      'Inter',
                      fontWeight: FontWeight.w700,
                      fontSize: 20,
                      color: Color(0xFF18AEB1),
                    ),
                  ),
                ),
                Container(
                  margin: EdgeInsets.fromLTRB(24.7, 0, 24.7, 0),
                  child: SizedBox(
                    width: 301,
                    child: Stack(
                      children: [
                        Positioned(
                          left: -3,
                          top: -66,
                          child: SizedBox(
                            height: 36,
                            child: Text(
                              'بفضل هذه الخدمة و من خلال التواصل مع المفتيين الشرعيين  و المتخصصين في باب المالية الاسلامية يمكنك الحصول على اجابات  مضمونة و موثقة لتساؤلاتك الشرعية ...',
                              textAlign: TextAlign.right,
                              style: GoogleFonts.getFont(
                                'Inter',
                                fontWeight: FontWeight.w400,
                                fontSize: 10,
                                color: Color(0xFF000000),
                              ),
                            ),
                          ),
                        ),
                        SizedBox(
                          width: 301,
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                margin: EdgeInsets.fromLTRB(1, 0, 0, 32),
                                decoration: BoxDecoration(
                                  border: Border.all(color: Color(0xFF0B8688)),
                                  color: Color(0xFFFCFCFE),
                                ),
                                child: SizedBox(
                                  width: 300,
                                  child: Container(
                                    padding: EdgeInsets.fromLTRB(10, 10.4, 14, 15),
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Container(
                                          margin: EdgeInsets.fromLTRB(0, 3.6, 0, 0),
                                          width: 9,
                                          height: 9,
                                          child: SizedBox(
                                            width: 9,
                                            height: 9,
                                            child: SvgPicture.asset(
                                              'assets/vectors/vector_57_x2.svg',
                                            ),
                                          ),
                                        ),
                                        Container(
                                          margin: EdgeInsets.fromLTRB(0, 0, 0, 0.6),
                                          child: Text(
                                            'الخدمة الرئيسية ',
                                            style: GoogleFonts.getFont(
                                              'Inter',
                                              fontWeight: FontWeight.w700,
                                              fontSize: 10,
                                              color: Color(0xFF18AEB1),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                              Container(
                                margin: EdgeInsets.fromLTRB(1, 0, 0, 34),
                                decoration: BoxDecoration(
                                  border: Border.all(color: Color(0xFF0B8688)),
                                  color: Color(0xFFFCFCFE),
                                ),
                                child: SizedBox(
                                  width: 300,
                                  child: Container(
                                    padding: EdgeInsets.fromLTRB(10, 10.4, 14, 15),
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Container(
                                          margin: EdgeInsets.fromLTRB(0, 3.6, 0, 0),
                                          width: 9,
                                          height: 9,
                                          child: SizedBox(
                                            width: 9,
                                            height: 9,
                                            child: SvgPicture.asset(
                                              'assets/vectors/vector_110_x2.svg',
                                            ),
                                          ),
                                        ),
                                        Container(
                                          margin: EdgeInsets.fromLTRB(0, 0, 0, 0.6),
                                          child: Text(
                                            'الرسوم ',
                                            style: GoogleFonts.getFont(
                                              'Inter',
                                              fontWeight: FontWeight.w700,
                                              fontSize: 10,
                                              color: Color(0xFF18AEB1),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                              Container(
                                margin: EdgeInsets.fromLTRB(1, 0, 0, 29),
                                decoration: BoxDecoration(
                                  border: Border.all(color: Color(0xFF0B8688)),
                                  color: Color(0xFFFCFCFE),
                                ),
                                child: SizedBox(
                                  width: 300,
                                  child: Container(
                                    padding: EdgeInsets.fromLTRB(10, 10, 14, 15),
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Container(
                                          margin: EdgeInsets.fromLTRB(0, 4, 0, 0),
                                          width: 9,
                                          height: 9,
                                          child: SizedBox(
                                            width: 9,
                                            height: 9,
                                            child: SvgPicture.asset(
                                              'assets/vectors/vector_20_x2.svg',
                                            ),
                                          ),
                                        ),
                                        Container(
                                          margin: EdgeInsets.fromLTRB(0, 0, 0, 1),
                                          child: Text(
                                            'معدل الوقت اللازم لطلب الخدمة',
                                            style: GoogleFonts.getFont(
                                              'Inter',
                                              fontWeight: FontWeight.w700,
                                              fontSize: 10,
                                              color: Color(0xFF18AEB1),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                              Container(
                                margin: EdgeInsets.fromLTRB(0, 0, 1, 29),
                                decoration: BoxDecoration(
                                  border: Border.all(color: Color(0xFF0B8688)),
                                  color: Color(0xFFFCFCFE),
                                ),
                                child: SizedBox(
                                  width: 300,
                                  child: Container(
                                    padding: EdgeInsets.fromLTRB(10, 10, 14, 15),
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Container(
                                          margin: EdgeInsets.fromLTRB(0, 4, 0, 0),
                                          width: 9,
                                          height: 9,
                                          child: SizedBox(
                                            width: 9,
                                            height: 9,
                                            child: SvgPicture.asset(
                                              'assets/vectors/vector_121_x2.svg',
                                            ),
                                          ),
                                        ),
                                        Container(
                                          margin: EdgeInsets.fromLTRB(0, 0, 0, 1),
                                          child: Text(
                                            'معدل الوقت اللازم للحصول على الخدمة',
                                            style: GoogleFonts.getFont(
                                              'Inter',
                                              fontWeight: FontWeight.w700,
                                              fontSize: 10,
                                              color: Color(0xFF18AEB1),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                              Container(
                                margin: EdgeInsets.fromLTRB(1, 0, 0, 28),
                                decoration: BoxDecoration(
                                  border: Border.all(color: Color(0xFF0B8688)),
                                  color: Color(0xFFFCFCFE),
                                ),
                                child: SizedBox(
                                  width: 300,
                                  child: Container(
                                    padding: EdgeInsets.fromLTRB(10, 10, 14, 15),
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Container(
                                          margin: EdgeInsets.fromLTRB(0, 4, 0, 0),
                                          width: 9,
                                          height: 9,
                                          child: SizedBox(
                                            width: 9,
                                            height: 9,
                                            child: SvgPicture.asset(
                                              'assets/vectors/vector_70_x2.svg',
                                            ),
                                          ),
                                        ),
                                        Container(
                                          margin: EdgeInsets.fromLTRB(0, 0, 0, 1),
                                          child: Text(
                                            'ساعات توافر العمل  ',
                                            style: GoogleFonts.getFont(
                                              'Inter',
                                              fontWeight: FontWeight.w700,
                                              fontSize: 10,
                                              color: Color(0xFF18AEB1),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                              Container(
                                margin: EdgeInsets.fromLTRB(1, 0, 0, 27),
                                decoration: BoxDecoration(
                                  border: Border.all(color: Color(0xFF0B8688)),
                                  color: Color(0xFFFCFCFE),
                                ),
                                child: SizedBox(
                                  width: 300,
                                  child: Container(
                                    padding: EdgeInsets.fromLTRB(10, 10, 14, 15),
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Container(
                                          margin: EdgeInsets.fromLTRB(0, 4, 0, 0),
                                          width: 9,
                                          height: 9,
                                          child: SizedBox(
                                            width: 9,
                                            height: 9,
                                            child: SvgPicture.asset(
                                              'assets/vectors/vector_52_x2.svg',
                                            ),
                                          ),
                                        ),
                                        Container(
                                          margin: EdgeInsets.fromLTRB(0, 0, 0, 1),
                                          child: Text(
                                            'ساعات الاستفسار الهاتفي   ',
                                            style: GoogleFonts.getFont(
                                              'Inter',
                                              fontWeight: FontWeight.w700,
                                              fontSize: 10,
                                              color: Color(0xFF18AEB1),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                              Container(
                                margin: EdgeInsets.fromLTRB(1, 0, 0, 27),
                                decoration: BoxDecoration(
                                  border: Border.all(color: Color(0xFF0B8688)),
                                  color: Color(0xFFFCFCFE),
                                ),
                                child: SizedBox(
                                  width: 300,
                                  child: Container(
                                    padding: EdgeInsets.fromLTRB(10, 10, 14, 15),
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Container(
                                          margin: EdgeInsets.fromLTRB(0, 4, 0, 0),
                                          width: 9,
                                          height: 9,
                                          child: SizedBox(
                                            width: 9,
                                            height: 9,
                                            child: SvgPicture.asset(
                                              'assets/vectors/vector_27_x2.svg',
                                            ),
                                          ),
                                        ),
                                        Container(
                                          margin: EdgeInsets.fromLTRB(0, 0, 0, 1),
                                          child: Text(
                                            'ارقام هواتف طلب الخدمة',
                                            style: GoogleFonts.getFont(
                                              'Inter',
                                              fontWeight: FontWeight.w700,
                                              fontSize: 10,
                                              color: Color(0xFF18AEB1),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                              Container(
                                margin: EdgeInsets.fromLTRB(1, 0, 0, 0),
                                decoration: BoxDecoration(
                                  border: Border.all(color: Color(0xFF0B8688)),
                                  color: Color(0xFFFCFCFE),
                                ),
                                child: SizedBox(
                                  width: 300,
                                  child: Container(
                                    padding: EdgeInsets.fromLTRB(10, 10, 14, 15),
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Container(
                                          margin: EdgeInsets.fromLTRB(0, 4, 0, 0),
                                          width: 9,
                                          height: 9,
                                          child: SizedBox(
                                            width: 9,
                                            height: 9,
                                            child: SvgPicture.asset(
                                              'assets/vectors/vector_95_x2.svg',
                                            ),
                                          ),
                                        ),
                                        Container(
                                          margin: EdgeInsets.fromLTRB(0, 0, 0, 1),
                                          child: Text(
                                            'اللغات الموفرة ',
                                            style: GoogleFonts.getFont(
                                              'Inter',
                                              fontWeight: FontWeight.w700,
                                              fontSize: 10,
                                              color: Color(0xFF18AEB1),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
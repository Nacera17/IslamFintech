import 'package:flutter/material.dart';
import 'dart:ui';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:flutter_app/utils.dart';
import 'package:google_fonts/google_fonts.dart';

class Group25Default extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return 
    Container(
      padding: EdgeInsets.fromLTRB(0, 153.6, 5.7, 0),
      child: Stack(
        clipBehavior: Clip.none,
        children: [
          Container(
            width: 99.2,
            height: 56.1,
            child: Positioned(
              left: 7,
              top: -29,
              child: SizedBox(
                height: 29,
                child: Text(
                  'موافق',
                  style: GoogleFonts.getFont(
                    'Inter',
                    fontWeight: FontWeight.w400,
                    fontSize: 24,
                    color: Color(0xFF000000),
                  ),
                ),
              ),
            ),
          ),
          Positioned(
            left: 0,
            right: 0,
            top: 0,
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(15),
                color: Color(0xFFFFFFFF),
                boxShadow: [
                  BoxShadow(
                    color: Color(0x40000000),
                    offset: Offset(0, 4),
                    blurRadius: 2,
                  ),
                ],
              ),
              child: SizedBox(
                width: 336,
                height: 175,
                child: Container(
                  padding: EdgeInsets.fromLTRB(27.6, 0, 0, 0),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        margin: EdgeInsets.fromLTRB(59.8, 0, 0, 15.9),
                        child: Align(
                          alignment: Alignment.topCenter,
                          child: Text(
                            'ادخل الرمز',
                            style: GoogleFonts.getFont(
                              'Inter',
                              fontWeight: FontWeight.w400,
                              fontSize: 24,
                              color: Color(0xFFE97D40),
                            ),
                          ),
                        ),
                      ),
                      Align(
                        alignment: Alignment.topLeft,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              padding: EdgeInsets.fromLTRB(19.8, 14, 14.6, 9.2),
                              child: Text(
                                '8',
                                style: GoogleFonts.getFont(
                                  'Inter',
                                  fontWeight: FontWeight.w700,
                                  fontSize: 24,
                                  color: Color(0xFF757575),
                                ),
                              ),
                            ),
                            Container(
                              padding: EdgeInsets.fromLTRB(17.7, 14, 17.1, 9.2),
                              decoration: BoxDecoration(
                                border: Border.all(color: Color(0xFFDDDDDD)),
                                borderRadius: BorderRadius.circular(20),
                              ),
                              child: Text(
                                '5',
                                style: GoogleFonts.getFont(
                                  'Inter',
                                  fontWeight: FontWeight.w700,
                                  fontSize: 24,
                                  color: Color(0xFF757575),
                                ),
                              ),
                            ),
                            Container(
                              padding: EdgeInsets.fromLTRB(19.8, 14, 15.4, 9.2),
                              decoration: BoxDecoration(
                                border: Border.all(color: Color(0xFFFF8D4D)),
                                borderRadius: BorderRadius.circular(20),
                              ),
                              child: Text(
                                '2',
                                style: GoogleFonts.getFont(
                                  'Inter',
                                  fontWeight: FontWeight.w700,
                                  fontSize: 24,
                                  color: Color(0xFF757575),
                                ),
                              ),
                            ),
                            Container(
                              width: 50.3,
                              height: 52.2,
                              decoration: BoxDecoration(
                                border: Border.all(color: Color(0xFFDDDDDD)),
                                borderRadius: BorderRadius.circular(20),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
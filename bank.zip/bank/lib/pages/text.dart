import 'package:flutter/material.dart';
import 'dart:ui';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:flutter_app/utils.dart';
import 'package:google_fonts/google_fonts.dart';

class Text extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return 
    Container(
      decoration: BoxDecoration(
        color: Color(0xFFE6E6E6),
      ),
      child: Container(
        padding: EdgeInsets.fromLTRB(11.9, 29, 23, 0),
        child: RichText(
          textAlign: TextAlign.right,
          text: TextSpan(
            style: GoogleFonts.getFont(
              'Inter',
              fontWeight: FontWeight.w700,
              fontSize: 15,
              color: Color(0xFF000000),
            ),
            children: [
              TextSpan(
                text: 'ماهي المالية الإسلامية؟',
                style: GoogleFonts.getFont(
                  'Inter',
                  fontWeight: FontWeight.w700,
                  fontSize: 20,
                  height: 1.3,
                  color: Color(0xFF64CACB),
                ),
              ),
              TextSpan(
                text: ' ',
                style: GoogleFonts.getFont(
                  'Inter',
                  fontWeight: FontWeight.w400,
                  fontSize: 20,
                  height: 1.3,
                  color: Color(0xFF64CACB),
                ),
              ),
              TextSpan(
                text: ' المالية الإسلامية هي نظام شامل لإدارة الأموال يتوافق مع أحكام الشريعة الإسلامية. تهدف إلى تحقيق العدالة والمساواة والرفاهية للجميع من خلال تجنب الممارسات الربوية والمحرمة الأخرى.',
                style: GoogleFonts.getFont(
                  'Inter',
                  fontWeight: FontWeight.w400,
                  fontSize: 15,
                  height: 1.3,
                ),
              ),
              TextSpan(
                text: '  ',
                style: GoogleFonts.getFont(
                  'Inter',
                  fontWeight: FontWeight.w700,
                  fontSize: 15,
                  height: 1.3,
                ),
              ),
              TextSpan(
                text: 'مبادئ أساسية للمالية الإسلامية:',
                style: GoogleFonts.getFont(
                  'Inter',
                  fontWeight: FontWeight.w700,
                  fontSize: 20,
                  height: 1.3,
                  color: Color(0xFF64CACB),
                ),
              ),
              TextSpan(
                text: '',
                style: GoogleFonts.getFont(
                  'Inter',
                  fontWeight: FontWeight.w700,
                  fontSize: 15,
                  height: 1.3,
                ),
              ),
              TextSpan(
                text: 'الحظر على الربا: ',
                style: GoogleFonts.getFont(
                  'Inter',
                  fontWeight: FontWeight.w600,
                  fontSize: 17,
                  height: 1.3,
                  color: Color(0xFF265073),
                ),
              ),
              TextSpan(
                text: 'يُحظر الربا، وهو الفائدة على القروض، في الإسلام.',
                style: GoogleFonts.getFont(
                  'Inter',
                  fontWeight: FontWeight.w400,
                  fontSize: 15,
                  height: 1.3,
                ),
              ),
              TextSpan(
                text: 'المشاركة في المخاطر',
                style: GoogleFonts.getFont(
                  'Inter',
                  fontWeight: FontWeight.w600,
                  fontSize: 17,
                  height: 1.3,
                  color: Color(0xFF265073),
                ),
              ),
              TextSpan(
                text: ': ',
                style: GoogleFonts.getFont(
                  'Inter',
                  fontWeight: FontWeight.w600,
                  fontSize: 15,
                  height: 1.3,
                  color: Color(0xFF265073),
                ),
              ),
              TextSpan(
                text: 'يجب أن تشارك جميع الأطراف في المخاطر والأرباح في أي مشروع تجاري.',
                style: GoogleFonts.getFont(
                  'Inter',
                  fontWeight: FontWeight.w400,
                  fontSize: 15,
                  height: 1.3,
                ),
              ),
              TextSpan(
                text: 'تجنب الغرر: ',
                style: GoogleFonts.getFont(
                  'Inter',
                  fontWeight: FontWeight.w600,
                  fontSize: 17,
                  height: 1.3,
                  color: Color(0xFF265073),
                ),
              ),
              TextSpan(
                text: 'يجب تجنب أي غموض أو مخاطر غير ضرورية في المعاملات المالية.',
                style: GoogleFonts.getFont(
                  'Inter',
                  fontWeight: FontWeight.w400,
                  fontSize: 15,
                  height: 1.3,
                ),
              ),
              TextSpan(
                text: 'التجارة الحلال: ',
                style: GoogleFonts.getFont(
                  'Inter',
                  fontWeight: FontWeight.w600,
                  fontSize: 17,
                  height: 1.3,
                  color: Color(0xFF265073),
                ),
              ),
              TextSpan(
                text: 'يجب أن تكون جميع السلع والخدمات المتداولة حلالاً وفقًا للشريعة الإسلامية.',
                style: GoogleFonts.getFont(
                  'Inter',
                  fontWeight: FontWeight.w400,
                  fontSize: 15,
                  height: 1.3,
                ),
              ),
              TextSpan(
                text: 'العدالة والمساواة:',
                style: GoogleFonts.getFont(
                  'Inter',
                  fontWeight: FontWeight.w600,
                  fontSize: 17,
                  height: 1.3,
                  color: Color(0xFF265073),
                ),
              ),
              TextSpan(
                text: ' يجب أن تكون جميع المعاملات المالية عادلة وعادلة.',
                style: GoogleFonts.getFont(
                  'Inter',
                  fontWeight: FontWeight.w400,
                  fontSize: 15,
                  height: 1.3,
                ),
              ),
              TextSpan(
                text: ' مزايا المالية الإسلامية: ',
                style: GoogleFonts.getFont(
                  'Inter',
                  fontWeight: FontWeight.w700,
                  fontSize: 20,
                  height: 1.3,
                  color: Color(0xFF64CACB),
                ),
              ),
              TextSpan(
                text: '',
                style: GoogleFonts.getFont(
                  'Inter',
                  fontWeight: FontWeight.w400,
                  fontSize: 15,
                  height: 1.3,
                ),
              ),
              TextSpan(
                text: 'العدالة والمساواة:',
                style: GoogleFonts.getFont(
                  'Inter',
                  fontWeight: FontWeight.w600,
                  fontSize: 15,
                  height: 1.3,
                  color: Color(0xFF265073),
                ),
              ),
              TextSpan(
                text: ' تُقدم المالية الإسلامية نظامًا أكثر عدلاً وإنصافًا لإدارة الأموال.',
                style: GoogleFonts.getFont(
                  'Inter',
                  fontWeight: FontWeight.w400,
                  fontSize: 15,
                  height: 1.3,
                ),
              ),
              TextSpan(
                text: 'الاستقرار المالي:',
                style: GoogleFonts.getFont(
                  'Inter',
                  fontWeight: FontWeight.w600,
                  fontSize: 15,
                  height: 1.3,
                  color: Color(0xFF265073),
                ),
              ),
              TextSpan(
                text: ' تُساهم المالية الإسلامية في تحقيق الاستقرار المالي من خلال تجنب الممارسات الربوية المضاربة.',
                style: GoogleFonts.getFont(
                  'Inter',
                  fontWeight: FontWeight.w400,
                  fontSize: 15,
                  height: 1.3,
                ),
              ),
              TextSpan(
                text: ' التنمية الاقتصادية: ',
                style: GoogleFonts.getFont(
                  'Inter',
                  fontWeight: FontWeight.w600,
                  fontSize: 15,
                  height: 1.3,
                  color: Color(0xFF265073),
                ),
              ),
              TextSpan(
                text: 'تُعزز المالية الإسلامية التنمية الاقتصادية من خلال تشجيع الاستثمار الحلال.',
                style: GoogleFonts.getFont(
                  'Inter',
                  fontWeight: FontWeight.w400,
                  fontSize: 15,
                  height: 1.3,
                ),
              ),
              TextSpan(
                text: 'المسؤولية الاجتماعية: ',
                style: GoogleFonts.getFont(
                  'Inter',
                  fontWeight: FontWeight.w600,
                  fontSize: 15,
                  height: 1.3,
                  color: Color(0xFF265073),
                ),
              ),
              TextSpan(
                text: 'ت',
                style: GoogleFonts.getFont(
                  'Inter',
                  fontWeight: FontWeight.w400,
                  fontSize: 15,
                  height: 1.3,
                  color: Color(0xFF0E0E0E),
                ),
              ),
              TextSpan(
                text: 'شجع المالية الإسلامية على المسؤولية الاجتماعية من خلال حثّ الأفراد على استثمار أموالهم في مشاريع تفيد المجتمع.',
                style: GoogleFonts.getFont(
                  'Inter',
                  fontWeight: FontWeight.w400,
                  fontSize: 15,
                  height: 1.3,
                ),
              ),
              TextSpan(
                text: '',
                style: GoogleFonts.getFont(
                  'Inter',
                  fontWeight: FontWeight.w700,
                  fontSize: 15,
                  height: 1.3,
                ),
              ),
              TextSpan(
                text: ' الفرق بين المالية الإسلامية والتمويل التقليدي: ',
                style: GoogleFonts.getFont(
                  'Inter',
                  fontWeight: FontWeight.w700,
                  fontSize: 20,
                  height: 1.3,
                  color: Color(0xFF64CACB),
                ),
              ),
              TextSpan(
                text: '',
                style: GoogleFonts.getFont(
                  'Inter',
                  fontWeight: FontWeight.w700,
                  fontSize: 15,
                  height: 1.3,
                ),
              ),
              TextSpan(
                text: 'الربا',
                style: GoogleFonts.getFont(
                  'Inter',
                  fontWeight: FontWeight.w400,
                  fontSize: 15,
                  height: 1.3,
                  color: Color(0xFF0B8688),
                ),
              ),
              TextSpan(
                text: ':تُحظر الفائدة في المالية الإسلامية بينما هي مسموح بها في التمويل التقليدي.',
                style: GoogleFonts.getFont(
                  'Inter',
                  fontWeight: FontWeight.w400,
                  fontSize: 15,
                  height: 1.3,
                ),
              ),
              TextSpan(
                text: 'المشاركة في المخاطر',
                style: GoogleFonts.getFont(
                  'Inter',
                  fontWeight: FontWeight.w400,
                  fontSize: 15,
                  height: 1.3,
                  color: Color(0xFF0B8688),
                ),
              ),
              TextSpan(
                text: ': تُشجع المالية الإسلامية على مشاركة المخاطر بين جميع الأطراف بينما لا تُركز على ذلك التمويل التقليدي.',
                style: GoogleFonts.getFont(
                  'Inter',
                  fontWeight: FontWeight.w400,
                  fontSize: 15,
                  height: 1.3,
                ),
              ),
              TextSpan(
                text: 'الغرر',
                style: GoogleFonts.getFont(
                  'Inter',
                  fontWeight: FontWeight.w400,
                  fontSize: 15,
                  height: 1.3,
                  color: Color(0xFF0B8688),
                ),
              ),
              TextSpan(
                text: ': تُحذر المالية الإسلامية من الغرر والمخاطر غير المبررة بينما قد لا تولي التمويل التقليدي اهتمامًا كبيرًا بذلك.',
                style: GoogleFonts.getFont(
                  'Inter',
                  fontWeight: FontWeight.w400,
                  fontSize: 15,
                  height: 1.3,
                ),
              ),
              TextSpan(
                text: 'المنتجات المالية: ',
                style: GoogleFonts.getFont(
                  'Inter',
                  fontWeight: FontWeight.w400,
                  fontSize: 15,
                  height: 1.3,
                  color: Color(0xFF0B8A8C),
                ),
              ),
              TextSpan(
                text: 'تختلف المنتجات المالية الإسلامية عن المنتجات المالية التقليدية في هيكلها وأحكامها.  ',
                style: GoogleFonts.getFont(
                  'Inter',
                  fontWeight: FontWeight.w400,
                  fontSize: 15,
                  height: 1.3,
                ),
              ),
              TextSpan(
                text: 'البنوك الإسلامية:  ',
                style: GoogleFonts.getFont(
                  'Inter',
                  fontWeight: FontWeight.w700,
                  fontSize: 20,
                  height: 1.3,
                  color: Color(0xFF64CACB),
                ),
              ),
              TextSpan(
                text: '',
                style: GoogleFonts.getFont(
                  'Inter',
                  fontWeight: FontWeight.w700,
                  fontSize: 15,
                  height: 1.3,
                ),
              ),
              TextSpan(
                text: '''هي مؤسسات تسعى إلى التخلي عن سعر الفائدة، وإتباع قواعد الشريعة الإسلامية كأساس للتعامل بينها و بين عملائها، سواء من جانب قبول الودائع أو توظيف هذه الودائع في الاستخدامات المختلفة في النشاط الاقتصاد
البنوك الإسلامية هي مؤسسات مالية مصرفية لتجميع الأموال و توظيفها في نطاق الشريعة الإسلامية بما يخدم المجتمع. التكافل الإسلامي وتحقيق عدالة التوزيع ووضع المال في مسار إسلامي معا لالتزام بعدم التعامل بالفوائد الربوبية أخذا و عطاءا ، و باجتناب أي عمل مخالف لأحكام الشريعة الإسلامية.
البنوك الإسلامية هي مؤسسات تراعي في وظائفها و أهدافها بقواعد الشريعة الإسلامية في المعاملات المالية و التجارية و المدنية.
البنوك الإسلامية هي مؤسسات مصرفية لا تتعامل بالفائدة أخذا أو عطاء، فالبنك الإسلامي ينبغي أن يتلقى من العملاء نقودهم دون أي التزام أو تعهد مباشر أو غير مباشر بإعطاء عائد ثابت على ودائعهم مع ضمان رد الأصل لهم عند الطلب''',
                style: GoogleFonts.getFont(
                  'Inter',
                  fontWeight: FontWeight.w400,
                  fontSize: 15,
                  height: 1.3,
                ),
              ),

            ],
          ),
        ),
      ),
    );
  }
}
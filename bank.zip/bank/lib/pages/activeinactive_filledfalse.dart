import 'package:flutter/material.dart';
import 'dart:ui';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:flutter_app/utils.dart';
import 'package:google_fonts/google_fonts.dart';

class ActiveinactiveFilledfalse extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return 
    Container(
      child: Container(
        decoration: BoxDecoration(
          border: Border.all(color: Color(0xFF979797)),
          borderRadius: BorderRadius.circular(100),
          color: Color(0xFFFFFFFF),
        ),
        child: Container(
          width: double.infinity,
          padding: EdgeInsets.fromLTRB(213.3, 15.9, 0, 18.9),
          child: Text(
            'الاسم',
            style: GoogleFonts.getFont(
              'Inter',
              fontWeight: FontWeight.w400,
              fontSize: 15,
              color: Color(0xFF000000),
            ),
          ),
        ),
      ),
    );
  }
}
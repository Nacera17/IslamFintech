import 'package:flutter/material.dart';
import 'dart:ui';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:flutter_app/utils.dart';
import 'package:google_fonts/google_fonts.dart';

// class Iphone131440 extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     return
//     Container(
//       decoration: BoxDecoration(
//         gradient: LinearGradient(
//           begin: Alignment(0, -1),
//           end: Alignment(0, 1),
//           colors: <Color>[Color(0xFF74FDFF), Color(0xFF265073)],
//           stops: <double>[0.085, 1],
//         ),
//       ),
//       child: Container(
//         padding: EdgeInsets.fromLTRB(0, 188, 0, 0),
//         child: Container(
//           decoration: BoxDecoration(
//             borderRadius: BorderRadius.circular(100),
//             image: DecorationImage(
//               fit: BoxFit.cover,
//               image: AssetImage(
//                 'assets/images/photo_6050789268961478011_xremovebg_preview_3.png',
//               ),
//             ),
//             boxShadow: [
//               BoxShadow(
//                 color: Color(0xFFFFFFFF),
//                 offset: Offset(1, 5),
//                 blurRadius: 25,
//               ),
//             ],
//           ),
//           child: Container(
//             width: 100,
//             height: 100,
//           ),
//         ),
//       ),
//     );
//   }
// }

class Iphone131440 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment(0, -1),
          end: Alignment(0, 1),
          colors: <Color>[Color(0xFF74FDFF), Color(0xFF265073)],
          stops: <double>[0.085, 1],
        ),
      ),
      child: Container(
        padding: EdgeInsets.fromLTRB(0, 188, 0, 0),
        child: Container(
          width: 100,
          height: 100,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(100),
            image: DecorationImage(
              fit: BoxFit.cover,
              image: AssetImage(
                'assets/images/photo_6050789268961478011_xremovebg_preview_3.png',
              ),
            ),
            boxShadow: [
              BoxShadow(
                color: Color(0xFFFFFFFF),
                offset: Offset(1, 5),
                blurRadius: 25,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

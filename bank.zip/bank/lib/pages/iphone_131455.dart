import 'package:flutter/material.dart';
import 'dart:ui';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:flutter_app/utils.dart';
import 'package:google_fonts/google_fonts.dart';

class Iphone131455 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return 
    Container(
      decoration: BoxDecoration(
        color: Color(0xFFFFFFFF),
      ),
      child: Stack(
        children: [
          Positioned(
            left: -1257.5,
            top: 579.9,
            child: SizedBox(
              width: 557,
              height: 242.1,
              child: SvgPicture.asset(
                'assets/vectors/vector_22_x2.svg',
              ),
            ),
          ),
          Positioned(
            left: -73.2,
            top: 748,
            child: Transform.rotate(
              angle: -0.7374045709,
              child: SizedBox(
                width: 169.4,
                height: 167.4,
                child: SvgPicture.asset(
                  'assets/vectors/ellipse_2849_x2.svg',
                ),
              ),
            ),
          ),
          Positioned(
            left: -103,
            top: 696,
            child: Transform.rotate(
              angle: -0.7374045709,
              child: SizedBox(
                width: 169.4,
                height: 167.4,
                child: SvgPicture.asset(
                  'assets/vectors/ellipse_2937_x2.svg',
                ),
              ),
            ),
          ),
    Container(
            padding: EdgeInsets.fromLTRB(22, 15, 22, 66),
            child: Stack(
              clipBehavior: Clip.none,
              children: [
                SizedBox(
                  width: 327,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        margin: EdgeInsets.fromLTRB(0, 0, 2, 743),
                        width: 20,
                        height: 20,
                        child: Container(
                          decoration: BoxDecoration(
                            image: DecorationImage(
                              fit: BoxFit.cover,
                              image: AssetImage(
                                'assets/images/back.png',
                              ),
                            ),
                          ),
                          child: Container(
                            width: 20,
                            height: 20,
                          ),
                        ),
                      ),
                      Container(
                        margin: EdgeInsets.fromLTRB(0, 53, 0, 0),
                        child: Container(
                          decoration: BoxDecoration(
                            color: Color(0xFFFFFFFF),
                            borderRadius: BorderRadius.only(
                              topRight: Radius.circular(36),
                              bottomLeft: Radius.circular(67),
                            ),
                          ),
                          child: SizedBox(
                            width: 305,
                            child: Container(
                              padding: EdgeInsets.fromLTRB(15, 9, 15, 106),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    margin: EdgeInsets.fromLTRB(0, 0, 13.3, 21),
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.start,
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Container(
                                          margin: EdgeInsets.fromLTRB(0, 0, 13.3, 0),
                                          decoration: BoxDecoration(
                                            borderRadius: BorderRadius.circular(100),
                                            image: DecorationImage(
                                              fit: BoxFit.cover,
                                              image: AssetImage(
                                                'assets/images/photo_6050789268961478011_xremovebg_preview_3.png',
                                              ),
                                            ),
                                            boxShadow: [
                                              BoxShadow(
                                                color: Color(0xFFFFFFFF),
                                                offset: Offset(1, 5),
                                                blurRadius: 25,
                                              ),
                                            ],
                                          ),
                                          child: Container(
                                            width: 50,
                                            height: 50,
                                          ),
                                        ),
                                        Container(
                                          margin: EdgeInsets.fromLTRB(0, 16, 0, 16),
                                          child: Text(
                                            'ISLAM-FINTECH',
                                            style: GoogleFonts.getFont(
                                              'Inter',
                                              fontWeight: FontWeight.w700,
                                              fontSize: 15,
                                              color: Color(0xFF000000),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Container(
                                    margin: EdgeInsets.fromLTRB(1, 0, 0, 17),
                                    child: Text(
                                      'افتح حسابك  المصرفي',
                                      style: GoogleFonts.getFont(
                                        'Inter',
                                        fontWeight: FontWeight.w700,
                                        fontSize: 15,
                                        color: Color(0xFF000000),
                                      ),
                                    ),
                                  ),
                                  Container(
                                    margin: EdgeInsets.fromLTRB(2, 0, 0, 56),
                                    child: Text(
                                      'خلال بضع دقائق ! ',
                                      textAlign: TextAlign.center,
                                      style: GoogleFonts.getFont(
                                        'Inter',
                                        fontWeight: FontWeight.w700,
                                        fontSize: 15,
                                        color: Color(0xFF18AEB1),
                                      ),
                                    ),
                                  ),
                                  Container(
                                    margin: EdgeInsets.fromLTRB(0, 0, 0, 92),
                                    child: Align(
                                      alignment: Alignment.topRight,
                                      child: SizedBox(
                                        width: 250,
                                        height: 250,
                                        child: SvgPicture.asset(
                                          'assets/vectors/undraw_time_management_re_tk_5_w_12_x2.svg',
                                        ),
                                      ),
                                    ),
                                  ),
                                  Container(
                                    decoration: BoxDecoration(
                                      border: Border.all(color: Color(0xFF333333)),
                                      borderRadius: BorderRadius.circular(100),
                                      color: Color(0xFFFFFFFF),
                                    ),
                                    child: Container(
                                      padding: EdgeInsets.fromLTRB(15.9, 17.5, 15.9, 17.5),
                                      child: Text(
                                        'افتح حسابك المصرفي',
                                        style: GoogleFonts.getFont(
                                          'Inter',
                                          fontWeight: FontWeight.w700,
                                          fontSize: 15,
                                          color: Color(0xFF0B8688),
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Positioned(
                  right: -89.2,
                  top: -68,
                  child: SizedBox(
                    width: 169.4,
                    height: 167.4,
                    child: SvgPicture.asset(
                      'assets/vectors/container_5_x2.svg',
                    ),
                  ),
                ),
                Positioned(
                  right: -320,
                  top: -763,
                  child: Container(
                    decoration: BoxDecoration(
                      color: Color(0xFFFFFFFF),
                      borderRadius: BorderRadius.only(
                        topRight: Radius.circular(36),
                        bottomLeft: Radius.circular(67),
                      ),
                    ),
                    child: SizedBox(
                      width: 305,
                      height: 710,
                      child: Container(
                        padding: EdgeInsets.fromLTRB(14.1, 25, 0, 0),
                        child: Stack(
                          clipBehavior: Clip.none,
                          children: [
                            Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: [
                                Container(
                                  margin: EdgeInsets.fromLTRB(0, 0, 0, 37),
                                  child: Text(
                                    'ISLAM-FINTECH',
                                    style: GoogleFonts.getFont(
                                      'Inter',
                                      fontWeight: FontWeight.w700,
                                      fontSize: 15,
                                      color: Color(0xFF000000),
                                    ),
                                  ),
                                ),
                                Container(
                                  margin: EdgeInsets.fromLTRB(0, 0, 13.1, 0),
                                  child: Text(
                                    'افتح حسابك  المصرفي',
                                    textAlign: TextAlign.center,
                                    style: GoogleFonts.getFont(
                                      'Inter',
                                      fontWeight: FontWeight.w700,
                                      fontSize: 15,
                                      color: Color(0xFF000000),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            Positioned(
                              top: 90,
                              child: SizedBox(
                                height: 36,
                                child: Text(
                                  'خلال بضع دقائق ',
                                  textAlign: TextAlign.center,
                                  style: GoogleFonts.getFont(
                                    'Inter',
                                    fontWeight: FontWeight.w700,
                                    fontSize: 15,
                                    color: Color(0xFF18AEB1),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
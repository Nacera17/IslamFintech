import 'package:flutter/material.dart';
import 'dart:ui';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:flutter_app/utils.dart';
import 'package:google_fonts/google_fonts.dart';

class Frame15385 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return 
    Container(
      decoration: BoxDecoration(
        color: Color(0xFFFFFFFF),
        borderRadius: BorderRadius.circular(30),
      ),
      child: Container(
        padding: EdgeInsets.fromLTRB(0, 16, 21.5, 24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              margin: EdgeInsets.fromLTRB(26.5, 0, 0, 14),
              child: Text(
                'اخر مرحلة ',
                style: GoogleFonts.getFont(
                  'Inter',
                  fontWeight: FontWeight.w700,
                  fontSize: 15,
                  color: Color(0xFF000000),
                ),
              ),
            ),
            Container(
              margin: EdgeInsets.fromLTRB(0, 0, 0, 41),
              child: Text(
                'أوافق على صحة المعلومات المقدمة ومطابقتها',
                style: GoogleFonts.getFont(
                  'Inter',
                  fontWeight: FontWeight.w700,
                  fontSize: 10,
                  color: Color(0xFF000000),
                ),
              ),
            ),
            Container(
              margin: EdgeInsets.fromLTRB(32.5, 0, 0, 16),
              decoration: BoxDecoration(
                border: Border.all(color: Color(0xFF0B8688)),
                borderRadius: BorderRadius.circular(15),
                color: Color(0xFF0B8688),
              ),
              child: Container(
                width: 130,
                padding: EdgeInsets.fromLTRB(11, 1, 0, 1),
                child: Text(
                  'اكمل ',
                  style: GoogleFonts.getFont(
                    'Inter',
                    fontWeight: FontWeight.w700,
                    fontSize: 15,
                    color: Color(0xFFFFFFFF),
                  ),
                ),
              ),
            ),
            Container(
              margin: EdgeInsets.fromLTRB(32.5, 0, 0, 0),
              decoration: BoxDecoration(
                border: Border.all(color: Color(0xFF0B8688)),
                borderRadius: BorderRadius.circular(15),
                color: Color(0xFF0B8688),
              ),
              child: Container(
                width: 130,
                padding: EdgeInsets.fromLTRB(11, 1, 0, 1),
                child: Text(
                  'الغاء',
                  style: GoogleFonts.getFont(
                    'Inter',
                    fontWeight: FontWeight.w700,
                    fontSize: 15,
                    color: Color(0xFFFFFFFF),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
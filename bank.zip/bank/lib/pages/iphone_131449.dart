import 'package:flutter/material.dart';
import 'dart:ui';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:flutter_app/utils.dart';
import 'package:google_fonts/google_fonts.dart';

class Iphone131449 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return 
    Container(
      decoration: BoxDecoration(
        color: Color(0xFFFFFFFF),
      ),
      child: Stack(
        children: [
          Positioned(
            left: 31,
            top: 409,
            child: SizedBox(
              width: 22,
              height: 19,
              child: SvgPicture.asset(
                'assets/vectors/vector_137_x2.svg',
              ),
            ),
          ),
          Positioned(
            left: -1271.5,
            top: 591.9,
            child: SizedBox(
              width: 557,
              height: 242.1,
              child: SvgPicture.asset(
                'assets/vectors/vector_236_x2.svg',
              ),
            ),
          ),
          Positioned(
            left: -87.2,
            top: 760,
            child: Transform.rotate(
              angle: -0.7374045709,
              child: SizedBox(
                width: 169.4,
                height: 167.4,
                child: SvgPicture.asset(
                  'assets/vectors/ellipse_2830_x2.svg',
                ),
              ),
            ),
          ),
          Positioned(
            left: -117,
            top: 708,
            child: Transform.rotate(
              angle: -0.7374045709,
              child: SizedBox(
                width: 169.4,
                height: 167.4,
                child: SvgPicture.asset(
                  'assets/vectors/ellipse_2916_x2.svg',
                ),
              ),
            ),
          ),
    Container(
            padding: EdgeInsets.fromLTRB(36, 3, 21.9, 0),
            child: Stack(
              clipBehavior: Clip.none,
              children: [
                SizedBox(
                  width: double.infinity,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        margin: EdgeInsets.fromLTRB(8.9, 0, 8.9, 272),
                        child: Align(
                          alignment: Alignment.topLeft,
                          child: Container(
                            width: 22,
                            height: 19,
                            child: SizedBox(
                              width: 22,
                              height: 19,
                              child: SvgPicture.asset(
                                'assets/vectors/vector_80_x2.svg',
                              ),
                            ),
                          ),
                        ),
                      ),
                      Container(
                        margin: EdgeInsets.fromLTRB(0, 0, 4.1, 53),
                        decoration: BoxDecoration(
                          border: Border.all(color: Color(0xFF979797)),
                          borderRadius: BorderRadius.circular(100),
                          color: Color(0xFFFFFFFF),
                        ),
                        child: Container(
                          padding: EdgeInsets.fromLTRB(22, 16, 22, 16),
                          child: Text(
                            'اسم المستخدم',
                            style: GoogleFonts.getFont(
                              'Inter',
                              fontWeight: FontWeight.w400,
                              fontSize: 15,
                              color: Color(0xFF000000),
                            ),
                          ),
                        ),
                      ),
                      Container(
                        margin: EdgeInsets.fromLTRB(3, 0, 1.1, 52),
                        decoration: BoxDecoration(
                          border: Border.all(color: Color(0xFF979797)),
                          borderRadius: BorderRadius.circular(100),
                          color: Color(0xFFFFFFFF),
                        ),
                        child: Container(
                          padding: EdgeInsets.fromLTRB(21, 16, 31, 16),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                width: 22,
                                height: 18,
                                child: SizedBox(
                                  width: 22,
                                  height: 18,
                                  child: SvgPicture.asset(
                                    'assets/vectors/vector_56_x2.svg',
                                  ),
                                ),
                              ),
                              Text(
                                'كلمة السر',
                                style: GoogleFonts.getFont(
                                  'Inter',
                                  fontWeight: FontWeight.w400,
                                  fontSize: 15,
                                  color: Color(0xFF000000),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      Container(
                        margin: EdgeInsets.fromLTRB(0, 0, 0, 91),
                        child: Align(
                          alignment: Alignment.topRight,
                          child: Text(
                            'هل نسيت كلمة السر  ؟',
                            style: GoogleFonts.getFont(
                              'Inter',
                              fontWeight: FontWeight.w400,
                              fontSize: 15,
                              color: Color(0x8F333333),
                            ),
                          ),
                        ),
                      ),
                      Container(
                        margin: EdgeInsets.fromLTRB(0, 0, 27.1, 0),
                        child: Align(
                          alignment: Alignment.topCenter,
                          child: Container(
                            decoration: BoxDecoration(
                              border: Border.all(color: Color(0xFF333333)),
                              borderRadius: BorderRadius.circular(100),
                              color: Color(0xFFFFFFFF),
                            ),
                            child: Container(
                              width: 225,
                              padding: EdgeInsets.fromLTRB(0, 17.5, 0, 17.5),
                              child: Text(
                                'تسجيل الدخول',
                                style: GoogleFonts.getFont(
                                  'Inter',
                                  fontWeight: FontWeight.w700,
                                  fontSize: 15,
                                  color: Color(0xFF0B8688),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Positioned(
                  right: -118.3,
                  top: -52,
                  child: SizedBox(
                    width: 522.4,
                    height: 237.2,
                    child: SvgPicture.asset(
                      'assets/vectors/container_9_x2.svg',
                    ),
                  ),
                ),
                Positioned(
                  left: -16,
                  top: 18,
                  child: Container(
                    width: 20,
                    height: 20,
                    child: Container(
                      decoration: BoxDecoration(
                        image: DecorationImage(
                          fit: BoxFit.cover,
                          image: AssetImage(
                            'assets/images/back.png',
                          ),
                        ),
                      ),
                      child: Container(
                        width: 20,
                        height: 20,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
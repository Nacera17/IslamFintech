import 'package:flutter/material.dart';
import 'dart:ui';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:flutter_app/utils.dart';
import 'package:google_fonts/google_fonts.dart';

class StateVariant21 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return 
    Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          margin: EdgeInsets.fromLTRB(0, 0, 8.4, 0),
          child: Text(
            'Option',
            style: GoogleFonts.getFont(
              'Inter',
              fontWeight: FontWeight.w600,
              fontSize: 20,
              color: Color(0xC9808080),
            ),
          ),
        ),
        Expanded(
          child: Container(
            margin: EdgeInsets.fromLTRB(0, 2, 0, 2),
            height: 20,
            child: Container(
              decoration: BoxDecoration(
                border: Border.all(color: Color(0xC9808080)),
                borderRadius: BorderRadius.circular(100),
                color: Color(0xFFFFFFFF),
              ),
              child: Container(
                width: 20,
                height: 20,
              ),
            ),
          ),
        ),
      ],
    );
  }
}
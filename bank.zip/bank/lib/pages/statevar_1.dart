import 'package:flutter/material.dart';
import 'dart:ui';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:flutter_app/utils.dart';
import 'package:google_fonts/google_fonts.dart';

class Statevar1 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return 
    Container(
      child: Container(
        decoration: BoxDecoration(
          border: Border.all(color: Color(0xFF000000)),
          borderRadius: BorderRadius.circular(100),
          color: Color(0xFFF5F5F5),
        ),
        child: Container(
          width: double.infinity,
          padding: EdgeInsets.fromLTRB(16, 18, 16, 18),
          child: Text(
            'ادخل اسمك',
            style: GoogleFonts.getFont(
              'Inter',
              fontWeight: FontWeight.w700,
              fontSize: 15,
              color: Color(0xFF000000),
            ),
          ),
        ),
      ),
    );
  }
}
import 'package:flutter/material.dart';
import 'dart:ui';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:flutter_app/utils.dart';
import 'package:google_fonts/google_fonts.dart';

class Property1Variant23 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return 
    Column(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        Container(
          margin: EdgeInsets.fromLTRB(16, 0, 16, 15),
          child: Text(
            'الاسم',
            style: GoogleFonts.getFont(
              'Inter',
              fontWeight: FontWeight.w400,
              fontSize: 14,
              color: Color(0xFF000000),
            ),
          ),
        ),
        Container(
          decoration: BoxDecoration(
            border: Border.all(color: Color(0xFF64CACB)),
            borderRadius: BorderRadius.circular(100),
            color: Color(0xFFFFFFFF),
          ),
          child: Container(
            height: 38,
            padding: EdgeInsets.fromLTRB(27.9, 9.2, 27.9, 26.8),
            child: Transform.rotate(
              angle: 1.5540411652,
              child: Container(
                decoration: BoxDecoration(
                  color: Color(0xFF000000),
                ),
                child: Container(
                  width: 0.3,
                  height: 1,
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }
}
import 'package:flutter/material.dart';
import 'dart:ui';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:flutter_app/utils.dart';
import 'package:google_fonts/google_fonts.dart';

class Iphone131477 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return 
    Container(
      decoration: BoxDecoration(
        color: Color(0xFFFFFFFF),
      ),
      child: Stack(
        children: [
          Positioned(
            right: -268,
            top: -128,
            child: Transform.rotate(
              angle: -0.7374045709,
              child: SizedBox(
                width: 376,
                height: 210.9,
                child: SvgPicture.asset(
                  'assets/vectors/ellipse_24_x2.svg',
                ),
              ),
            ),
          ),
          Positioned(
            left: -1263.5,
            top: 569.9,
            child: SizedBox(
              width: 557,
              height: 242.1,
              child: SvgPicture.asset(
                'assets/vectors/vector_246_x2.svg',
              ),
            ),
          ),
          Positioned(
            left: -79.2,
            top: 738,
            child: Transform.rotate(
              angle: -0.7374045709,
              child: SizedBox(
                width: 169.4,
                height: 167.4,
                child: SvgPicture.asset(
                  'assets/vectors/ellipse_287_x2.svg',
                ),
              ),
            ),
          ),
    Container(
            padding: EdgeInsets.fromLTRB(28, 25, 25, 81),
            child: Stack(
              clipBehavior: Clip.none,
              children: [
                SizedBox(
                  width: double.infinity,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        margin: EdgeInsets.fromLTRB(2, 0, 2, 46),
                        child: Align(
                          alignment: Alignment.topLeft,
                          child: SizedBox(
                            width: 227,
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  margin: EdgeInsets.fromLTRB(0, 0, 57, 135),
                                  width: 20,
                                  height: 20,
                                  child: Container(
                                    decoration: BoxDecoration(
                                      image: DecorationImage(
                                        fit: BoxFit.cover,
                                        image: AssetImage(
                                          'assets/images/back.png',
                                        ),
                                      ),
                                    ),
                                    child: Container(
                                      width: 20,
                                      height: 20,
                                    ),
                                  ),
                                ),
                                Container(
                                  margin: EdgeInsets.fromLTRB(0, 10, 0, 0),
                                  child: SizedBox(
                                    width: 150,
                                    height: 145,
                                    child: SvgPicture.asset(
                                      'assets/vectors/group_6_x2.svg',
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                      Container(
                        margin: EdgeInsets.fromLTRB(0, 0, 0, 50),
                        child: Container(
                          padding: EdgeInsets.fromLTRB(0, 0, 2, 0),
                          child: Stack(
                            clipBehavior: Clip.none,
                            children: [
                              SizedBox(
                                width: double.infinity,
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Container(
                                      margin: EdgeInsets.fromLTRB(0, 0, 4, 24),
                                      decoration: BoxDecoration(
                                        border: Border.all(color: Color(0xFF18AEB1)),
                                        borderRadius: BorderRadius.circular(10),
                                        color: Color(0xFFFFFFFF),
                                      ),
                                      child: Container(
                                        padding: EdgeInsets.fromLTRB(0, 15.5, 16.4, 11.5),
                                        child: Row(
                                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Container(
                                              margin: EdgeInsets.fromLTRB(0, 0, 0, 4),
                                              child: Text(
                                                'اسم المستخدم',
                                                style: GoogleFonts.getFont(
                                                  'Inter',
                                                  fontWeight: FontWeight.w400,
                                                  fontSize: 15,
                                                  color: Color(0xFF000000),
                                                ),
                                              ),
                                            ),
                                            Container(
                                              margin: EdgeInsets.fromLTRB(0, 2, 0, 0),
                                              child: Container(
                                                decoration: BoxDecoration(
                                                  image: DecorationImage(
                                                    fit: BoxFit.cover,
                                                    image: AssetImage(
                                                      'assets/images/user.png',
                                                    ),
                                                  ),
                                                ),
                                                child: Container(
                                                  width: 20,
                                                  height: 20,
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                    Container(
                                      margin: EdgeInsets.fromLTRB(2, 0, 2, 29),
                                      decoration: BoxDecoration(
                                        border: Border.all(color: Color(0xFF18AEB1)),
                                        borderRadius: BorderRadius.circular(10),
                                        color: Color(0xFFFFFFFF),
                                      ),
                                      child: Container(
                                        padding: EdgeInsets.fromLTRB(0, 13.5, 18.5, 11.5),
                                        child: Row(
                                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Container(
                                              margin: EdgeInsets.fromLTRB(0, 0, 0, 6),
                                              child: Text(
                                                'Abc@Abc.com',
                                                style: GoogleFonts.getFont(
                                                  'Inter',
                                                  fontWeight: FontWeight.w400,
                                                  fontSize: 15,
                                                  decoration: TextDecoration.underline,
                                                  color: Color(0xFF000000),
                                                  decorationColor: Color(0xFF000000),
                                                ),
                                              ),
                                            ),
                                            Container(
                                              margin: EdgeInsets.fromLTRB(0, 4, 0, 0),
                                              child: Container(
                                                decoration: BoxDecoration(
                                                  image: DecorationImage(
                                                    fit: BoxFit.cover,
                                                    image: AssetImage(
                                                      'assets/images/mail.png',
                                                    ),
                                                  ),
                                                ),
                                                child: Container(
                                                  width: 20,
                                                  height: 20,
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                    Container(
                                      margin: EdgeInsets.fromLTRB(3, 0, 1, 55),
                                      decoration: BoxDecoration(
                                        border: Border.all(color: Color(0xFF18AEB1)),
                                        borderRadius: BorderRadius.circular(10),
                                        color: Color(0xFFFFFFFF),
                                      ),
                                      child: Container(
                                        padding: EdgeInsets.fromLTRB(0, 13.5, 19.5, 14.5),
                                        child: Row(
                                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Container(
                                              margin: EdgeInsets.fromLTRB(0, 3, 9, 0),
                                              child: SizedBox(
                                                width: 147,
                                                child: Text(
                                                  '+ 213 645 Xxxxxx',
                                                  style: GoogleFonts.getFont(
                                                    'Inter',
                                                    fontWeight: FontWeight.w400,
                                                    fontSize: 15,
                                                    color: Color(0xFF000000),
                                                  ),
                                                ),
                                              ),
                                            ),
                                            Container(
                                              margin: EdgeInsets.fromLTRB(0, 0, 0, 1),
                                              child: Container(
                                                decoration: BoxDecoration(
                                                  image: DecorationImage(
                                                    fit: BoxFit.cover,
                                                    image: AssetImage(
                                                      'assets/images/phone_receiver_silhouette.png',
                                                    ),
                                                  ),
                                                ),
                                                child: Container(
                                                  width: 20,
                                                  height: 20,
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                    Container(
                                      margin: EdgeInsets.fromLTRB(4, 0, 0, 18),
                                      decoration: BoxDecoration(
                                        border: Border.all(color: Color(0xFF18AEB1)),
                                        borderRadius: BorderRadius.circular(10),
                                        color: Color(0xFFFFFFFF),
                                      ),
                                      child: Container(
                                        padding: EdgeInsets.fromLTRB(0, 15.5, 20.5, 79.5),
                                        child: Row(
                                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Container(
                                              margin: EdgeInsets.fromLTRB(0, 0, 0, 2),
                                              child: Text(
                                                'نص السؤال',
                                                style: GoogleFonts.getFont(
                                                  'Inter',
                                                  fontWeight: FontWeight.w400,
                                                  fontSize: 15,
                                                  color: Color(0xFF000000),
                                                ),
                                              ),
                                            ),
                                            Container(
                                              decoration: BoxDecoration(
                                                image: DecorationImage(
                                                  fit: BoxFit.cover,
                                                  image: AssetImage(
                                                    'assets/images/question_mark.png',
                                                  ),
                                                ),
                                              ),
                                              child: Container(
                                                width: 20,
                                                height: 20,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                    Container(
                                      margin: EdgeInsets.fromLTRB(1, 0, 1, 0),
                                      child: Align(
                                        alignment: Alignment.topLeft,
                                        child: Container(
                                          width: 89,
                                          decoration: BoxDecoration(
                                            border: Border(
                                              right: BorderSide(
                                                color: Color(0xFF000000),
                                                width: 1,
                                              ),
                                            ),
                                          ),
                                          child: Container(
                                            padding: EdgeInsets.fromLTRB(1.3, 16, 0, 16),
                                            child: Stack(
                                              clipBehavior: Clip.none,
                                              children: [
                                                Text(
                                                  'ادخل',
                                                  style: GoogleFonts.getFont(
                                                    'Inter',
                                                    fontWeight: FontWeight.w400,
                                                    fontSize: 15,
                                                    color: Color(0xAD979797),
                                                  ),
                                                ),
                                                Positioned(
                                                  right: -189,
                                                  bottom: -16,
                                                  child: Container(
                                                    decoration: BoxDecoration(
                                                      color: Color(0xFF898A8D),
                                                    ),
                                                    child: Container(
                                                      width: 189,
                                                      height: 50,
                                                    ),
                                                  ),
                                                ),
                                                Positioned(
                                                  right: -236,
                                                  bottom: -64,
                                                  child: Container(
                                                    decoration: BoxDecoration(
                                                      color: Color(0xFF18AEB1),
                                                    ),
                                                    child: Container(
                                                      width: 176,
                                                      height: 48,
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Positioned(
                                left: 6.1,
                                right: 0,
                                bottom: 0,
                                child: Container(
                                  decoration: BoxDecoration(
                                    border: Border.all(color: Color(0xFF18AEB1)),
                                    borderRadius: BorderRadius.circular(10),
                                    color: Color(0xFFFFFFFF),
                                  ),
                                  child: Container(
                                    width: 330.9,
                                    height: 50,
                                    padding: EdgeInsets.fromLTRB(22.5, 15.5, 22.5, 13.5),
                                    child: Container(
                                      decoration: BoxDecoration(
                                        image: DecorationImage(
                                          fit: BoxFit.cover,
                                          image: AssetImage(
                                            'assets/images/add_contact.png',
                                          ),
                                        ),
                                      ),
                                      child: Container(
                                        width: 20,
                                        height: 20,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      Container(
                        margin: EdgeInsets.fromLTRB(0, 0, 6, 0),
                        child: Align(
                          alignment: Alignment.topCenter,
                          child: Container(
                            decoration: BoxDecoration(
                              border: Border.all(color: Color(0xFF333333)),
                              borderRadius: BorderRadius.circular(10),
                              color: Color(0xFF18AEB1),
                            ),
                            child: Container(
                              width: 215,
                              padding: EdgeInsets.fromLTRB(0, 12, 0, 13),
                              child: Text(
                                'ارسل ',
                                style: GoogleFonts.getFont(
                                  'Inter',
                                  fontWeight: FontWeight.w700,
                                  fontSize: 15,
                                  color: Color(0xFFFCFCFE),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Positioned(
                  left: -109,
                  bottom: -115.4,
                  child: Transform.rotate(
                    angle: -0.7374045709,
                    child: SizedBox(
                      width: 169.4,
                      height: 167.4,
                      child: SvgPicture.asset(
                        'assets/vectors/ellipse_2915_x2.svg',
                      ),
                    ),
                  ),
                ),
                Positioned(
                  right: 66,
                  bottom: 94,
                  child: Container(
                    decoration: BoxDecoration(
                      color: Color(0xA8CCCCCC),
                      border: Border(
                        right: BorderSide(
                          color: Color(0xFF000000),
                          width: 1,
                        ),
                      ),
                    ),
                    child: SizedBox(
                      width: 181,
                      height: 50,
                      child: Container(
                        padding: EdgeInsets.fromLTRB(12.7, 13, 12.7, 6.6),
                        child: Stack(
                          clipBehavior: Clip.none,
                          children: [
                            SizedBox(
                              width: 138.3,
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                        margin: EdgeInsets.fromLTRB(0, 5, 19.9, 7.4),
                                        child: Text(
                                          '5 ',
                                          style: GoogleFonts.getFont(
                                            'Inter',
                                            fontWeight: FontWeight.w400,
                                            fontSize: 15,
                                            color: Color(0xFF000000),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        margin: EdgeInsets.fromLTRB(0, 11, 13.3, 1.4),
                                        child: Text(
                                          '5',
                                          style: GoogleFonts.getFont(
                                            'Inter',
                                            fontWeight: FontWeight.w400,
                                            fontSize: 15,
                                            color: Color(0xFF000000),
                                          ),
                                        ),
                                      ),
                                      Column(
                                        mainAxisAlignment: MainAxisAlignment.start,
                                        crossAxisAlignment: CrossAxisAlignment.end,
                                        children: [
                                          Container(
                                            margin: EdgeInsets.fromLTRB(0, 0, 0, 1.4),
                                            child: Text(
                                              '7',
                                              style: GoogleFonts.getFont(
                                                'Inter',
                                                fontWeight: FontWeight.w400,
                                                fontSize: 15,
                                                color: Color(0xFF000000),
                                              ),
                                            ),
                                          ),
                                          Container(
                                            margin: EdgeInsets.fromLTRB(0, 0, 6, 0),
                                            child: SizedBox(
                                              width: 35.8,
                                              height: 11,
                                              child: SvgPicture.asset(
                                                'assets/vectors/vector_6_x2.svg',
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                  Container(
                                    margin: EdgeInsets.fromLTRB(0, 9, 0, 3.4),
                                    child: Text(
                                      '6',
                                      style: GoogleFonts.getFont(
                                        'Inter',
                                        fontWeight: FontWeight.w400,
                                        fontSize: 15,
                                        color: Color(0xFF000000),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Positioned(
                              right: -8.5,
                              bottom: 4.8,
                              child: SizedBox(
                                width: 72.8,
                                height: 19.7,
                                child: SvgPicture.asset(
                                  'assets/vectors/vector_4_x2.svg',
                                ),
                              ),
                            ),
                            Positioned(
                              left: 7.5,
                              bottom: 4.8,
                              child: SizedBox(
                                width: 30.8,
                                height: 24.7,
                                child: SvgPicture.asset(
                                  'assets/vectors/vector_5_x2.svg',
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
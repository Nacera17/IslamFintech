import 'package:flutter/material.dart';
import 'dart:ui';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:flutter_app/utils.dart';
import 'package:google_fonts/google_fonts.dart';

class Group26 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return 
    Container(
      child: Container(
        width: double.infinity,
        decoration: BoxDecoration(
          border: Border.all(color: Color(0xFF9747FF)),
          borderRadius: BorderRadius.circular(5),
        ),
        child: Container(
          padding: EdgeInsets.fromLTRB(19, 19, 19, 19),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Container(
                margin: EdgeInsets.fromLTRB(0, 0, 0, 21),
                width: 47,
                height: 44,
                child: SizedBox(
                  width: 47,
                  height: 44,
                  child: SvgPicture.asset(
                    'assets/vectors/ellipse_33_x2.svg',
                  ),
                ),
              ),
              SizedBox(
                width: 47,
                height: 44,
                child: SvgPicture.asset(
                  'assets/vectors/checkchecked_x2.svg',
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
import 'package:flutter/material.dart';
import 'dart:ui';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:flutter_app/utils.dart';
import 'package:google_fonts/google_fonts.dart';

import 'iphone_131439.dart'; // Import the required file

class Iphone131442 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // Navigate to the next screen with a delay
    Future.delayed(Duration(milliseconds: 1), () {
      Navigator.of(context).push(
        PageRouteBuilder(
          pageBuilder: (context, animation, secondaryAnimation) => Iphone131439(),
          transitionsBuilder: (context, animation, secondaryAnimation, child) {
            var begin = Offset(1.0, 0.0);
            var end = Offset.zero;
            var curve = Curves.ease;

            var tween = Tween(begin: begin, end: end).chain(CurveTween(curve: curve));

            return SlideTransition(
              position: animation.drive(tween),
              child: child,
            );
          },
        ),
      );
    });

    return Container(
      decoration: BoxDecoration(
        color: Color(0xFFFFFFFF),
      ),
      child: Stack(
        children: [
          Positioned(
            right: -805,
            top: -135,
            child: SizedBox(
              width: 1553,
              height: 1482,
              child: SvgPicture.asset(
                'assets/vectors/ellipse_48_x2.svg',
              ),
            ),
          ),
          Container(),
        ],
      ),
    );
  }
}

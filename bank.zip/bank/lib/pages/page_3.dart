import 'package:flutter/material.dart';
import 'dart:ui';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:flutter_app/utils.dart';
import 'package:google_fonts/google_fonts.dart';

class Page3 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return 
    Container(
      decoration: BoxDecoration(
        color: Color(0xFFFFFFFF),
      ),
      child: Stack(
        children: [
          Positioned(
            left: -80.2,
            top: 733,
            child: Transform.rotate(
              angle: -0.7374045709,
              child: SizedBox(
                width: 169.4,
                height: 167.4,
                child: SvgPicture.asset(
                  'assets/vectors/ellipse_283_x2.svg',
                ),
              ),
            ),
          ),
          Positioned(
            left: -110,
            top: 681,
            child: Transform.rotate(
              angle: -0.7374045709,
              child: SizedBox(
                width: 169.4,
                height: 167.4,
                child: SvgPicture.asset(
                  'assets/vectors/ellipse_2913_x2.svg',
                ),
              ),
            ),
          ),
          Positioned(
            left: -110,
            top: -72,
            child: Container(
              width: 527,
              height: 166.3,
              decoration: BoxDecoration(
                boxShadow: [
                  BoxShadow(
                    color: Color(0x40000000),
                    offset: Offset(0, 1),
                    blurRadius: 2,
                  ),
                ],
              ),
              child: SvgPicture.asset(
                'assets/vectors/ellipse_23_x2.svg',
              ),
            ),
          ),
    Container(
            padding: EdgeInsets.fromLTRB(29, 30, 10.4, 219),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  margin: EdgeInsets.fromLTRB(0, 0, 0, 139),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        margin: EdgeInsets.fromLTRB(0, 0, 0, 29),
                        width: 20,
                        height: 20,
                        child: Container(
                          decoration: BoxDecoration(
                            image: DecorationImage(
                              fit: BoxFit.cover,
                              image: AssetImage(
                                'assets/images/back.png',
                              ),
                            ),
                          ),
                          child: Container(
                            width: 20,
                            height: 20,
                          ),
                        ),
                      ),
                      Container(
                        margin: EdgeInsets.fromLTRB(0, 11, 0, 0),
                        child: Text(
                          'العقارات',
                          style: GoogleFonts.getFont(
                            'Inter',
                            fontWeight: FontWeight.w700,
                            fontSize: 25,
                            height: 1.5,
                            color: Color(0xFFFFFFFF),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  margin: EdgeInsets.fromLTRB(5, 0, 22.6, 34),
                  decoration: BoxDecoration(
                    border: Border.all(color: Color(0xFF0B8688)),
                    color: Color(0xFFFCFCFE),
                  ),
                  child: SizedBox(
                    height: 113,
                    child: Container(
                      padding: EdgeInsets.fromLTRB(17, 6, 17, 5),
                      child: Stack(
                        clipBehavior: Clip.none,
                        children: [
                          Container(
                            decoration: BoxDecoration(
                              image: DecorationImage(
                                fit: BoxFit.cover,
                                image: AssetImage(
                                  'assets/images/masrif_salam_1.png',
                                ),
                              ),
                            ),
                            child: Container(
                              width: 88.9,
                              height: 100,
                            ),
                          ),
                          Positioned(
                            right: -23.7,
                            top: 18,
                            child: SizedBox(
                              height: 45,
                              child: Text(
                                ' مصرف السلام',
                                style: GoogleFonts.getFont(
                                  'Inter',
                                  fontWeight: FontWeight.w700,
                                  fontSize: 30,
                                  decoration: TextDecoration.underline,
                                  height: 1.5,
                                  color: Color(0xCF000000),
                                  decorationColor: Color(0xCF000000),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                Container(
                  margin: EdgeInsets.fromLTRB(5, 0, 22.6, 34),
                  decoration: BoxDecoration(
                    border: Border.all(color: Color(0xFF0B8688)),
                    color: Color(0xFFFCFCFE),
                  ),
                  child: Container(
                    padding: EdgeInsets.fromLTRB(11, 16, 9.6, 5),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Expanded(
                          child: Container(
                            margin: EdgeInsets.fromLTRB(0, 0, 6.6, 10),
                            child: Container(
                              decoration: BoxDecoration(
                                image: DecorationImage(
                                  fit: BoxFit.cover,
                                  image: AssetImage(
                                    'assets/images/bna_1.png',
                                  ),
                                ),
                              ),
                              child: Container(
                                height: 80,
                              ),
                            ),
                          ),
                        ),
                        Text(
                          'بنك الوطني الجزائري',
                          textAlign: TextAlign.center,
                          style: GoogleFonts.getFont(
                            'Inter',
                            fontWeight: FontWeight.w700,
                            fontSize: 30,
                            decoration: TextDecoration.underline,
                            height: 1.5,
                            color: Color(0xCF000000),
                            decorationColor: Color(0xCF000000),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                Container(
                  margin: EdgeInsets.fromLTRB(1, 0, 26.6, 0),
                  decoration: BoxDecoration(
                    border: Border.all(color: Color(0xFF0B8688)),
                    color: Color(0xFFFCFCFE),
                  ),
                  child: Container(
                    padding: EdgeInsets.fromLTRB(4.1, 23, 4.1, 12),
                    child: Stack(
                      clipBehavior: Clip.none,
                      children: [
                        Text(
                          'القرض الشعبي الجزائري',
                          textAlign: TextAlign.center,
                          style: GoogleFonts.getFont(
                            'Inter',
                            fontWeight: FontWeight.w700,
                            fontSize: 25,
                            decoration: TextDecoration.underline,
                            height: 1.5,
                            color: Color(0xCF000000),
                            decorationColor: Color(0xCF000000),
                          ),
                        ),
                        Positioned(
                          left: 8.9,
                          bottom: -1.7,
                          child: Container(
                            decoration: BoxDecoration(
                              image: DecorationImage(
                                fit: BoxFit.cover,
                                image: AssetImage(
                                  'assets/images/crdit_populaire_dalgrie_logo_svg_1.png',
                                ),
                              ),
                            ),
                            child: Container(
                              width: 100,
                              height: 90.7,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
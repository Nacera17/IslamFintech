import 'package:flutter/material.dart';
import 'dart:ui';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:flutter_app/utils.dart';
import 'package:google_fonts/google_fonts.dart';

class Frame15420 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return 
    Column(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          margin: EdgeInsets.fromLTRB(0, 0, 0, 20),
          padding: EdgeInsets.fromLTRB(19, 19, 19, 19),
          decoration: BoxDecoration(
            border: Border.all(color: Color(0xFF9747FF)),
            borderRadius: BorderRadius.circular(5),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                margin: EdgeInsets.fromLTRB(0, 0, 0, 42),
                decoration: BoxDecoration(
                  border: Border.all(color: Color(0xFF0B8688)),
                  color: Color(0xFFFCFCFE),
                ),
                child: Container(
                  padding: EdgeInsets.fromLTRB(10, 10.4, 14, 15),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        margin: EdgeInsets.fromLTRB(0, 3.6, 0, 0),
                        width: 9,
                        height: 9,
                        child: SizedBox(
                          width: 9,
                          height: 9,
                          child: SvgPicture.asset(
                            'assets/vectors/vector_8_x2.svg',
                          ),
                        ),
                      ),
                      Container(
                        margin: EdgeInsets.fromLTRB(0, 0, 0, 0.6),
                        child: Text(
                          'الخدمة الرئيسية ',
                          style: GoogleFonts.getFont(
                            'Inter',
                            fontWeight: FontWeight.w700,
                            fontSize: 10,
                            color: Color(0xFF18AEB1),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Container(
                decoration: BoxDecoration(
                  border: Border.all(color: Color(0xFF0B8688)),
                  color: Color(0xFFFCFCFE),
                ),
                child: Container(
                  padding: EdgeInsets.fromLTRB(11.7, 7, 14, 16),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Container(
                        margin: EdgeInsets.fromLTRB(0, 0, 0, 7.9),
                        child: Text(
                          'الخدمة الرئيسية ',
                          style: GoogleFonts.getFont(
                            'Inter',
                            fontWeight: FontWeight.w700,
                            fontSize: 10,
                            color: Color(0xFF18AEB1),
                          ),
                        ),
                      ),
                      Container(
                        margin: EdgeInsets.fromLTRB(0, 0, 0, 3.4),
                        child: Align(
                          alignment: Alignment.topLeft,
                          child: Container(
                            width: 9.6,
                            height: 1.8,
                            child: SizedBox(
                              width: 9.6,
                              height: 1.8,
                              child: SvgPicture.asset(
                                'assets/vectors/vector_133_x2.svg',
                              ),
                            ),
                          ),
                        ),
                      ),
                      Text(
                        'التوعية بالزكاة وخدمات الصندوق',
                        style: GoogleFonts.getFont(
                          'Inter',
                          fontWeight: FontWeight.w700,
                          fontSize: 10,
                          color: Color(0xFF50555C),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
        Container(
          margin: EdgeInsets.fromLTRB(0, 0, 0, 20),
          padding: EdgeInsets.fromLTRB(19, 19, 19, 19),
          decoration: BoxDecoration(
            border: Border.all(color: Color(0xFF9747FF)),
            borderRadius: BorderRadius.circular(5),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                margin: EdgeInsets.fromLTRB(0, 0, 0, 42),
                decoration: BoxDecoration(
                  border: Border.all(color: Color(0xFF0B8688)),
                  color: Color(0xFFFCFCFE),
                ),
                child: Container(
                  padding: EdgeInsets.fromLTRB(10, 10.4, 14, 15),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        margin: EdgeInsets.fromLTRB(0, 3.6, 0, 0),
                        width: 9,
                        height: 9,
                        child: SizedBox(
                          width: 9,
                          height: 9,
                          child: SvgPicture.asset(
                            'assets/vectors/vector_83_x2.svg',
                          ),
                        ),
                      ),
                      Container(
                        margin: EdgeInsets.fromLTRB(0, 0, 0, 0.6),
                        child: Text(
                          'الرسوم ',
                          style: GoogleFonts.getFont(
                            'Inter',
                            fontWeight: FontWeight.w700,
                            fontSize: 10,
                            color: Color(0xFF18AEB1),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Container(
                decoration: BoxDecoration(
                  border: Border.all(color: Color(0xFF0B8688)),
                  color: Color(0xFFFCFCFE),
                ),
                child: Container(
                  padding: EdgeInsets.fromLTRB(11.7, 7, 14, 16),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Container(
                        margin: EdgeInsets.fromLTRB(0, 0, 0, 7.9),
                        child: Text(
                          'الرسوم ',
                          style: GoogleFonts.getFont(
                            'Inter',
                            fontWeight: FontWeight.w700,
                            fontSize: 10,
                            color: Color(0xFF18AEB1),
                          ),
                        ),
                      ),
                      Container(
                        margin: EdgeInsets.fromLTRB(0, 0, 0, 3.4),
                        child: Align(
                          alignment: Alignment.topLeft,
                          child: Container(
                            width: 9.6,
                            height: 1.8,
                            child: SizedBox(
                              width: 9.6,
                              height: 1.8,
                              child: SvgPicture.asset(
                                'assets/vectors/vector_87_x2.svg',
                              ),
                            ),
                          ),
                        ),
                      ),
                      Text(
                        'مجانية',
                        style: GoogleFonts.getFont(
                          'Inter',
                          fontWeight: FontWeight.w700,
                          fontSize: 10,
                          color: Color(0xFF50555C),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
        Container(
          margin: EdgeInsets.fromLTRB(0, 0, 0, 20),
          padding: EdgeInsets.fromLTRB(19, 19, 19, 19),
          decoration: BoxDecoration(
            border: Border.all(color: Color(0xFF9747FF)),
            borderRadius: BorderRadius.circular(5),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                margin: EdgeInsets.fromLTRB(0, 0, 0, 42),
                decoration: BoxDecoration(
                  border: Border.all(color: Color(0xFF0B8688)),
                  color: Color(0xFFFCFCFE),
                ),
                child: Container(
                  padding: EdgeInsets.fromLTRB(10, 10, 14, 15),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        margin: EdgeInsets.fromLTRB(0, 4, 0, 0),
                        width: 9,
                        height: 9,
                        child: SizedBox(
                          width: 9,
                          height: 9,
                          child: SvgPicture.asset(
                            'assets/vectors/vector_x2.svg',
                          ),
                        ),
                      ),
                      Container(
                        margin: EdgeInsets.fromLTRB(0, 0, 0, 1),
                        child: Text(
                          'معدل الوقت اللازم لطلب الخدمة',
                          style: GoogleFonts.getFont(
                            'Inter',
                            fontWeight: FontWeight.w700,
                            fontSize: 10,
                            color: Color(0xFF18AEB1),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Container(
                decoration: BoxDecoration(
                  border: Border.all(color: Color(0xFF0B8688)),
                  color: Color(0xFFFCFCFE),
                ),
                child: Container(
                  padding: EdgeInsets.fromLTRB(11.7, 9, 14, 16),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Container(
                        margin: EdgeInsets.fromLTRB(0, 0, 0, 5.9),
                        child: Text(
                          'معدل الوقت اللازم لطلب الخدمة',
                          style: GoogleFonts.getFont(
                            'Inter',
                            fontWeight: FontWeight.w700,
                            fontSize: 10,
                            color: Color(0xFF18AEB1),
                          ),
                        ),
                      ),
                      Container(
                        margin: EdgeInsets.fromLTRB(0, 0, 0, 3.4),
                        child: Align(
                          alignment: Alignment.topLeft,
                          child: Container(
                            width: 9.6,
                            height: 1.8,
                            child: SizedBox(
                              width: 9.6,
                              height: 1.8,
                              child: SvgPicture.asset(
                                'assets/vectors/vector_7_x2.svg',
                              ),
                            ),
                          ),
                        ),
                      ),
                      Text(
                        '5 دقائق',
                        style: GoogleFonts.getFont(
                          'Inter',
                          fontWeight: FontWeight.w700,
                          fontSize: 10,
                          color: Color(0xFF50555C),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
        Container(
          margin: EdgeInsets.fromLTRB(0, 0, 0, 20),
          padding: EdgeInsets.fromLTRB(19, 19, 19, 19),
          decoration: BoxDecoration(
            border: Border.all(color: Color(0xFF9747FF)),
            borderRadius: BorderRadius.circular(5),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                margin: EdgeInsets.fromLTRB(0, 0, 0, 42),
                decoration: BoxDecoration(
                  border: Border.all(color: Color(0xFF0B8688)),
                  color: Color(0xFFFCFCFE),
                ),
                child: Container(
                  padding: EdgeInsets.fromLTRB(10, 10, 14, 15),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        margin: EdgeInsets.fromLTRB(0, 4, 0, 0),
                        width: 9,
                        height: 9,
                        child: SizedBox(
                          width: 9,
                          height: 9,
                          child: SvgPicture.asset(
                            'assets/vectors/vector_140_x2.svg',
                          ),
                        ),
                      ),
                      Container(
                        margin: EdgeInsets.fromLTRB(0, 0, 0, 1),
                        child: Text(
                          'معدل الوقت اللازم للحصول على الخدمة',
                          style: GoogleFonts.getFont(
                            'Inter',
                            fontWeight: FontWeight.w700,
                            fontSize: 10,
                            color: Color(0xFF18AEB1),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Container(
                decoration: BoxDecoration(
                  border: Border.all(color: Color(0xFF0B8688)),
                  color: Color(0xFFFCFCFE),
                ),
                child: Container(
                  padding: EdgeInsets.fromLTRB(11.7, 8, 14, 4),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Container(
                        margin: EdgeInsets.fromLTRB(0, 0, 0, 6.9),
                        child: Text(
                          'معدل الوقت اللازم للحصول على الخدمة',
                          style: GoogleFonts.getFont(
                            'Inter',
                            fontWeight: FontWeight.w700,
                            fontSize: 10,
                            color: Color(0xFF18AEB1),
                          ),
                        ),
                      ),
                      Container(
                        margin: EdgeInsets.fromLTRB(0, 0, 0, 3.4),
                        child: Align(
                          alignment: Alignment.topLeft,
                          child: Container(
                            width: 9.6,
                            height: 1.8,
                            child: SizedBox(
                              width: 9.6,
                              height: 1.8,
                              child: SvgPicture.asset(
                                'assets/vectors/vector_115_x2.svg',
                              ),
                            ),
                          ),
                        ),
                      ),
                      Text(
                        'لطلب الفتوى يوم عمل واحد',
                        textAlign: TextAlign.right,
                        style: GoogleFonts.getFont(
                          'Inter',
                          fontWeight: FontWeight.w700,
                          fontSize: 10,
                          color: Color(0xFF50555C),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
        Container(
          margin: EdgeInsets.fromLTRB(0, 0, 0, 20),
          padding: EdgeInsets.fromLTRB(19, 19, 19, 19),
          decoration: BoxDecoration(
            border: Border.all(color: Color(0xFF9747FF)),
            borderRadius: BorderRadius.circular(5),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                margin: EdgeInsets.fromLTRB(0, 0, 0, 42),
                decoration: BoxDecoration(
                  border: Border.all(color: Color(0xFF0B8688)),
                  color: Color(0xFFFCFCFE),
                ),
                child: Container(
                  padding: EdgeInsets.fromLTRB(10, 10, 14, 15),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        margin: EdgeInsets.fromLTRB(0, 4, 0, 0),
                        width: 9,
                        height: 9,
                        child: SizedBox(
                          width: 9,
                          height: 9,
                          child: SvgPicture.asset(
                            'assets/vectors/vector_16_x2.svg',
                          ),
                        ),
                      ),
                      Container(
                        margin: EdgeInsets.fromLTRB(0, 0, 0, 1),
                        child: Text(
                          'ساعات توافر العمل  ',
                          style: GoogleFonts.getFont(
                            'Inter',
                            fontWeight: FontWeight.w700,
                            fontSize: 10,
                            color: Color(0xFF18AEB1),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Container(
                decoration: BoxDecoration(
                  border: Border.all(color: Color(0xFF0B8688)),
                  color: Color(0xFFFCFCFE),
                ),
                child: Container(
                  padding: EdgeInsets.fromLTRB(11.7, 8, 11, 8),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Container(
                        margin: EdgeInsets.fromLTRB(3, 0, 3, 6.9),
                        child: Text(
                          'ساعات توافر العمل من الاثنين الى الخميس ',
                          style: GoogleFonts.getFont(
                            'Inter',
                            fontWeight: FontWeight.w700,
                            fontSize: 10,
                            color: Color(0xFF18AEB1),
                          ),
                        ),
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            margin: EdgeInsets.fromLTRB(0, 0, 0, 23.4),
                            width: 9.6,
                            height: 1.8,
                            child: SizedBox(
                              width: 9.6,
                              height: 1.8,
                              child: SvgPicture.asset(
                                'assets/vectors/vector_97_x2.svg',
                              ),
                            ),
                          ),
    Container(
    margin: EdgeInsets.fromLTRB(0, 1.1, 0, 0),
    child: Text(
    '''من الاثنين الى الخميس
7:30  صباحا  حتى  13:30 مساء''',
    textAlign: TextAlign.right,
    style: GoogleFonts.getFont(
    'Inter',
    fontWeight: FontWeight.w700,
    fontSize: 10,
    color: Color(0xFF50555C),
    ),
    ),
    ),

    ],
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
        Container(
          margin: EdgeInsets.fromLTRB(0, 0, 0, 20),
          padding: EdgeInsets.fromLTRB(19, 19, 19, 19),
          decoration: BoxDecoration(
            border: Border.all(color: Color(0xFF9747FF)),
            borderRadius: BorderRadius.circular(5),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                margin: EdgeInsets.fromLTRB(0, 0, 0, 42),
                decoration: BoxDecoration(
                  border: Border.all(color: Color(0xFF0B8688)),
                  color: Color(0xFFFCFCFE),
                ),
                child: Container(
                  padding: EdgeInsets.fromLTRB(10, 10, 14, 15),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        margin: EdgeInsets.fromLTRB(0, 4, 0, 0),
                        width: 9,
                        height: 9,
                        child: SizedBox(
                          width: 9,
                          height: 9,
                          child: SvgPicture.asset(
                            'assets/vectors/vector_136_x2.svg',
                          ),
                        ),
                      ),
                      Container(
                        margin: EdgeInsets.fromLTRB(0, 0, 0, 1),
                        child: Text(
                          'ساعات الاستفسار الهاتفي   ',
                          style: GoogleFonts.getFont(
                            'Inter',
                            fontWeight: FontWeight.w700,
                            fontSize: 10,
                            color: Color(0xFF18AEB1),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Container(
                decoration: BoxDecoration(
                  border: Border.all(color: Color(0xFF0B8688)),
                  color: Color(0xFFFCFCFE),
                ),
                child: Container(
                  padding: EdgeInsets.fromLTRB(11.7, 8, 11, 8),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Container(
                        margin: EdgeInsets.fromLTRB(3, 0, 3, 6.9),
                        child: Text(
                          'ساعات الاستفسار الهاتفي   ',
                          style: GoogleFonts.getFont(
                            'Inter',
                            fontWeight: FontWeight.w700,
                            fontSize: 10,
                            color: Color(0xFF18AEB1),
                          ),
                        ),
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            margin: EdgeInsets.fromLTRB(0, 0, 0, 23.4),
                            width: 9.6,
                            height: 1.8,
                            child: SizedBox(
                              width: 9.6,
                              height: 1.8,
                              child: SvgPicture.asset(
                                'assets/vectors/vector_21_x2.svg',
                              ),
                            ),
                          ),
    Container(
    margin: EdgeInsets.fromLTRB(0, 1.1, 0, 0),
    child: Text(
    '''الجمعة و السبت  
15 مساء حتى 19 مساء''',
    textAlign: TextAlign.right,
    style: GoogleFonts.getFont(
    'Inter',
    fontWeight: FontWeight.w700,
    fontSize: 10,
    color: Color(0xFF50555C),
    ),
    ),
    ),

    ],
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
        Container(
          margin: EdgeInsets.fromLTRB(0, 0, 0, 20),
          padding: EdgeInsets.fromLTRB(19, 19, 19, 19),
          decoration: BoxDecoration(
            border: Border.all(color: Color(0xFF9747FF)),
            borderRadius: BorderRadius.circular(5),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                margin: EdgeInsets.fromLTRB(0, 0, 0, 42),
                decoration: BoxDecoration(
                  border: Border.all(color: Color(0xFF0B8688)),
                  color: Color(0xFFFCFCFE),
                ),
                child: Container(
                  padding: EdgeInsets.fromLTRB(10, 10, 14, 15),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        margin: EdgeInsets.fromLTRB(0, 4, 0, 0),
                        width: 9,
                        height: 9,
                        child: SizedBox(
                          width: 9,
                          height: 9,
                          child: SvgPicture.asset(
                            'assets/vectors/vector_111_x2.svg',
                          ),
                        ),
                      ),
                      Container(
                        margin: EdgeInsets.fromLTRB(0, 0, 0, 1),
                        child: Text(
                          'ارقام هواتف طلب الخدمة',
                          style: GoogleFonts.getFont(
                            'Inter',
                            fontWeight: FontWeight.w700,
                            fontSize: 10,
                            color: Color(0xFF18AEB1),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Container(
                decoration: BoxDecoration(
                  border: Border.all(color: Color(0xFF0B8688)),
                  color: Color(0xFFFCFCFE),
                ),
                child: Container(
                  padding: EdgeInsets.fromLTRB(11.7, 8, 11, 1),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Container(
                        margin: EdgeInsets.fromLTRB(3, 0, 3, 3),
                        child: Text(
                          'ارقام هواتف طلب الخدمة',
                          style: GoogleFonts.getFont(
                            'Inter',
                            fontWeight: FontWeight.w700,
                            fontSize: 10,
                            color: Color(0xFF18AEB1),
                          ),
                        ),
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            margin: EdgeInsets.fromLTRB(0, 3.9, 0, 30.4),
                            width: 9.6,
                            height: 1.8,
                            child: SizedBox(
                              width: 9.6,
                              height: 1.8,
                              child: SvgPicture.asset(
                                'assets/vectors/vector_81_x2.svg',
                              ),
                            ),
                          ),
                          Text(
    '''0645251352
                          0754658915
                          0512254645''',
                            textAlign: TextAlign.right,
                            style: GoogleFonts.getFont(
                              'Inter',
                              fontWeight: FontWeight.w700,
                              fontSize: 10,
                              color: Color(0xFF50555C),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
        Container(
          padding: EdgeInsets.fromLTRB(19, 19, 19, 19),
          decoration: BoxDecoration(
            border: Border.all(color: Color(0xFF9747FF)),
            borderRadius: BorderRadius.circular(5),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                margin: EdgeInsets.fromLTRB(0, 0, 0, 42),
                decoration: BoxDecoration(
                  border: Border.all(color: Color(0xFF0B8688)),
                  color: Color(0xFFFCFCFE),
                ),
                child: Container(
                  padding: EdgeInsets.fromLTRB(10, 10, 14, 15),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        margin: EdgeInsets.fromLTRB(0, 4, 0, 0),
                        width: 9,
                        height: 9,
                        child: SizedBox(
                          width: 9,
                          height: 9,
                          child: SvgPicture.asset(
                            'assets/vectors/vector_85_x2.svg',
                          ),
                        ),
                      ),
                      Container(
                        margin: EdgeInsets.fromLTRB(0, 0, 0, 1),
                        child: Text(
                          'اللغات الموفرة ',
                          style: GoogleFonts.getFont(
                            'Inter',
                            fontWeight: FontWeight.w700,
                            fontSize: 10,
                            color: Color(0xFF18AEB1),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Container(
                decoration: BoxDecoration(
                  border: Border.all(color: Color(0xFF0B8688)),
                  color: Color(0xFFFCFCFE),
                ),
                child: Container(
                  padding: EdgeInsets.fromLTRB(11.7, 8, 11, 20),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Container(
                        margin: EdgeInsets.fromLTRB(3, 0, 3, 6.9),
                        child: Text(
                          'اللغات الموفرة ',
                          style: GoogleFonts.getFont(
                            'Inter',
                            fontWeight: FontWeight.w700,
                            fontSize: 10,
                            color: Color(0xFF18AEB1),
                          ),
                        ),
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            margin: EdgeInsets.fromLTRB(0, 0, 0, 11.4),
                            width: 9.6,
                            height: 1.8,
                            child: SizedBox(
                              width: 9.6,
                              height: 1.8,
                              child: SvgPicture.asset(
                                'assets/vectors/vector_3_x2.svg',
                              ),
                            ),
                          ),
                          Container(
                            margin: EdgeInsets.fromLTRB(0, 1.1, 0, 0),
                            child: Text(
                              'الانجليزية  , العربية  , الفرنسية',
                              style: GoogleFonts.getFont(
                                'Inter',
                                fontWeight: FontWeight.w700,
                                fontSize: 10,
                                color: Color(0xFF50555C),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
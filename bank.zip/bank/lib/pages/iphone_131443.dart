import 'package:flutter/material.dart';
import 'dart:ui';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:flutter_app/utils.dart';
import 'package:google_fonts/google_fonts.dart';

class Iphone131443 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return 
    Container(
      decoration: BoxDecoration(
        color: Color(0xFFFFFFFF),
      ),
      child: Stack(
        children: [
          Positioned(
            left: -113,
            top: -421,
            child: SizedBox(
              width: 295,
              height: 358,
              child: SvgPicture.asset(
                'assets/vectors/ellipse_49_x2.svg',
              ),
            ),
          ),
          Positioned(
            left: 44,
            top: -366,
            child: SizedBox(
              width: 206,
              height: 209,
              child: SvgPicture.asset(
                'assets/vectors/ellipse_50_x2.svg',
              ),
            ),
          ),
          Positioned(
            right: -131,
            top: 386,
            child: SizedBox(
              width: 236,
              height: 281,
              child: SvgPicture.asset(
                'assets/vectors/ellipse_51_x2.svg',
              ),
            ),
          ),
          Positioned(
            right: -88,
            top: 497,
            child: SizedBox(
              width: 239,
              height: 301,
              child: SvgPicture.asset(
                'assets/vectors/ellipse_52_x2.svg',
              ),
            ),
          ),
    Container(
            padding: EdgeInsets.fromLTRB(26, 247, 30, 233),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  margin: EdgeInsets.fromLTRB(0, 0, 0, 59),
                  child: Align(
                    alignment: Alignment.topRight,
                    child: Container(
                      width: 306,
                      height: 55,
                      child: Positioned(
                        right: -23,
                        top: 5,
                        child: SizedBox(
                          height: 29,
                          child: Text(
                            'ارسال   الرمز الى رقم الهاتف ',
                            style: GoogleFonts.getFont(
                              'Inter',
                              fontWeight: FontWeight.w400,
                              fontSize: 24,
                              color: Color(0xFF000000),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
                Align(
                  alignment: Alignment.topLeft,
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(100),
                    child: SizedBox(
                      width: 250,
                      height: 250,
                      child: SvgPicture.asset(
                        'assets/vectors/undraw_confirm_re_69_me_1_x2.svg',
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
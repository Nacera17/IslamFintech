import 'package:flutter/material.dart';
import 'dart:ui';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:flutter_app/utils.dart';
import 'package:google_fonts/google_fonts.dart';

class Iphone131446 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return 
    Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment(0, -1),
          end: Alignment(0, 1),
          colors: <Color>[Color(0xFF3C7DB2), Color(0xFF64CACB)],
          stops: <double>[0.085, 1],
        ),
      ),
      child: Stack(
        children: [
          Positioned(
            right: -107.2,
            top: -124,
        child: Transform.rotate(
          angle: -0.6395083633,
              child: SizedBox(
                width: 251,
                height: 249,
                child: SvgPicture.asset(
                  'assets/vectors/ellipse_39_x2.svg',
                ),
              ),
            ),
          ),
          Positioned(
            right: -157.6,
            top: -22,
            child: Transform.rotate(
              angle: -0.1779358141,
              child: SizedBox(
                width: 199.6,
                height: 151.1,
                child: SvgPicture.asset(
                  'assets/vectors/ellipse_38_x2.svg',
                ),
              ),
            ),
          ),
          Positioned(
            left: -410,
            top: 1361,
            child: Transform.rotate(
              angle: -0.6333967211,
              child: SizedBox(
                width: 209.2,
                height: 204.5,
                child: SvgPicture.asset(
                  'assets/vectors/ellipse_40_x2.svg',
                ),
              ),
            ),
          ),
          Positioned(
            left: -355.1,
            top: 1443,
            child: Transform.rotate(
              angle: -0.6395083633,
              child: SizedBox(
                width: 130.4,
                height: 131.4,
                child: SvgPicture.asset(
                  'assets/vectors/ellipse_41_x2.svg',
                ),
              ),
            ),
          ),
          Positioned(
            left: -410,
            top: 1361,
            child: Transform.rotate(
              angle: -0.6333967211,
              child: SizedBox(
                width: 209.2,
                height: 204.5,
                child: SvgPicture.asset(
                  'assets/vectors/ellipse_42_x2.svg',
                ),
              ),
            ),
          ),
          Positioned(
            left: -355.1,
            top: 1443,
            child: Transform.rotate(
              angle: -0.6395083633,
              child: SizedBox(
                width: 130.4,
                height: 131.4,
                child: SvgPicture.asset(
                  'assets/vectors/ellipse_43_x2.svg',
                ),
              ),
            ),
          ),
    Container(
            padding: EdgeInsets.fromLTRB(0, 20, 0, 0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  margin: EdgeInsets.fromLTRB(25, 0, 29.1, 84),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        margin: EdgeInsets.fromLTRB(0, 1, 0, 0),
                        width: 20,
                        height: 20,
                        child: Container(
                          decoration: BoxDecoration(
                            image: DecorationImage(
                              fit: BoxFit.cover,
                              image: AssetImage(
                                'assets/images/back.png',
                              ),
                            ),
                          ),
                          child: Container(
                            width: 20,
                            height: 20,
                          ),
                        ),
                      ),
                      Container(
                        margin: EdgeInsets.fromLTRB(0, 0, 0, 1.9),
                        child: SizedBox(
                          width: 21.9,
                          height: 19.1,
                          child: SvgPicture.asset(
                            'assets/vectors/vector_126_x2.svg',
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  margin: EdgeInsets.fromLTRB(28, 0, 28, 20),
                  decoration: BoxDecoration(
                    border: Border.all(color: Color(0xFF2F2E41)),
                    borderRadius: BorderRadius.circular(15),
                    color: Color(0xFFFFFFFF),
                  ),
                  child: Container(
                    padding: EdgeInsets.fromLTRB(18.9, 5.1, 4.9, 5.9),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          width: 60,
                          child: Container(
                            decoration: BoxDecoration(
                              color: Color(0xFFDBF2F2),
                              borderRadius: BorderRadius.circular(100),
                            ),
                            child: SizedBox(
                              width: 60,
                              child: Container(
                                padding: EdgeInsets.fromLTRB(12.6, 16.4, 11.1, 0),
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.end,
                                  children: [
                                    Container(
                                      margin: EdgeInsets.fromLTRB(8.6, 0, 8.6, 2.5),
                                      child: SizedBox(
                                        width: 19.5,
                                        height: 16.2,
                                        child: SvgPicture.asset(
                                          'assets/vectors/container_10_x2.svg',
                                        ),
                                      ),
                                    ),
                                    SizedBox(
                                      width: 36.3,
                                      height: 14.9,
                                      child: SvgPicture.asset(
                                        'assets/vectors/container_2_x2.svg',
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ),
                        Container(
                          margin: EdgeInsets.fromLTRB(0, 7.9, 0, 15.1),
                          child: Text(
                            'حسابي المصرفي',
                            style: GoogleFonts.getFont(
                              'Inter',
                              fontWeight: FontWeight.w700,
                              fontSize: 18,
                              height: 1.5,
                              color: Color(0xFF265073),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                Container(
                  margin: EdgeInsets.fromLTRB(28, 0, 28, 20),
                  child: Container(
                    padding: EdgeInsets.fromLTRB(17, 6, 26.3, 5),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          decoration: BoxDecoration(
                            border: Border.all(color: Color(0x61000000)),
                            borderRadius: BorderRadius.circular(100),
                            color: Color(0xFFDBF2F2),
                          ),
                          child: Stack(
                            children: [
                              Positioned(
                                left: 0,
                                top: 22.7,
                                child: SizedBox(
                                  width: 9.7,
                                  height: 8.4,
                                  child: SvgPicture.asset(
                                    'assets/vectors/vector_31_x2.svg',
                                  ),
                                ),
                              ),
                              Positioned(
                                left: 18.6,
                                top: 0,
                                child: SizedBox(
                                  width: 15.5,
                                  height: 2.1,
                                  child: SvgPicture.asset(
                                    'assets/vectors/vector_29_x2.svg',
                                  ),
                                ),
                              ),
                        SizedBox(
                                width: 60,
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.end,
                                  children: [
                                    Container(
                                      margin: EdgeInsets.fromLTRB(0, 0, 12.4, 5.4),
                                      child: Align(
                                        alignment: Alignment.topCenter,
                                        child: SizedBox(
                                          width: 1.4,
                                          height: 1.2,
                                          child: SvgPicture.asset(
                                            'assets/vectors/group_6_x2.svg',
                                          ),
                                        ),
                                      ),
                                    ),
                                    Container(
                                      margin: EdgeInsets.fromLTRB(0, 0, 6.5, 0.8),
                                      child: SizedBox(
                                        width: 52.5,
                                        child: Row(
                                          mainAxisAlignment: MainAxisAlignment.start,
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            SizedBox(
                                              width: 9.7,
                                              height: 8.4,
                                              child: SvgPicture.asset(
                                                'assets/vectors/vector_2_x2.svg',
                                              ),
                                            ),
                                            SizedBox(
                                              width: 9.7,
                                              height: 8.4,
                                              child: SvgPicture.asset(
                                                'assets/vectors/vector_47_x2.svg',
                                              ),
                                            ),
                                            SizedBox(
                                              width: 9.7,
                                              height: 8.4,
                                              child: SvgPicture.asset(
                                                'assets/vectors/container_8_x2.svg',
                                              ),
                                            ),
                                            SizedBox(
                                              width: 9.7,
                                              height: 8.4,
                                              child: SvgPicture.asset(
                                                'assets/vectors/vector_128_x2.svg',
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                    Container(
                                      margin: EdgeInsets.fromLTRB(1.1, 0, 8.5, 4.1),
                                      child: SizedBox(
                                        width: 48.4,
                                        child: Row(
                                          mainAxisAlignment: MainAxisAlignment.start,
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Container(
                                              margin: EdgeInsets.fromLTRB(0, 0, 9.5, 0),
                                              child: SizedBox(
                                                width: 5,
                                                height: 1,
                                                child: SvgPicture.asset(
                                                  'assets/vectors/vector_90_x2.svg',
                                                ),
                                              ),
                                            ),
                                            Container(
                                              margin: EdgeInsets.fromLTRB(0, 0, 9.5, 0),
                                              child: SizedBox(
                                                width: 5,
                                                height: 1,
                                                child: SvgPicture.asset(
                                                  'assets/vectors/vector_64_x2.svg',
                                                ),
                                              ),
                                            ),
                                            Container(
                                              margin: EdgeInsets.fromLTRB(0, 0, 9.2, 0),
                                              child: SizedBox(
                                                width: 5,
                                                height: 1,
                                                child: SvgPicture.asset(
                                                  'assets/vectors/vector_108_x2.svg',
                                                ),
                                              ),
                                            ),
                                            SizedBox(
                                              width: 5,
                                              height: 1,
                                              child: SvgPicture.asset(
                                                'assets/vectors/vector_86_x2.svg',
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                    Container(
                                      margin: EdgeInsets.fromLTRB(1.1, 0, 5.9, 0),
                                      child: SizedBox(
                                        width: 51.1,
                                        child: Row(
                                          mainAxisAlignment: MainAxisAlignment.start,
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Container(
                                              margin: EdgeInsets.fromLTRB(0, 10.6, 0.2, 17),
                                              child: SizedBox(
                                                width: 5,
                                                height: 1,
                                                child: SvgPicture.asset(
                                                  'assets/vectors/vector_22_x2.svg',
                                                ),
                                              ),
                                            ),
                                            Container(
                                              margin: EdgeInsets.fromLTRB(0, 0, 3, 25.1),
                                              child: SizedBox(
                                                width: 3.9,
                                                height: 3.4,
                                                child: SvgPicture.asset(
                                                  'assets/vectors/vector_101_x2.svg',
                                                ),
                                              ),
                                            ),
                                            Container(
                                              margin: EdgeInsets.fromLTRB(0, 1.3, 0.5, 17),
                                              child: SizedBox(
                                                width: 9.7,
                                                child: Column(
                                                  mainAxisAlignment: MainAxisAlignment.start,
                                                  crossAxisAlignment: CrossAxisAlignment.center,
                                                  children: [
                                                    Container(
                                                      margin: EdgeInsets.fromLTRB(0, 0, 0, 0.8),
                                                      child: SizedBox(
                                                        width: 9.7,
                                                        height: 8.4,
                                                        child: SvgPicture.asset(
                                                          'assets/vectors/vector_92_x2.svg',
                                                        ),
                                                      ),
                                                    ),
                                                    Container(
                                                      margin: EdgeInsets.fromLTRB(2.3, 0, 2.3, 0),
                                                      child: SizedBox(
                                                        width: 5,
                                                        height: 1,
                                                        child: SvgPicture.asset(
                                                          'assets/vectors/vector_59_x2.svg',
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                            Container(
                                              margin: EdgeInsets.fromLTRB(0, 15.8, 0.3, 11.9),
                                              child: SizedBox(
                                                width: 3.8,
                                                child: Row(
                                                  mainAxisAlignment: MainAxisAlignment.start,
                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                  children: [
                                                    Container(
                                                      margin: EdgeInsets.fromLTRB(0, 0, 0.5, 0),
                                                      child: SizedBox(
                                                        width: 1,
                                                        height: 0.8,
                                                        child: SvgPicture.asset(
                                                          'assets/vectors/vector_43_x2.svg',
                                                        ),
                                                      ),
                                                    ),
                                                    Container(
                                                      margin: EdgeInsets.fromLTRB(0, 0, 0.5, 0),
                                                      child: SizedBox(
                                                        width: 1,
                                                        height: 0.8,
                                                        child: SvgPicture.asset(
                                                          'assets/vectors/vector_79_x2.svg',
                                                        ),
                                                      ),
                                                    ),
                                                    SizedBox(
                                                      width: 1,
                                                      height: 0.8,
                                                      child: SvgPicture.asset(
                                                        'assets/vectors/vector_114_x2.svg',
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                            Container(
                                              margin: EdgeInsets.fromLTRB(0, 1.5, 4.9, 16.8),
                                              child: SizedBox(
                                                width: 9.7,
                                                child: Column(
                                                  mainAxisAlignment: MainAxisAlignment.start,
                                                  crossAxisAlignment: CrossAxisAlignment.center,
                                                  children: [
                                                    Container(
                                                      margin: EdgeInsets.fromLTRB(0, 0, 0, 0.8),
                                                      child: SizedBox(
                                                        width: 9.7,
                                                        height: 8.4,
                                                        child: SvgPicture.asset(
                                                          'assets/vectors/vector_49_x2.svg',
                                                        ),
                                                      ),
                                                    ),
                                                    Container(
                                                      margin: EdgeInsets.fromLTRB(2.6, 0, 2.1, 0),
                                                      child: SizedBox(
                                                        width: 5,
                                                        height: 1,
                                                        child: SvgPicture.asset(
                                                          'assets/vectors/vector_41_x2.svg',
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                            Container(
                                              margin: EdgeInsets.fromLTRB(0, 3, 0, 0),
                                              child: SizedBox(
                                                width: 10,
                                                height: 25.5,
                                                child: SvgPicture.asset(
                                                  'assets/vectors/group_5_x2.svg',
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                    SizedBox(
                                      width: 22.3,
                                      height: 0.2,
                                      child: SvgPicture.asset(
                                        'assets/vectors/vector_46_x2.svg',
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          margin: EdgeInsets.fromLTRB(0, 7, 0, 16),
                          child: Text(
                            'العروض',
                            style: GoogleFonts.getFont(
                              'Inter',
                              fontWeight: FontWeight.w700,
                              fontSize: 18,
                              height: 1.5,
                              color: Color(0xFF265073),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                Container(
                  margin: EdgeInsets.fromLTRB(28, 0, 28, 20),
                  child: Container(
                    padding: EdgeInsets.fromLTRB(16, 7, 10.6, 4),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          decoration: BoxDecoration(
                            border: Border.all(color: Color(0x61000000)),
                            borderRadius: BorderRadius.circular(100),
                            color: Color(0xFFDBF2F2),
                          ),
                          child: Stack(
                            children: [
                              Positioned(
                                left: 13.1,
                                top: 0,
                                child: SizedBox(
                                  width: 27.3,
                                  height: 49.9,
                                  child: SvgPicture.asset(
                                    'assets/vectors/vector_131_x2.svg',
                                  ),
                                ),
                              ),
                        Container(
                                width: 60,
                                height: 50,
                                child: SizedBox(
                                  width: 60,
                                  height: 49.5,
                                  child: SvgPicture.asset(
                                    'assets/vectors/container_34_x2.svg',
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          margin: EdgeInsets.fromLTRB(0, 6, 0, 17),
                          child: Text(
                            'حساب التوفير',
                            style: GoogleFonts.getFont(
                              'Inter',
                              fontWeight: FontWeight.w700,
                              fontSize: 18,
                              height: 1.5,
                              color: Color(0xFF265073),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                Container(
                  margin: EdgeInsets.fromLTRB(25, 0, 31, 19),
                  child: Container(
                    padding: EdgeInsets.fromLTRB(20, 8, 9.5, 3),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          decoration: BoxDecoration(
                            border: Border.all(color: Color(0x59000000)),
                            borderRadius: BorderRadius.circular(100),
                            color: Color(0xFFDBF2F2),
                          ),
                          child: SizedBox(
                            width: 60,
                            child: Container(
                              padding: EdgeInsets.fromLTRB(0, 4.2, 0, 0),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    margin: EdgeInsets.fromLTRB(8.5, 0, 0.1, 0.2),
                                    child: SizedBox(
                                      width: 49.4,
                                      child: Row(
                                        mainAxisAlignment: MainAxisAlignment.start,
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Container(
                                            margin: EdgeInsets.fromLTRB(0, 5.6, 1.6, 0),
                                            child: SizedBox(
                                              width: 8.6,
                                              child: Column(
                                                mainAxisAlignment: MainAxisAlignment.start,
                                                crossAxisAlignment: CrossAxisAlignment.center,
                                                children: [
                                                  Container(
                                                    margin: EdgeInsets.fromLTRB(1.5, 0, 5, 0.5),
                                                    child: SizedBox(
                                                      width: 2.1,
                                                      height: 3.9,
                                                      child: SvgPicture.asset(
                                                        'assets/vectors/container_23_x2.svg',
                                                      ),
                                                    ),
                                                  ),
                                                  Container(
                                                    margin: EdgeInsets.fromLTRB(0, 0, 0, 3.7),
                                                    child: SizedBox(
                                                      width: 8.6,
                                                      child: Row(
                                                        mainAxisAlignment: MainAxisAlignment.start,
                                                        crossAxisAlignment: CrossAxisAlignment.start,
                                                        children: [
                                                          Container(
                                                            margin: EdgeInsets.fromLTRB(0, 0, 0, 2.8),
                                                            child: SizedBox(
                                                              width: 5.4,
                                                              height: 14.4,
                                                              child: SvgPicture.asset(
                                                                'assets/vectors/container_35_x2.svg',
                                                              ),
                                                            ),
                                                          ),
                                                          Container(
                                                            margin: EdgeInsets.fromLTRB(0, 13.5, 0, 0),
                                                            child: SizedBox(
                                                              width: 1.5,
                                                              height: 3.7,
                                                              child: SvgPicture.asset(
                                                                'assets/vectors/vector_14_x2.svg',
                                                              ),
                                                            ),
                                                          ),
                                                          Container(
                                                            margin: EdgeInsets.fromLTRB(0, 12.3, 0, 2),
                                                            child: SizedBox(
                                                              width: 2.6,
                                                              height: 2.9,
                                                              child: SvgPicture.asset(
                                                                'assets/vectors/vector_96_x2.svg',
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                  Container(
                                                    margin: EdgeInsets.fromLTRB(5.6, 0, 2.4, 2.7),
                                                    child: SizedBox(
                                                      width: 0.6,
                                                      height: 0.7,
                                                      child: SvgPicture.asset(
                                                        'assets/vectors/vector_23_x2.svg',
                                                      ),
                                                    ),
                                                  ),
                                                  Container(
                                                    margin: EdgeInsets.fromLTRB(0.2, 0, 0.3, 0),
                                                    child: SizedBox(
                                                      width: 8.1,
                                                      child: Row(
                                                        mainAxisAlignment: MainAxisAlignment.start,
                                                        crossAxisAlignment: CrossAxisAlignment.start,
                                                        children: [
                                                          Container(
                                                            margin: EdgeInsets.fromLTRB(0, 5.7, 0, 0.8),
                                                            child: SizedBox(
                                                              width: 0.8,
                                                              height: 3.7,
                                                              child: SvgPicture.asset(
                                                                'assets/vectors/vector_28_x2.svg',
                                                              ),
                                                            ),
                                                          ),
                                                          SizedBox(
                                                            width: 7.4,
                                                            height: 10.2,
                                                            child: Stack(
                                                              children: [
                                                                SizedBox(
                                                                  width: 7.4,
                                                                  height: 10.2,
                                                                  child: SvgPicture.asset(
                                                                    'assets/vectors/container_32_x2.svg',
                                                                  ),
                                                                ),
                                                                Positioned(
                                                                  right: 0.8,
                                                                  top: 1.6,
                                                                  child: SizedBox(
                                                                    width: 0.4,
                                                                    height: 2.7,
                                                                    child: SvgPicture.asset(
                                                                      'assets/vectors/vector_66_x2.svg',
                                                                    ),
                                                                  ),
                                                                ),
                                                                Positioned(
                                                                  left: 1,
                                                                  bottom: 4.2,
                                                                  child: SizedBox(
                                                                    width: 1.3,
                                                                    height: 0.8,
                                                                    child: SvgPicture.asset(
                                                                      'assets/vectors/vector_103_x2.svg',
                                                                    ),
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                          Container(
                                            margin: EdgeInsets.fromLTRB(0, 0, 5.4, 5.4),
                                            child: SizedBox(
                                              width: 2,
                                              height: 38.9,
                                              child: SvgPicture.asset(
                                                'assets/vectors/container_14_x2.svg',
                                              ),
                                            ),
                                          ),
                                          Container(
                                            margin: EdgeInsets.fromLTRB(0, 13.2, 3.3, 19.4),
                                            child: SizedBox(
                                              width: 6.5,
                                              height: 11.8,
                                              child: SvgPicture.asset(
                                                'assets/vectors/container_29_x2.svg',
                                              ),
                                            ),
                                          ),
                                          Container(
                                            margin: EdgeInsets.fromLTRB(0, 12, 7.5, 16.9),
                                            child: SizedBox(
                                              width: 7,
                                              child: Column(
                                                mainAxisAlignment: MainAxisAlignment.start,
                                                crossAxisAlignment: CrossAxisAlignment.center,
                                                children: [
                                                  Container(
                                                    margin: EdgeInsets.fromLTRB(0, 0, 0, 3.5),
                                                    child: SizedBox(
                                                      width: 7,
                                                      height: 3.5,
                                                      child: Stack(
                                                        children: [
                                                          SizedBox(
                                                            width: 7,
                                                            height: 3.5,
                                                            child: SvgPicture.asset(
                                                              'assets/vectors/vector_82_x2.svg',
                                                            ),
                                                          ),
                                                          Positioned(
                                                            left: 0.9,
                                                            bottom: 0.7,
                                                            child: SizedBox(
                                                              width: 1.1,
                                                              height: 0.5,
                                                              child: SvgPicture.asset(
                                                                'assets/vectors/vector_24_x2.svg',
                                                              ),
                                                            ),
                                                          ),
                                                          Positioned(
                                                            left: 2.3,
                                                            bottom: 0.7,
                                                            child: SizedBox(
                                                              width: 1.1,
                                                              height: 0.5,
                                                              child: SvgPicture.asset(
                                                                'assets/vectors/vector_62_x2.svg',
                                                              ),
                                                            ),
                                                          ),
                                                          Positioned(
                                                            right: 2.2,
                                                            bottom: 0.6,
                                                            child: SizedBox(
                                                              width: 1.1,
                                                              height: 0.5,
                                                              child: SvgPicture.asset(
                                                                'assets/vectors/vector_34_x2.svg',
                                                              ),
                                                            ),
                                                          ),
                                                          Positioned(
                                                            right: 0.8,
                                                            bottom: 0.6,
                                                            child: SizedBox(
                                                              width: 1.1,
                                                              height: 0.5,
                                                              child: SvgPicture.asset(
                                                                'assets/vectors/vector_61_x2.svg',
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                  Container(
                                                    margin: EdgeInsets.fromLTRB(0, 0, 0.1, 1.2),
                                                    child: SizedBox(
                                                      width: 7,
                                                      child: Row(
                                                        mainAxisAlignment: MainAxisAlignment.start,
                                                        crossAxisAlignment: CrossAxisAlignment.start,
                                                        children: [
                                                          Container(
                                                            margin: EdgeInsets.fromLTRB(0, 0, 0.6, 0),
                                                            child: SizedBox(
                                                              width: 1.9,
                                                              height: 1.3,
                                                              child: SvgPicture.asset(
                                                                'assets/vectors/vector_11_x2.svg',
                                                              ),
                                                            ),
                                                          ),
                                                          Container(
                                                            margin: EdgeInsets.fromLTRB(0, 0, 0.6, 0),
                                                            child: SizedBox(
                                                              width: 1.9,
                                                              height: 1.3,
                                                              child: SvgPicture.asset(
                                                                'assets/vectors/vector_58_x2.svg',
                                                              ),
                                                            ),
                                                          ),
                                                          SizedBox(
                                                            width: 1.9,
                                                            height: 1.3,
                                                            child: SvgPicture.asset(
                                                              'assets/vectors/vector_129_x2.svg',
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                  Container(
                                                    margin: EdgeInsets.fromLTRB(0, 0, 0.1, 1.2),
                                                    child: SizedBox(
                                                      width: 7,
                                                      child: Row(
                                                        mainAxisAlignment: MainAxisAlignment.start,
                                                        crossAxisAlignment: CrossAxisAlignment.start,
                                                        children: [
                                                          Container(
                                                            margin: EdgeInsets.fromLTRB(0, 0, 0.6, 0),
                                                            child: SizedBox(
                                                              width: 1.9,
                                                              height: 1.3,
                                                              child: SvgPicture.asset(
                                                                'assets/vectors/vector_10_x2.svg',
                                                              ),
                                                            ),
                                                          ),
                                                          Container(
                                                            margin: EdgeInsets.fromLTRB(0, 0, 0.6, 0),
                                                            child: SizedBox(
                                                              width: 1.9,
                                                              height: 1.3,
                                                              child: SvgPicture.asset(
                                                                'assets/vectors/vector_130_x2.svg',
                                                              ),
                                                            ),
                                                          ),
                                                          SizedBox(
                                                            width: 1.9,
                                                            height: 1.3,
                                                            child: SvgPicture.asset(
                                                              'assets/vectors/vector_105_x2.svg',
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                  Container(
                                                    margin: EdgeInsets.fromLTRB(0, 0, 0.1, 1.2),
                                                    child: SizedBox(
                                                      width: 7,
                                                      child: Row(
                                                        mainAxisAlignment: MainAxisAlignment.start,
                                                        crossAxisAlignment: CrossAxisAlignment.start,
                                                        children: [
                                                          Container(
                                                            margin: EdgeInsets.fromLTRB(0, 0, 0.6, 0),
                                                            child: SizedBox(
                                                              width: 1.9,
                                                              height: 1.3,
                                                              child: SvgPicture.asset(
                                                                'assets/vectors/vector_17_x2.svg',
                                                              ),
                                                            ),
                                                          ),
                                                          Container(
                                                            margin: EdgeInsets.fromLTRB(0, 0, 0.6, 0),
                                                            child: SizedBox(
                                                              width: 1.9,
                                                              height: 1.3,
                                                              child: SvgPicture.asset(
                                                                'assets/vectors/vector_33_x2.svg',
                                                              ),
                                                            ),
                                                          ),
                                                          SizedBox(
                                                            width: 1.9,
                                                            height: 1.3,
                                                            child: SvgPicture.asset(
                                                              'assets/vectors/vector_122_x2.svg',
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                  Container(
                                                    margin: EdgeInsets.fromLTRB(0, 0, 0.1, 0),
                                                    child: SizedBox(
                                                      width: 7,
                                                      child: Row(
                                                        mainAxisAlignment: MainAxisAlignment.start,
                                                        crossAxisAlignment: CrossAxisAlignment.start,
                                                        children: [
                                                          Container(
                                                            margin: EdgeInsets.fromLTRB(0, 0, 0.6, 0),
                                                            child: SizedBox(
                                                              width: 1.9,
                                                              height: 1.3,
                                                              child: SvgPicture.asset(
                                                                'assets/vectors/vector_1_x2.svg',
                                                              ),
                                                            ),
                                                          ),
                                                          Container(
                                                            margin: EdgeInsets.fromLTRB(0, 0, 0.6, 0),
                                                            child: SizedBox(
                                                              width: 1.9,
                                                              height: 1.3,
                                                              child: SvgPicture.asset(
                                                                'assets/vectors/vector_71_x2.svg',
                                                              ),
                                                            ),
                                                          ),
                                                          SizedBox(
                                                            width: 1.9,
                                                            height: 1.3,
                                                            child: SvgPicture.asset(
                                                              'assets/vectors/vector_48_x2.svg',
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                          Container(
                                            margin: EdgeInsets.fromLTRB(0, 30.9, 0, 0),
                                            child: SizedBox(
                                              width: 7.4,
                                              child: Column(
                                                mainAxisAlignment: MainAxisAlignment.start,
                                                crossAxisAlignment: CrossAxisAlignment.center,
                                                children: [
                                                  Container(
                                                    margin: EdgeInsets.fromLTRB(2.1, 0, 4.7, 2.7),
                                                    child: SizedBox(
                                                      width: 0.6,
                                                      height: 0.7,
                                                      child: SvgPicture.asset(
                                                        'assets/vectors/vector_99_x2.svg',
                                                      ),
                                                    ),
                                                  ),
                                                  SizedBox(
                                                    width: 7.4,
                                                    height: 10.2,
                                                    child: Stack(
                                                      children: [
                                                        SizedBox(
                                                          width: 7.4,
                                                          height: 10.2,
                                                          child: SvgPicture.asset(
                                                            'assets/vectors/container_24_x2.svg',
                                                          ),
                                                        ),
                                                        Positioned(
                                                          right: 1,
                                                          bottom: 4.2,
                                                          child: SizedBox(
                                                            width: 1.3,
                                                            height: 0.8,
                                                            child: SvgPicture.asset(
                                                              'assets/vectors/vector_89_x2.svg',
                                                            ),
                                                          ),
                                                        ),
                                                        Positioned(
                                                          right: 0.8,
                                                          top: 1.5,
                                                          child: SizedBox(
                                                            width: 0.3,
                                                            height: 1.1,
                                                            child: SvgPicture.asset(
                                                              'assets/vectors/vector_67_x2.svg',
                                                            ),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                  SizedBox(
                                    width: 60,
                                    height: 0.3,
                                    child: SvgPicture.asset(
                                      'assets/vectors/vector_116_x2.svg',
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                        Container(
                          margin: EdgeInsets.fromLTRB(0, 5, 0, 18),
                          child: Text(
                            'حساب الودائع',
                            style: GoogleFonts.getFont(
                              'Inter',
                              fontWeight: FontWeight.w700,
                              fontSize: 18,
                              height: 1.5,
                              color: Color(0xFF265073),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                Container(
                  margin: EdgeInsets.fromLTRB(24, 0, 32, 20),
                  child: Container(
                    padding: EdgeInsets.fromLTRB(21, 5, 18.6, 6),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          decoration: BoxDecoration(
                            color: Color(0xFFDBF2F2),
                            borderRadius: BorderRadius.circular(100),
                          ),
                          child: SizedBox(
                            width: 60,
                            child: Container(
                              padding: EdgeInsets.fromLTRB(0, 5, 0, 0),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Container(
                                    margin: EdgeInsets.fromLTRB(15.3, 0, 15.3, 0),
                                    child: Align(
                                      alignment: Alignment.topLeft,
                                      child: Transform.rotate(
                                        angle: -0.1552692059,
                                        child: SizedBox(
                                          width: 0.9,
                                          height: 0.3,
                                          child: SvgPicture.asset(
                                            'assets/vectors/vector_25_x2.svg',
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Container(
                                    margin: EdgeInsets.fromLTRB(12.6, 0, 12.6, 0),
                                    child: Align(
                                      alignment: Alignment.topLeft,
                                      child: SizedBox(
                                        width: 2.7,
                                        child: Row(
                                          mainAxisAlignment: MainAxisAlignment.start,
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Container(
                                              margin: EdgeInsets.fromLTRB(0, 0.3, 0.8, 2.3),
                                              child: Transform.rotate(
                                                angle: -0.1552692059,
                                                child: SizedBox(
                                                  width: 0.9,
                                                  height: 0.3,
                                                  child: SvgPicture.asset(
                                                    'assets/vectors/vector_91_x2.svg',
                                                  ),
                                                ),
                                              ),
                                            ),
                                            SizedBox(
                                              width: 1,
                                              height: 2.9,
                                              child: SvgPicture.asset(
                                                'assets/vectors/container_7_x2.svg',
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                  Container(
                                    margin: EdgeInsets.fromLTRB(13.6, 0, 13.6, 0),
                                    child: Align(
                                      alignment: Alignment.topLeft,
                                      child: SizedBox(
                                        width: 19.7,
                                        child: Row(
                                          mainAxisAlignment: MainAxisAlignment.start,
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Container(
                                              margin: EdgeInsets.fromLTRB(0, 2.2, 0.1, 2.6),
                                              child: SizedBox(
                                                width: 10.1,
                                                height: 5.1,
                                                child: SvgPicture.asset(
                                                  'assets/vectors/container_16_x2.svg',
                                                ),
                                              ),
                                            ),
                                            SizedBox(
                                              width: 9.6,
                                              height: 9.9,
                                              child: SvgPicture.asset(
                                                'assets/vectors/container_28_x2.svg',
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                  Container(
                                    margin: EdgeInsets.fromLTRB(7.6, 0, 13.6, 6),
                                    child: SizedBox(
                                      width: 38.8,
                                      child: Row(
                                        mainAxisAlignment: MainAxisAlignment.start,
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Container(
                                            margin: EdgeInsets.fromLTRB(0, 3.9, 0.6, 8),
                                            child: SizedBox(
                                              width: 6.1,
                                              height: 7.4,
                                              child: SvgPicture.asset(
                                                'assets/vectors/container_26_x2.svg',
                                              ),
                                            ),
                                          ),
                                          Container(
                                            margin: EdgeInsets.fromLTRB(0, 0, 0.4, 14.3),
                                            child: SizedBox(
                                              width: 11,
                                              height: 5,
                                              child: SvgPicture.asset(
                                                'assets/vectors/container_36_x2.svg',
                                              ),
                                            ),
                                          ),
                                          Container(
                                            margin: EdgeInsets.fromLTRB(0, 2.4, 5.3, 15.6),
                                            child: SizedBox(
                                              width: 7,
                                              height: 1.3,
                                              child: SvgPicture.asset(
                                                'assets/vectors/container_31_x2.svg',
                                              ),
                                            ),
                                          ),
                                          Container(
                                            margin: EdgeInsets.fromLTRB(0, 9.9, 1.5, 8.7),
                                            child: SizedBox(
                                              width: 3,
                                              height: 0.6,
                                              child: SvgPicture.asset(
                                                'assets/vectors/vector_9_x2.svg',
                                              ),
                                            ),
                                          ),
                                          Container(
                                            margin: EdgeInsets.fromLTRB(0, 9.4, 0, 0),
                                            child: SizedBox(
                                              width: 3.9,
                                              height: 9.9,
                                              child: SvgPicture.asset(
                                                'assets/vectors/vector_98_x2.svg',
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                  Container(
                                    margin: EdgeInsets.fromLTRB(0, 0, 3.4, 0.5),
                                    child: Align(
                                      alignment: Alignment.topCenter,
                                      child: SizedBox(
                                        width: 13.8,
                                        height: 6.4,
                                        child: SvgPicture.asset(
                                          'assets/vectors/container_x2.svg',
                                        ),
                                      ),
                                    ),
                                  ),
                                  SizedBox(
                                    width: 60,
                                    height: 0.2,
                                    child: SvgPicture.asset(
                                      'assets/vectors/vector_69_x2.svg',
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                        Container(
                          margin: EdgeInsets.fromLTRB(0, 9, 0, 14),
                          child: Text(
                            'زكاتك',
                            style: GoogleFonts.getFont(
                              'Inter',
                              fontWeight: FontWeight.w700,
                              fontSize: 18,
                              height: 1.5,
                              color: Color(0xFF265073),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                Container(
                  margin: EdgeInsets.fromLTRB(25, 0, 31, 9.5),
                  child: Container(
                    padding: EdgeInsets.fromLTRB(20, 5, 16.8, 6),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          decoration: BoxDecoration(
                            color: Color(0xFFDBF2F2),
                            borderRadius: BorderRadius.circular(100),
                          ),
                          child: SizedBox(
                            width: 60,
                            child: Container(
                              padding: EdgeInsets.fromLTRB(0, 0, 0, 0),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Container(
                                    margin: EdgeInsets.fromLTRB(3.4, 0, 0, 0),
                                    child: SizedBox(
                                      width: 56.6,
                                      child: Row(
                                        mainAxisAlignment: MainAxisAlignment.start,
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Container(
                                            margin: EdgeInsets.fromLTRB(0, 8.1, 2.7, 0),
                                            child: SizedBox(
                                              width: 19.1,
                                              height: 41.8,
                                              child: SvgPicture.asset(
                                                'assets/vectors/container_15_x2.svg',
                                              ),
                                            ),
                                          ),
                                          Container(
                                            margin: EdgeInsets.fromLTRB(0, 0, 0, 21.4),
                                            child: SizedBox(
                                              width: 34.8,
                                              height: 28.4,
                                              child: SvgPicture.asset(
                                                'assets/vectors/group_1_x2.svg',
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                  Align(
                                    alignment: Alignment.topLeft,
                                    child: SizedBox(
                                      width: 19.1,
                                      height: 0.2,
                                      child: SvgPicture.asset(
                                        'assets/vectors/vector_124_x2.svg',
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                        Container(
                          margin: EdgeInsets.fromLTRB(0, 8, 0, 15),
                          child: Text(
                            'تحويل  الاموال',
                            style: GoogleFonts.getFont(
                              'Inter',
                              fontWeight: FontWeight.w700,
                              fontSize: 18,
                              height: 1.5,
                              color: Color(0xFF265073),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                Container(
                  margin: EdgeInsets.fromLTRB(24, 0, 32, 9.5),
                  child: Stack(
                    children: [
                      Positioned(
                        top: 10.5,
                        child: Container(
                          width: 334,
                          height: 61,
                          child: Container(
                            decoration: BoxDecoration(
                              border: Border.all(color: Color(0xFF2F2E41)),
                              borderRadius: BorderRadius.circular(15),
                              color: Color(0xFFFFFFFF),
                            ),
                            child: Container(
                              width: 334,
                              height: 61,
                              child: Container(
                                decoration: BoxDecoration(
                                  color: Color(0x21D9D9D9),
                                ),
                                child: Container(
                                  width: 334,
                                  height: 61,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                Container(
                        padding: EdgeInsets.fromLTRB(14, 0, 19.4, 0),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              margin: EdgeInsets.fromLTRB(0, 17.5, 0, 13.5),
                              child: Container(
                                decoration: BoxDecoration(
                                  color: Color(0xFFDBF2F2),
                                  borderRadius: BorderRadius.circular(100),
                                ),
                                child: Stack(
                                  children: [
                                  Positioned(
                                    left: 19.6,
                                    top: 31.1,
                                    child: SizedBox(
                                      width: 12.3,
                                      height: 13.6,
                                      child: SvgPicture.asset(
                                        'assets/vectors/vector_45_x2.svg',
                                      ),
                                    ),
                                  ),
                            SizedBox(
                                      width: 60,
                                      child: Container(
                                        padding: EdgeInsets.fromLTRB(0, 5.3, 0, 0),
                                        child: Column(
                                          mainAxisAlignment: MainAxisAlignment.start,
                                          crossAxisAlignment: CrossAxisAlignment.end,
                                          children: [
                                            Container(
                                              margin: EdgeInsets.fromLTRB(12.4, 0, 0, 1),
                                              child: Align(
                                                alignment: Alignment.topCenter,
                                                child: SizedBox(
                                                  width: 6.9,
                                                  height: 0.6,
                                                  child: SvgPicture.asset(
                                                    'assets/vectors/vector_84_x2.svg',
                                                  ),
                                                ),
                                              ),
                                            ),
                                            Container(
                                              margin: EdgeInsets.fromLTRB(0, 0, 0, 0.4),
                                              child: SizedBox(
                                                width: 38.8,
                                                child: Row(
                                                  mainAxisAlignment: MainAxisAlignment.start,
                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                  children: [
                                                    Container(
                                                      margin: EdgeInsets.fromLTRB(0, 0.1, 5.8, 4.7),
                                                      child: SizedBox(
                                                        width: 7.9,
                                                        height: 10.3,
                                                        child: SvgPicture.asset(
                                                          'assets/vectors/container_1_x2.svg',
                                                        ),
                                                      ),
                                                    ),
                                                    Container(
                                                      margin: EdgeInsets.fromLTRB(0, 0, 2.1, 5.7),
                                                      child: SizedBox(
                                                        width: 2.8,
                                                        child: Column(
                                                          mainAxisAlignment: MainAxisAlignment.start,
                                                          crossAxisAlignment: CrossAxisAlignment.center,
                                                          children: [
                                                            Container(
                                                              margin: EdgeInsets.fromLTRB(0.6, 0, 0.7, 0.6),
                                                              child: SizedBox(
                                                                width: 1.5,
                                                                height: 5.5,
                                                                child: SvgPicture.asset(
                                                                  'assets/vectors/vector_123_x2.svg',
                                                                ),
                                                              ),
                                                            ),
                                                            SizedBox(
                                                              width: 2.8,
                                                              height: 3.3,
                                                              child: SvgPicture.asset(
                                                                'assets/vectors/vector_141_x2.svg',
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ),
                                                    Container(
                                                      margin: EdgeInsets.fromLTRB(0, 3.6, 2.2, 0),
                                                      child: SizedBox(
                                                        width: 11.1,
                                                        child: Column(
                                                          mainAxisAlignment: MainAxisAlignment.start,
                                                          crossAxisAlignment: CrossAxisAlignment.center,
                                                          children: [
                                                            Container(
                                                              margin: EdgeInsets.fromLTRB(0, 0, 0, 1.6),
                                                              child: SizedBox(
                                                                width: 11.1,
                                                                height: 1,
                                                                child: SvgPicture.asset(
                                                                  'assets/vectors/vector_139_x2.svg',
                                                                ),
                                                              ),
                                                            ),
                                                            Container(
                                                              margin: EdgeInsets.fromLTRB(4.3, 0, 4.5, 0),
                                                              child: SizedBox(
                                                                width: 2.4,
                                                                height: 8.9,
                                                                child: SvgPicture.asset(
                                                                  'assets/vectors/vector_106_x2.svg',
                                                                ),
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ),
                                                    Container(
                                                      margin: EdgeInsets.fromLTRB(0, 7.8, 0, 0.2),
                                                      child: SizedBox(
                                                        width: 6.9,
                                                        child: Column(
                                                          mainAxisAlignment: MainAxisAlignment.start,
                                                          crossAxisAlignment: CrossAxisAlignment.center,
                                                          children: [
                                                            Container(
                                                              margin: EdgeInsets.fromLTRB(0, 0, 0, 1),
                                                              child: SizedBox(
                                                                width: 6.9,
                                                                height: 0.6,
                                                                child: SvgPicture.asset(
                                                                  'assets/vectors/vector_60_x2.svg',
                                                                ),
                                                              ),
                                                            ),
                                                            Container(
                                                              margin: EdgeInsets.fromLTRB(2.6, 0, 2.8, 0),
                                                              child: SizedBox(
                                                                width: 1.5,
                                                                height: 5.5,
                                                                child: SvgPicture.asset(
                                                                  'assets/vectors/vector_12_x2.svg',
                                                                ),
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                            Container(
                                              margin: EdgeInsets.fromLTRB(2.1, 0, 2.1, 9.9),
                                              child: SizedBox(
                                                width: 20,
                                                child: Row(
                                                  mainAxisAlignment: MainAxisAlignment.start,
                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                  children: [
                                                    Container(
                                                      margin: EdgeInsets.fromLTRB(0, 1, 9, 0),
                                                      child: SizedBox(
                                                        width: 8.3,
                                                        height: 4.3,
                                                        child: SvgPicture.asset(
                                                          'assets/vectors/container_19_x2.svg',
                                                        ),
                                                      ),
                                                    ),
                                                    Container(
                                                      margin: EdgeInsets.fromLTRB(0, 0, 0, 2),
                                                      child: SizedBox(
                                                        width: 2.8,
                                                        height: 3.3,
                                                        child: SvgPicture.asset(
                                                          'assets/vectors/vector_6_x2.svg',
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                            Container(
                                              margin: EdgeInsets.fromLTRB(18, 0, 18, 0),
                                              child: Align(
                                                alignment: Alignment.topLeft,
                                                child: SizedBox(
                                                  width: 2.4,
                                                  height: 9.9,
                                                  child: SvgPicture.asset(
                                                    'assets/vectors/container_22_x2.svg',
                                                  ),
                                                ),
                                              ),
                                            ),
                                            Container(
                                              margin: EdgeInsets.fromLTRB(0, 0, 13.4, 0),
                                              child: SizedBox(
                                                width: 46.6,
                                                height: 3.2,
                                                child: SvgPicture.asset(
                                                  'assets/vectors/container_21_x2.svg',
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            Text(
                              'دروس في المالية  الاسلامية',
                              textAlign: TextAlign.center,
                              style: GoogleFonts.getFont(
                                'Inter',
                                fontWeight: FontWeight.w700,
                                fontSize: 18,
                                height: 1.5,
                                color: Color(0xFF265073),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  margin: EdgeInsets.fromLTRB(25, 0, 30.6, 17),
                  child: Container(
                    padding: EdgeInsets.fromLTRB(16, 6, 0, 5),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          decoration: BoxDecoration(
                            image: DecorationImage(
                              fit: BoxFit.cover,
                              image: AssetImage(
                                'assets/images/management_consulting.png',
                              ),
                            ),
                          ),
                          child: Container(
                            width: 50,
                            height: 50,
                          ),
                        ),
                        Container(
                          margin: EdgeInsets.fromLTRB(0, 11, 0, 12),
                          child: Text(
                            'استشارة اسلامية',
                            style: GoogleFonts.getFont(
                              'Inter',
                              fontWeight: FontWeight.w700,
                              fontSize: 18,
                              height: 1.5,
                              color: Color(0xFF265073),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                Container(
                  child: Container(
                    decoration: BoxDecoration(
                      color: Color(0xFF265073),
                      borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(12),
                        topRight: Radius.circular(12),
                      ),
                    ),
                    child: SizedBox(
                      width: double.infinity,
                      child: Container(
                        padding: EdgeInsets.fromLTRB(0, 12, 35.2, 17),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              margin: EdgeInsets.fromLTRB(0, 0, 0, 4),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Container(
                                    margin: EdgeInsets.fromLTRB(0, 1, 38.3, 1),
                                    child: Column(
                                      mainAxisAlignment: MainAxisAlignment.start,
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: [
                                        Container(
                                          margin: EdgeInsets.fromLTRB(5, 0, 19.7, 2),
                                          child: Container(
                                            decoration: BoxDecoration(
                                              image: DecorationImage(
                                                fit: BoxFit.cover,
                                                image: AssetImage(
                                                  'assets/images/home.png',
                                                ),
                                              ),
                                            ),
                                            child: Container(
                                              width: 24,
                                              height: 24,
                                            ),
                                          ),
                                        ),
                                        Text(
                                          'الرئيسية',
                                          style: GoogleFonts.getFont(
                                            'Inter',
                                            fontWeight: FontWeight.w400,
                                            fontSize: 10,
                                            height: 1.5,
                                            color: Color(0xFFFFFFFF),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Container(
                                    margin: EdgeInsets.fromLTRB(0, 1, 39.8, 0),
                                    child: Column(
                                      mainAxisAlignment: MainAxisAlignment.start,
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: [
                                        Container(
                                          margin: EdgeInsets.fromLTRB(3, 0, 19.2, 3),
                                          child: Container(
                                            decoration: BoxDecoration(
                                              image: DecorationImage(
                                                fit: BoxFit.cover,
                                                image: AssetImage(
                                                  'assets/images/credit_card.png',
                                                ),
                                              ),
                                            ),
                                            child: Container(
                                              width: 24,
                                              height: 24,
                                            ),
                                          ),
                                        ),
                                        Text(
                                          'بطاقاتي',
                                          style: GoogleFonts.getFont(
                                            'Inter',
                                            fontWeight: FontWeight.w400,
                                            fontSize: 10,
                                            height: 1.5,
                                            color: Color(0xFFFCFCFE),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Container(
                                    margin: EdgeInsets.fromLTRB(0, 0, 0, 2),
                                    child: Column(
                                      mainAxisAlignment: MainAxisAlignment.start,
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: [
                                        Container(
                                          margin: EdgeInsets.fromLTRB(8, 0, 7.4, 2),
                                          child: Container(
                                            decoration: BoxDecoration(
                                              image: DecorationImage(
                                                fit: BoxFit.cover,
                                                image: AssetImage(
                                                  'assets/images/chatbot_1.png',
                                                ),
                                              ),
                                            ),
                                            child: Container(
                                              width: 24,
                                              height: 24,
                                            ),
                                          ),
                                        ),
                                        Text(
                                          'chat bot',
                                          style: GoogleFonts.getFont(
                                            'Inter',
                                            fontWeight: FontWeight.w400,
                                            fontSize: 10,
                                            height: 1.5,
                                            color: Color(0xFFFFFFFF),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Container(
                              margin: EdgeInsets.fromLTRB(0, 1, 0, 0),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    margin: EdgeInsets.fromLTRB(2, 0, 16.8, 7),
                                    child: Container(
                                      decoration: BoxDecoration(
                                        image: DecorationImage(
                                          fit: BoxFit.cover,
                                          image: AssetImage(
                                            'assets/images/user_1.png',
                                          ),
                                        ),
                                      ),
                                      child: Container(
                                        width: 24,
                                        height: 24,
                                      ),
                                    ),
                                  ),
                                  Text(
                                    'حسابي',
                                    style: GoogleFonts.getFont(
                                      'Inter',
                                      fontWeight: FontWeight.w400,
                                      fontSize: 10,
                                      height: 1.5,
                                      color: Color(0xFFFFFFFF),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
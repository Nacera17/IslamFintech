
import 'package:flutter/material.dart';

import 'package:flutter_app/pages/activeactive_filledfalse.dart';
import 'package:flutter_app/pages/activeactive_filledfalse_1.dart';
import 'package:flutter_app/pages/activeactive_filledtrue.dart';
import 'package:flutter_app/pages/activeactive_filledtrue_1.dart';
import 'package:flutter_app/pages/activeinactive_filledfalse.dart';
import 'package:flutter_app/pages/activeinactive_filledfalse_1.dart';
import 'package:flutter_app/pages/activeinactive_filledtrue.dart';
import 'package:flutter_app/pages/activeinactive_filledtrue_1.dart';
import 'package:flutter_app/pages/ar_keyboard.dart';
import 'package:flutter_app/pages/ar_keyboard_1.dart';
import 'package:flutter_app/pages/ar_keyboard_2.dart';
import 'package:flutter_app/pages/ar_keyboard_3.dart';
import 'package:flutter_app/pages/arrow_left.dart';
import 'package:flutter_app/pages/arrow_left_1.dart';
import 'package:flutter_app/pages/back.dart';
import 'package:flutter_app/pages/back_1.dart';
import 'package:flutter_app/pages/back_2.dart';
import 'package:flutter_app/pages/check.dart';
import 'package:flutter_app/pages/check_1.dart';
import 'package:flutter_app/pages/component_13_variant_4.dart';
import 'package:flutter_app/pages/component_13_variant_41.dart';
import 'package:flutter_app/pages/component_13_variant_42.dart';
import 'package:flutter_app/pages/component_20.dart';
import 'package:flutter_app/pages/component_21.dart';
import 'package:flutter_app/pages/component_26.dart';
import 'package:flutter_app/pages/component_27.dart';
import 'package:flutter_app/pages/component_2_variant_4.dart';
import 'package:flutter_app/pages/component_2_variant_41.dart';
import 'package:flutter_app/pages/component_3.dart';
import 'package:flutter_app/pages/frame_15328.dart';
import 'package:flutter_app/pages/frame_15329.dart';
import 'package:flutter_app/pages/frame_15380.dart';
import 'package:flutter_app/pages/frame_15382.dart';
import 'package:flutter_app/pages/frame_15383.dart';
import 'package:flutter_app/pages/frame_15384.dart';
import 'package:flutter_app/pages/frame_15385.dart';
import 'package:flutter_app/pages/frame_15420.dart';
import 'package:flutter_app/pages/frame_15432.dart';
import 'package:flutter_app/pages/frame_15433.dart';
import 'package:flutter_app/pages/frame_15434.dart';
import 'package:flutter_app/pages/frame_3.dart';
import 'package:flutter_app/pages/group_25_default.dart';
import 'package:flutter_app/pages/group_26.dart';
import 'package:flutter_app/pages/heroicons_outlineeye.dart';
import 'package:flutter_app/pages/info.dart';
import 'package:flutter_app/pages/info_2.dart';
import 'package:flutter_app/pages/iphone_131425.dart';
import 'package:flutter_app/pages/iphone_131437.dart';
import 'package:flutter_app/pages/iphone_131438.dart';
import 'package:flutter_app/pages/iphone_131439.dart';
import 'package:flutter_app/pages/iphone_131440.dart';
import 'package:flutter_app/pages/iphone_131441.dart';
import 'package:flutter_app/pages/iphone_131442.dart';
import 'package:flutter_app/pages/iphone_131443.dart';
import 'package:flutter_app/pages/iphone_131445.dart';
import 'package:flutter_app/pages/iphone_131446.dart';
import 'package:flutter_app/pages/iphone_131447.dart';
import 'package:flutter_app/pages/iphone_131449.dart';
import 'package:flutter_app/pages/iphone_13145.dart';
import 'package:flutter_app/pages/iphone_131450.dart';
import 'package:flutter_app/pages/iphone_131451.dart';
import 'package:flutter_app/pages/iphone_131452.dart';
import 'package:flutter_app/pages/iphone_131453.dart';
import 'package:flutter_app/pages/iphone_131454.dart';
import 'package:flutter_app/pages/iphone_131455.dart';
import 'package:flutter_app/pages/iphone_131457.dart';
import 'package:flutter_app/pages/iphone_131458.dart';
import 'package:flutter_app/pages/iphone_131459.dart';
import 'package:flutter_app/pages/iphone_131460.dart';
import 'package:flutter_app/pages/iphone_131461.dart';
import 'package:flutter_app/pages/iphone_131462.dart';
import 'package:flutter_app/pages/iphone_131463.dart';
import 'package:flutter_app/pages/iphone_131464.dart';
import 'package:flutter_app/pages/iphone_131465.dart';
import 'package:flutter_app/pages/iphone_131466.dart';
import 'package:flutter_app/pages/iphone_131467.dart';
import 'package:flutter_app/pages/iphone_131468.dart';
import 'package:flutter_app/pages/iphone_131469.dart';
import 'package:flutter_app/pages/iphone_131470.dart';
import 'package:flutter_app/pages/iphone_131471.dart';
import 'package:flutter_app/pages/iphone_131472.dart';
import 'package:flutter_app/pages/iphone_131473.dart';
import 'package:flutter_app/pages/iphone_131474.dart';
import 'package:flutter_app/pages/iphone_131475.dart';
import 'package:flutter_app/pages/iphone_131476.dart';
import 'package:flutter_app/pages/iphone_131477.dart';
import 'package:flutter_app/pages/iphone_131478.dart';
import 'package:flutter_app/pages/iphone_131479.dart';
import 'package:flutter_app/pages/iphone_131480.dart';
import 'package:flutter_app/pages/iphone_131481.dart';
import 'package:flutter_app/pages/iphone_131482.dart';
import 'package:flutter_app/pages/iphone_131483.dart';
import 'package:flutter_app/pages/iphone_131484.dart';
import 'package:flutter_app/pages/iphone_131485.dart';
import 'package:flutter_app/pages/iphone_131486.dart';
import 'package:flutter_app/pages/iphone_131487.dart';
import 'package:flutter_app/pages/iphone_131488.dart';
import 'package:flutter_app/pages/iphone_131489.dart';
import 'package:flutter_app/pages/iphone_131490.dart';
import 'package:flutter_app/pages/mdieye_off.dart';
import 'package:flutter_app/pages/mdieye_off_1.dart';
import 'package:flutter_app/pages/mdieye_off_outline.dart';
import 'package:flutter_app/pages/no_keyboard.dart';
import 'package:flutter_app/pages/page.dart';
import 'package:flutter_app/pages/page_1.dart';
import 'package:flutter_app/pages/page_10.dart';
import 'package:flutter_app/pages/page_11.dart';
import 'package:flutter_app/pages/page_12.dart';
import 'package:flutter_app/pages/page_13.dart';
import 'package:flutter_app/pages/page_14.dart';
import 'package:flutter_app/pages/page_15.dart';
import 'package:flutter_app/pages/page_16.dart';
import 'package:flutter_app/pages/page_17.dart';
import 'package:flutter_app/pages/page_18.dart';
import 'package:flutter_app/pages/page_19.dart';
import 'package:flutter_app/pages/page_2.dart';
import 'package:flutter_app/pages/page_3.dart';
import 'package:flutter_app/pages/page_4.dart';
import 'package:flutter_app/pages/page_5.dart';
import 'package:flutter_app/pages/page_6.dart';
import 'package:flutter_app/pages/page_7.dart';
import 'package:flutter_app/pages/page_8.dart';
import 'package:flutter_app/pages/page_9.dart';
import 'package:flutter_app/pages/property_1_a.dart';
import 'package:flutter_app/pages/property_1_a_1.dart';
import 'package:flutter_app/pages/property_1_component_10.dart';
import 'package:flutter_app/pages/property_1_component_11.dart';
import 'package:flutter_app/pages/property_1_default.dart';
import 'package:flutter_app/pages/property_1_default_1.dart';
import 'package:flutter_app/pages/property_1_default_2.dart';
import 'package:flutter_app/pages/property_1_default_3.dart';
import 'package:flutter_app/pages/property_1_default_4.dart';
import 'package:flutter_app/pages/property_1_default_5.dart';
import 'package:flutter_app/pages/property_1_default_6.dart';
import 'package:flutter_app/pages/property_1_default_7.dart';
import 'package:flutter_app/pages/property_1_input_1.dart';
import 'package:flutter_app/pages/property_1_input_2.dart';
import 'package:flutter_app/pages/property_1_variant_2.dart';
import 'package:flutter_app/pages/property_1_variant_21.dart';
import 'package:flutter_app/pages/property_1_variant_22.dart';
import 'package:flutter_app/pages/property_1_variant_23.dart';
import 'package:flutter_app/pages/property_1_variant_3.dart';
import 'package:flutter_app/pages/property_1_variant_31.dart';
import 'package:flutter_app/pages/property_1_variant_32.dart';
import 'package:flutter_app/pages/property_1_variant_33.dart';
import 'package:flutter_app/pages/property_1_variant_4.dart';
import 'package:flutter_app/pages/property_1_variant_5.dart';
import 'package:flutter_app/pages/property_1_vector.dart';
import 'package:flutter_app/pages/property_1_vector_1.dart';
import 'package:flutter_app/pages/real_formsdelete_this.dart';
import 'package:flutter_app/pages/real_formsdelete_this_1.dart';
import 'package:flutter_app/pages/state_frame_15322.dart';
import 'package:flutter_app/pages/state_frame_153221.dart';
import 'package:flutter_app/pages/state_variant_2.dart';
import 'package:flutter_app/pages/state_variant_21.dart';
import 'package:flutter_app/pages/stateactive.dart';
import 'package:flutter_app/pages/stateactive_1.dart';
import 'package:flutter_app/pages/statechecked.dart';
import 'package:flutter_app/pages/statechecked_1.dart';
import 'package:flutter_app/pages/stateselected.dart';
import 'package:flutter_app/pages/stateselected_1.dart';
import 'package:flutter_app/pages/statevar_1.dart';
import 'package:flutter_app/pages/statevar_11.dart';
import 'package:flutter_app/pages/tablerpoint_filled.dart';
import 'package:flutter_app/pages/tablerpoint_filled_1.dart';
import 'package:flutter_app/pages/text.dart';
import 'package:flutter_app/pages/user_tie.dart';
import 'package:flutter_app/pages/user_tie_1.dart';
import 'package:flutter_app/pages/zakat.dart';


void main() => runApp(const MyApp());

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter App',
      initialRoute: '/Iphone131441',
      routes: {
        '/Iphone131441': (context) => Iphone131441(),
        '/Iphone131442': (context) => Iphone131442(),
        '/Iphone131439': (context) => Iphone131439(),
        '/Iphone131440': (context) => Iphone131440(),
        '/iphone131425': (context) => Iphone131425(),
        '/iphone131457': (context) => Iphone131457(),
        '/iphone131437': (context) => Iphone131437(),
        '/iphone13145': (context) => Iphone13145(),
        '/iphone131445': (context) => Iphone131445(),

      },
    );
  }
}

